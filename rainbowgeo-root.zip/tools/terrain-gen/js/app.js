var eE={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},PE={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},PP=0,CC=1,tP=2;var X7=1,DP=2,MQ=3,YQ=0,FB=1,yB=2;var LQ=0,OE=1,eC=2,PC=3,tC=4,IP=5,_Q=100,nP=101,rP=102,DC=103,IC=104,sP=200,iP=201,MP=202,oP=203,yf=204,Of=205,cP=206,aP=207,zP=208,HP=209,uP=210,dP=211,lP=212,hP=213,bP=214,mP=0,pP=1,FP=2,ev=3,xP=4,GP=5,LP=6,UP=7,Y7=0,XP=1,YP=2,UQ=0,TP=1,jP=2,yP=3,zw=4,OP=5,NP=6;var T7=300,ZE=301,VE=302,Nf=303,Rf=304,Lv=306,Zf=1e3,zB=1001,Vf=1002,hB=1003,nC=1004;var Cf=1005;var bB=1006,RP=1007;var TQ=1008;var XQ=1009,ZP=1010,VP=1011,Hw=1012,j7=1013,xQ=1014,GQ=1015,Mg=1016,y7=1017,O7=1018,AE=1020,kP=1021,KB=1023,qP=1024,JP=1025,BE=1026,kE=1027,WP=1028,N7=1029,SP=1030,R7=1031,Z7=1033,ef=33776,Pf=33777,tf=33778,Df=33779,rC=35840,sC=35841,iC=35842,MC=35843,V7=36196,oC=37492,cC=37496,aC=37808,zC=37809,HC=37810,uC=37811,dC=37812,lC=37813,hC=37814,bC=37815,mC=37816,pC=37817,FC=37818,xC=37819,GC=37820,LC=37821,If=36492,UC=36494,XC=36495,KP=36283,YC=36284,TC=36285,jC=36286;var Pv=2300,tv=2301,nf=2302,yC=2400,OC=2401,NC=2402;var k7=3e3,QE=3001,_P=3200,$P=3201,q7=0,At=1,OB="",eB="srgb",aQ="srgb-linear",uw="display-p3",Uv="display-p3-linear",Dv="linear",QB="srgb",Iv="rec709",nv="p3";var aE=7680;var RC=519,Bt=512,Qt=513,Et=514,J7=515,gt=516,vt=517,ft=518,wt=519,ZC=35044;var VC="300 es",kf=1035,oQ=2e3,rv=2001,fQ=class{addEventListener(A,B){this._listeners===void 0&&(this._listeners={});let Q=this._listeners;Q[A]===void 0&&(Q[A]=[]),Q[A].indexOf(B)===-1&&Q[A].push(B)}hasEventListener(A,B){if(this._listeners===void 0)return!1;let Q=this._listeners;return Q[A]!==void 0&&Q[A].indexOf(B)!==-1}removeEventListener(A,B){if(this._listeners===void 0)return;let g=this._listeners[A];if(g!==void 0){let v=g.indexOf(B);v!==-1&&g.splice(v,1)}}dispatchEvent(A){if(this._listeners===void 0)return;let Q=this._listeners[A.type];if(Q!==void 0){A.target=this;let g=Q.slice(0);for(let v=0,w=g.length;v<w;v++)g[v].call(this,A);A.target=null}}},oB=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],kC=1234567,ng=Math.PI/180,og=180/Math.PI;function _E(){let E=Math.random()*4294967295|0,A=Math.random()*4294967295|0,B=Math.random()*4294967295|0,Q=Math.random()*4294967295|0;return(oB[E&255]+oB[E>>8&255]+oB[E>>16&255]+oB[E>>24&255]+"-"+oB[A&255]+oB[A>>8&255]+"-"+oB[A>>16&15|64]+oB[A>>24&255]+"-"+oB[B&63|128]+oB[B>>8&255]+"-"+oB[B>>16&255]+oB[B>>24&255]+oB[Q&255]+oB[Q>>8&255]+oB[Q>>16&255]+oB[Q>>24&255]).toLowerCase()}function aB(E,A,B){return Math.max(A,Math.min(B,E))}function dw(E,A){return(E%A+A)%A}function Ct(E,A,B,Q,g){return Q+(E-A)*(g-Q)/(B-A)}function et(E,A,B){return E!==A?(B-E)/(A-E):0}function rg(E,A,B){return(1-B)*E+B*A}function Pt(E,A,B,Q){return rg(E,A,1-Math.exp(-B*Q))}function tt(E,A=1){return A-Math.abs(dw(E,A*2)-A)}function Dt(E,A,B){return E<=A?0:E>=B?1:(E=(E-A)/(B-A),E*E*(3-2*E))}function It(E,A,B){return E<=A?0:E>=B?1:(E=(E-A)/(B-A),E*E*E*(E*(E*6-15)+10))}function nt(E,A){return E+Math.floor(Math.random()*(A-E+1))}function rt(E,A){return E+Math.random()*(A-E)}function st(E){return E*(.5-Math.random())}function it(E){E!==void 0&&(kC=E);let A=kC+=1831565813;return A=Math.imul(A^A>>>15,A|1),A^=A+Math.imul(A^A>>>7,A|61),((A^A>>>14)>>>0)/4294967296}function Mt(E){return E*ng}function ot(E){return E*og}function qf(E){return(E&E-1)===0&&E!==0}function ct(E){return Math.pow(2,Math.ceil(Math.log(E)/Math.LN2))}function sv(E){return Math.pow(2,Math.floor(Math.log(E)/Math.LN2))}function at(E,A,B,Q,g){let v=Math.cos,w=Math.sin,f=v(B/2),C=w(B/2),e=v((A+Q)/2),P=w((A+Q)/2),D=v((A-Q)/2),t=w((A-Q)/2),n=v((Q-A)/2),s=w((Q-A)/2);switch(g){case"XYX":E.set(f*P,C*D,C*t,f*e);break;case"YZY":E.set(C*t,f*P,C*D,f*e);break;case"ZXZ":E.set(C*D,C*t,f*P,f*e);break;case"XZX":E.set(f*P,C*s,C*n,f*e);break;case"YXY":E.set(C*n,f*P,C*s,f*e);break;case"ZYZ":E.set(C*s,C*n,f*P,f*e);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+g)}}function YE(E,A){switch(A.constructor){case Float32Array:return E;case Uint32Array:return E/4294967295;case Uint16Array:return E/65535;case Uint8Array:return E/255;case Int32Array:return Math.max(E/2147483647,-1);case Int16Array:return Math.max(E/32767,-1);case Int8Array:return Math.max(E/127,-1);default:throw new Error("Invalid component type.")}}function dB(E,A){switch(A.constructor){case Float32Array:return E;case Uint32Array:return Math.round(E*4294967295);case Uint16Array:return Math.round(E*65535);case Uint8Array:return Math.round(E*255);case Int32Array:return Math.round(E*2147483647);case Int16Array:return Math.round(E*32767);case Int8Array:return Math.round(E*127);default:throw new Error("Invalid component type.")}}var W7={DEG2RAD:ng,RAD2DEG:og,generateUUID:_E,clamp:aB,euclideanModulo:dw,mapLinear:Ct,inverseLerp:et,lerp:rg,damp:Pt,pingpong:tt,smoothstep:Dt,smootherstep:It,randInt:nt,randFloat:rt,randFloatSpread:st,seededRandom:it,degToRad:Mt,radToDeg:ot,isPowerOfTwo:qf,ceilPowerOfTwo:ct,floorPowerOfTwo:sv,setQuaternionFromProperEuler:at,normalize:dB,denormalize:YE},hA=class E{constructor(A=0,B=0){E.prototype.isVector2=!0,this.x=A,this.y=B}get width(){return this.x}set width(A){this.x=A}get height(){return this.y}set height(A){this.y=A}set(A,B){return this.x=A,this.y=B,this}setScalar(A){return this.x=A,this.y=A,this}setX(A){return this.x=A,this}setY(A){return this.y=A,this}setComponent(A,B){switch(A){case 0:this.x=B;break;case 1:this.y=B;break;default:throw new Error("index is out of range: "+A)}return this}getComponent(A){switch(A){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+A)}}clone(){return new this.constructor(this.x,this.y)}copy(A){return this.x=A.x,this.y=A.y,this}add(A){return this.x+=A.x,this.y+=A.y,this}addScalar(A){return this.x+=A,this.y+=A,this}addVectors(A,B){return this.x=A.x+B.x,this.y=A.y+B.y,this}addScaledVector(A,B){return this.x+=A.x*B,this.y+=A.y*B,this}sub(A){return this.x-=A.x,this.y-=A.y,this}subScalar(A){return this.x-=A,this.y-=A,this}subVectors(A,B){return this.x=A.x-B.x,this.y=A.y-B.y,this}multiply(A){return this.x*=A.x,this.y*=A.y,this}multiplyScalar(A){return this.x*=A,this.y*=A,this}divide(A){return this.x/=A.x,this.y/=A.y,this}divideScalar(A){return this.multiplyScalar(1/A)}applyMatrix3(A){let B=this.x,Q=this.y,g=A.elements;return this.x=g[0]*B+g[3]*Q+g[6],this.y=g[1]*B+g[4]*Q+g[7],this}min(A){return this.x=Math.min(this.x,A.x),this.y=Math.min(this.y,A.y),this}max(A){return this.x=Math.max(this.x,A.x),this.y=Math.max(this.y,A.y),this}clamp(A,B){return this.x=Math.max(A.x,Math.min(B.x,this.x)),this.y=Math.max(A.y,Math.min(B.y,this.y)),this}clampScalar(A,B){return this.x=Math.max(A,Math.min(B,this.x)),this.y=Math.max(A,Math.min(B,this.y)),this}clampLength(A,B){let Q=this.length();return this.divideScalar(Q||1).multiplyScalar(Math.max(A,Math.min(B,Q)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(A){return this.x*A.x+this.y*A.y}cross(A){return this.x*A.y-this.y*A.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(A){let B=Math.sqrt(this.lengthSq()*A.lengthSq());if(B===0)return Math.PI/2;let Q=this.dot(A)/B;return Math.acos(aB(Q,-1,1))}distanceTo(A){return Math.sqrt(this.distanceToSquared(A))}distanceToSquared(A){let B=this.x-A.x,Q=this.y-A.y;return B*B+Q*Q}manhattanDistanceTo(A){return Math.abs(this.x-A.x)+Math.abs(this.y-A.y)}setLength(A){return this.normalize().multiplyScalar(A)}lerp(A,B){return this.x+=(A.x-this.x)*B,this.y+=(A.y-this.y)*B,this}lerpVectors(A,B,Q){return this.x=A.x+(B.x-A.x)*Q,this.y=A.y+(B.y-A.y)*Q,this}equals(A){return A.x===this.x&&A.y===this.y}fromArray(A,B=0){return this.x=A[B],this.y=A[B+1],this}toArray(A=[],B=0){return A[B]=this.x,A[B+1]=this.y,A}fromBufferAttribute(A,B){return this.x=A.getX(B),this.y=A.getY(B),this}rotateAround(A,B){let Q=Math.cos(B),g=Math.sin(B),v=this.x-A.x,w=this.y-A.y;return this.x=v*Q-w*g+A.x,this.y=v*g+w*Q+A.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},NA=class E{constructor(A,B,Q,g,v,w,f,C,e){E.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],A!==void 0&&this.set(A,B,Q,g,v,w,f,C,e)}set(A,B,Q,g,v,w,f,C,e){let P=this.elements;return P[0]=A,P[1]=g,P[2]=f,P[3]=B,P[4]=v,P[5]=C,P[6]=Q,P[7]=w,P[8]=e,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(A){let B=this.elements,Q=A.elements;return B[0]=Q[0],B[1]=Q[1],B[2]=Q[2],B[3]=Q[3],B[4]=Q[4],B[5]=Q[5],B[6]=Q[6],B[7]=Q[7],B[8]=Q[8],this}extractBasis(A,B,Q){return A.setFromMatrix3Column(this,0),B.setFromMatrix3Column(this,1),Q.setFromMatrix3Column(this,2),this}setFromMatrix4(A){let B=A.elements;return this.set(B[0],B[4],B[8],B[1],B[5],B[9],B[2],B[6],B[10]),this}multiply(A){return this.multiplyMatrices(this,A)}premultiply(A){return this.multiplyMatrices(A,this)}multiplyMatrices(A,B){let Q=A.elements,g=B.elements,v=this.elements,w=Q[0],f=Q[3],C=Q[6],e=Q[1],P=Q[4],D=Q[7],t=Q[2],n=Q[5],s=Q[8],i=g[0],r=g[3],I=g[6],H=g[1],o=g[4],l=g[7],F=g[2],b=g[5],h=g[8];return v[0]=w*i+f*H+C*F,v[3]=w*r+f*o+C*b,v[6]=w*I+f*l+C*h,v[1]=e*i+P*H+D*F,v[4]=e*r+P*o+D*b,v[7]=e*I+P*l+D*h,v[2]=t*i+n*H+s*F,v[5]=t*r+n*o+s*b,v[8]=t*I+n*l+s*h,this}multiplyScalar(A){let B=this.elements;return B[0]*=A,B[3]*=A,B[6]*=A,B[1]*=A,B[4]*=A,B[7]*=A,B[2]*=A,B[5]*=A,B[8]*=A,this}determinant(){let A=this.elements,B=A[0],Q=A[1],g=A[2],v=A[3],w=A[4],f=A[5],C=A[6],e=A[7],P=A[8];return B*w*P-B*f*e-Q*v*P+Q*f*C+g*v*e-g*w*C}invert(){let A=this.elements,B=A[0],Q=A[1],g=A[2],v=A[3],w=A[4],f=A[5],C=A[6],e=A[7],P=A[8],D=P*w-f*e,t=f*C-P*v,n=e*v-w*C,s=B*D+Q*t+g*n;if(s===0)return this.set(0,0,0,0,0,0,0,0,0);let i=1/s;return A[0]=D*i,A[1]=(g*e-P*Q)*i,A[2]=(f*Q-g*w)*i,A[3]=t*i,A[4]=(P*B-g*C)*i,A[5]=(g*v-f*B)*i,A[6]=n*i,A[7]=(Q*C-e*B)*i,A[8]=(w*B-Q*v)*i,this}transpose(){let A,B=this.elements;return A=B[1],B[1]=B[3],B[3]=A,A=B[2],B[2]=B[6],B[6]=A,A=B[5],B[5]=B[7],B[7]=A,this}getNormalMatrix(A){return this.setFromMatrix4(A).invert().transpose()}transposeIntoArray(A){let B=this.elements;return A[0]=B[0],A[1]=B[3],A[2]=B[6],A[3]=B[1],A[4]=B[4],A[5]=B[7],A[6]=B[2],A[7]=B[5],A[8]=B[8],this}setUvTransform(A,B,Q,g,v,w,f){let C=Math.cos(v),e=Math.sin(v);return this.set(Q*C,Q*e,-Q*(C*w+e*f)+w+A,-g*e,g*C,-g*(-e*w+C*f)+f+B,0,0,1),this}scale(A,B){return this.premultiply(rf.makeScale(A,B)),this}rotate(A){return this.premultiply(rf.makeRotation(-A)),this}translate(A,B){return this.premultiply(rf.makeTranslation(A,B)),this}makeTranslation(A,B){return A.isVector2?this.set(1,0,A.x,0,1,A.y,0,0,1):this.set(1,0,A,0,1,B,0,0,1),this}makeRotation(A){let B=Math.cos(A),Q=Math.sin(A);return this.set(B,-Q,0,Q,B,0,0,0,1),this}makeScale(A,B){return this.set(A,0,0,0,B,0,0,0,1),this}equals(A){let B=this.elements,Q=A.elements;for(let g=0;g<9;g++)if(B[g]!==Q[g])return!1;return!0}fromArray(A,B=0){for(let Q=0;Q<9;Q++)this.elements[Q]=A[Q+B];return this}toArray(A=[],B=0){let Q=this.elements;return A[B]=Q[0],A[B+1]=Q[1],A[B+2]=Q[2],A[B+3]=Q[3],A[B+4]=Q[4],A[B+5]=Q[5],A[B+6]=Q[6],A[B+7]=Q[7],A[B+8]=Q[8],A}clone(){return new this.constructor().fromArray(this.elements)}},rf=new NA;function S7(E){for(let A=E.length-1;A>=0;--A)if(E[A]>=65535)return!0;return!1}function iv(E){return document.createElementNS("http://www.w3.org/1999/xhtml",E)}function zt(){let E=iv("canvas");return E.style.display="block",E}var qC={};function sg(E){E in qC||(qC[E]=!0,console.warn(E))}var JC=new NA().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),WC=new NA().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),jg={[aQ]:{transfer:Dv,primaries:Iv,toReference:E=>E,fromReference:E=>E},[eB]:{transfer:QB,primaries:Iv,toReference:E=>E.convertSRGBToLinear(),fromReference:E=>E.convertLinearToSRGB()},[Uv]:{transfer:Dv,primaries:nv,toReference:E=>E.applyMatrix3(WC),fromReference:E=>E.applyMatrix3(JC)},[uw]:{transfer:QB,primaries:nv,toReference:E=>E.convertSRGBToLinear().applyMatrix3(WC),fromReference:E=>E.applyMatrix3(JC).convertLinearToSRGB()}},Ht=new Set([aQ,Uv]),KA={enabled:!0,_workingColorSpace:aQ,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(E){if(!Ht.has(E))throw new Error(`Unsupported working color space, "${E}".`);this._workingColorSpace=E},convert:function(E,A,B){if(this.enabled===!1||A===B||!A||!B)return E;let Q=jg[A].toReference,g=jg[B].fromReference;return g(Q(E))},fromWorkingColorSpace:function(E,A){return this.convert(E,this._workingColorSpace,A)},toWorkingColorSpace:function(E,A){return this.convert(E,A,this._workingColorSpace)},getPrimaries:function(E){return jg[E].primaries},getTransfer:function(E){return E===OB?Dv:jg[E].transfer}};function NE(E){return E<.04045?E*.0773993808:Math.pow(E*.9478672986+.0521327014,2.4)}function sf(E){return E<.0031308?E*12.92:1.055*Math.pow(E,.41666)-.055}var zE,Mv=class{static getDataURL(A){if(/^data:/i.test(A.src)||typeof HTMLCanvasElement>"u")return A.src;let B;if(A instanceof HTMLCanvasElement)B=A;else{zE===void 0&&(zE=iv("canvas")),zE.width=A.width,zE.height=A.height;let Q=zE.getContext("2d");A instanceof ImageData?Q.putImageData(A,0,0):Q.drawImage(A,0,0,A.width,A.height),B=zE}return B.width>2048||B.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",A),B.toDataURL("image/jpeg",.6)):B.toDataURL("image/png")}static sRGBToLinear(A){if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){let B=iv("canvas");B.width=A.width,B.height=A.height;let Q=B.getContext("2d");Q.drawImage(A,0,0,A.width,A.height);let g=Q.getImageData(0,0,A.width,A.height),v=g.data;for(let w=0;w<v.length;w++)v[w]=NE(v[w]/255)*255;return Q.putImageData(g,0,0),B}else if(A.data){let B=A.data.slice(0);for(let Q=0;Q<B.length;Q++)B instanceof Uint8Array||B instanceof Uint8ClampedArray?B[Q]=Math.floor(NE(B[Q]/255)*255):B[Q]=NE(B[Q]);return{data:B,width:A.width,height:A.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),A}},ut=0,ov=class{constructor(A=null){this.isSource=!0,Object.defineProperty(this,"id",{value:ut++}),this.uuid=_E(),this.data=A,this.version=0}set needsUpdate(A){A===!0&&this.version++}toJSON(A){let B=A===void 0||typeof A=="string";if(!B&&A.images[this.uuid]!==void 0)return A.images[this.uuid];let Q={uuid:this.uuid,url:""},g=this.data;if(g!==null){let v;if(Array.isArray(g)){v=[];for(let w=0,f=g.length;w<f;w++)g[w].isDataTexture?v.push(Mf(g[w].image)):v.push(Mf(g[w]))}else v=Mf(g);Q.url=v}return B||(A.images[this.uuid]=Q),Q}};function Mf(E){return typeof HTMLImageElement<"u"&&E instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&E instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&E instanceof ImageBitmap?Mv.getDataURL(E):E.data?{data:Array.from(E.data),width:E.width,height:E.height,type:E.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var dt=0,RB=class E extends fQ{constructor(A=E.DEFAULT_IMAGE,B=E.DEFAULT_MAPPING,Q=zB,g=zB,v=bB,w=TQ,f=KB,C=XQ,e=E.DEFAULT_ANISOTROPY,P=OB){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:dt++}),this.uuid=_E(),this.name="",this.source=new ov(A),this.mipmaps=[],this.mapping=B,this.channel=0,this.wrapS=Q,this.wrapT=g,this.magFilter=v,this.minFilter=w,this.anisotropy=e,this.format=f,this.internalFormat=null,this.type=C,this.offset=new hA(0,0),this.repeat=new hA(1,1),this.center=new hA(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new NA,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof P=="string"?this.colorSpace=P:(sg("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=P===QE?eB:OB),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(A=null){this.source.data=A}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(A){return this.name=A.name,this.source=A.source,this.mipmaps=A.mipmaps.slice(0),this.mapping=A.mapping,this.channel=A.channel,this.wrapS=A.wrapS,this.wrapT=A.wrapT,this.magFilter=A.magFilter,this.minFilter=A.minFilter,this.anisotropy=A.anisotropy,this.format=A.format,this.internalFormat=A.internalFormat,this.type=A.type,this.offset.copy(A.offset),this.repeat.copy(A.repeat),this.center.copy(A.center),this.rotation=A.rotation,this.matrixAutoUpdate=A.matrixAutoUpdate,this.matrix.copy(A.matrix),this.generateMipmaps=A.generateMipmaps,this.premultiplyAlpha=A.premultiplyAlpha,this.flipY=A.flipY,this.unpackAlignment=A.unpackAlignment,this.colorSpace=A.colorSpace,this.userData=JSON.parse(JSON.stringify(A.userData)),this.needsUpdate=!0,this}toJSON(A){let B=A===void 0||typeof A=="string";if(!B&&A.textures[this.uuid]!==void 0)return A.textures[this.uuid];let Q={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(A).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(Q.userData=this.userData),B||(A.textures[this.uuid]=Q),Q}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(A){if(this.mapping!==T7)return A;if(A.applyMatrix3(this.matrix),A.x<0||A.x>1)switch(this.wrapS){case Zf:A.x=A.x-Math.floor(A.x);break;case zB:A.x=A.x<0?0:1;break;case Vf:Math.abs(Math.floor(A.x)%2)===1?A.x=Math.ceil(A.x)-A.x:A.x=A.x-Math.floor(A.x);break}if(A.y<0||A.y>1)switch(this.wrapT){case Zf:A.y=A.y-Math.floor(A.y);break;case zB:A.y=A.y<0?0:1;break;case Vf:Math.abs(Math.floor(A.y)%2)===1?A.y=Math.ceil(A.y)-A.y:A.y=A.y-Math.floor(A.y);break}return this.flipY&&(A.y=1-A.y),A}set needsUpdate(A){A===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return sg("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===eB?QE:k7}set encoding(A){sg("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=A===QE?eB:OB}};RB.DEFAULT_IMAGE=null;RB.DEFAULT_MAPPING=T7;RB.DEFAULT_ANISOTROPY=1;var sB=class E{constructor(A=0,B=0,Q=0,g=1){E.prototype.isVector4=!0,this.x=A,this.y=B,this.z=Q,this.w=g}get width(){return this.z}set width(A){this.z=A}get height(){return this.w}set height(A){this.w=A}set(A,B,Q,g){return this.x=A,this.y=B,this.z=Q,this.w=g,this}setScalar(A){return this.x=A,this.y=A,this.z=A,this.w=A,this}setX(A){return this.x=A,this}setY(A){return this.y=A,this}setZ(A){return this.z=A,this}setW(A){return this.w=A,this}setComponent(A,B){switch(A){case 0:this.x=B;break;case 1:this.y=B;break;case 2:this.z=B;break;case 3:this.w=B;break;default:throw new Error("index is out of range: "+A)}return this}getComponent(A){switch(A){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+A)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(A){return this.x=A.x,this.y=A.y,this.z=A.z,this.w=A.w!==void 0?A.w:1,this}add(A){return this.x+=A.x,this.y+=A.y,this.z+=A.z,this.w+=A.w,this}addScalar(A){return this.x+=A,this.y+=A,this.z+=A,this.w+=A,this}addVectors(A,B){return this.x=A.x+B.x,this.y=A.y+B.y,this.z=A.z+B.z,this.w=A.w+B.w,this}addScaledVector(A,B){return this.x+=A.x*B,this.y+=A.y*B,this.z+=A.z*B,this.w+=A.w*B,this}sub(A){return this.x-=A.x,this.y-=A.y,this.z-=A.z,this.w-=A.w,this}subScalar(A){return this.x-=A,this.y-=A,this.z-=A,this.w-=A,this}subVectors(A,B){return this.x=A.x-B.x,this.y=A.y-B.y,this.z=A.z-B.z,this.w=A.w-B.w,this}multiply(A){return this.x*=A.x,this.y*=A.y,this.z*=A.z,this.w*=A.w,this}multiplyScalar(A){return this.x*=A,this.y*=A,this.z*=A,this.w*=A,this}applyMatrix4(A){let B=this.x,Q=this.y,g=this.z,v=this.w,w=A.elements;return this.x=w[0]*B+w[4]*Q+w[8]*g+w[12]*v,this.y=w[1]*B+w[5]*Q+w[9]*g+w[13]*v,this.z=w[2]*B+w[6]*Q+w[10]*g+w[14]*v,this.w=w[3]*B+w[7]*Q+w[11]*g+w[15]*v,this}divideScalar(A){return this.multiplyScalar(1/A)}setAxisAngleFromQuaternion(A){this.w=2*Math.acos(A.w);let B=Math.sqrt(1-A.w*A.w);return B<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=A.x/B,this.y=A.y/B,this.z=A.z/B),this}setAxisAngleFromRotationMatrix(A){let B,Q,g,v,C=A.elements,e=C[0],P=C[4],D=C[8],t=C[1],n=C[5],s=C[9],i=C[2],r=C[6],I=C[10];if(Math.abs(P-t)<.01&&Math.abs(D-i)<.01&&Math.abs(s-r)<.01){if(Math.abs(P+t)<.1&&Math.abs(D+i)<.1&&Math.abs(s+r)<.1&&Math.abs(e+n+I-3)<.1)return this.set(1,0,0,0),this;B=Math.PI;let o=(e+1)/2,l=(n+1)/2,F=(I+1)/2,b=(P+t)/4,h=(D+i)/4,Z=(s+r)/4;return o>l&&o>F?o<.01?(Q=0,g=.707106781,v=.707106781):(Q=Math.sqrt(o),g=b/Q,v=h/Q):l>F?l<.01?(Q=.707106781,g=0,v=.707106781):(g=Math.sqrt(l),Q=b/g,v=Z/g):F<.01?(Q=.707106781,g=.707106781,v=0):(v=Math.sqrt(F),Q=h/v,g=Z/v),this.set(Q,g,v,B),this}let H=Math.sqrt((r-s)*(r-s)+(D-i)*(D-i)+(t-P)*(t-P));return Math.abs(H)<.001&&(H=1),this.x=(r-s)/H,this.y=(D-i)/H,this.z=(t-P)/H,this.w=Math.acos((e+n+I-1)/2),this}min(A){return this.x=Math.min(this.x,A.x),this.y=Math.min(this.y,A.y),this.z=Math.min(this.z,A.z),this.w=Math.min(this.w,A.w),this}max(A){return this.x=Math.max(this.x,A.x),this.y=Math.max(this.y,A.y),this.z=Math.max(this.z,A.z),this.w=Math.max(this.w,A.w),this}clamp(A,B){return this.x=Math.max(A.x,Math.min(B.x,this.x)),this.y=Math.max(A.y,Math.min(B.y,this.y)),this.z=Math.max(A.z,Math.min(B.z,this.z)),this.w=Math.max(A.w,Math.min(B.w,this.w)),this}clampScalar(A,B){return this.x=Math.max(A,Math.min(B,this.x)),this.y=Math.max(A,Math.min(B,this.y)),this.z=Math.max(A,Math.min(B,this.z)),this.w=Math.max(A,Math.min(B,this.w)),this}clampLength(A,B){let Q=this.length();return this.divideScalar(Q||1).multiplyScalar(Math.max(A,Math.min(B,Q)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(A){return this.x*A.x+this.y*A.y+this.z*A.z+this.w*A.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(A){return this.normalize().multiplyScalar(A)}lerp(A,B){return this.x+=(A.x-this.x)*B,this.y+=(A.y-this.y)*B,this.z+=(A.z-this.z)*B,this.w+=(A.w-this.w)*B,this}lerpVectors(A,B,Q){return this.x=A.x+(B.x-A.x)*Q,this.y=A.y+(B.y-A.y)*Q,this.z=A.z+(B.z-A.z)*Q,this.w=A.w+(B.w-A.w)*Q,this}equals(A){return A.x===this.x&&A.y===this.y&&A.z===this.z&&A.w===this.w}fromArray(A,B=0){return this.x=A[B],this.y=A[B+1],this.z=A[B+2],this.w=A[B+3],this}toArray(A=[],B=0){return A[B]=this.x,A[B+1]=this.y,A[B+2]=this.z,A[B+3]=this.w,A}fromBufferAttribute(A,B){return this.x=A.getX(B),this.y=A.getY(B),this.z=A.getZ(B),this.w=A.getW(B),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Jf=class extends fQ{constructor(A=1,B=1,Q={}){super(),this.isRenderTarget=!0,this.width=A,this.height=B,this.depth=1,this.scissor=new sB(0,0,A,B),this.scissorTest=!1,this.viewport=new sB(0,0,A,B);let g={width:A,height:B,depth:1};Q.encoding!==void 0&&(sg("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),Q.colorSpace=Q.encoding===QE?eB:OB),Q=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:bB,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},Q),this.texture=new RB(g,Q.mapping,Q.wrapS,Q.wrapT,Q.magFilter,Q.minFilter,Q.format,Q.type,Q.anisotropy,Q.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=Q.generateMipmaps,this.texture.internalFormat=Q.internalFormat,this.depthBuffer=Q.depthBuffer,this.stencilBuffer=Q.stencilBuffer,this.depthTexture=Q.depthTexture,this.samples=Q.samples}setSize(A,B,Q=1){(this.width!==A||this.height!==B||this.depth!==Q)&&(this.width=A,this.height=B,this.depth=Q,this.texture.image.width=A,this.texture.image.height=B,this.texture.image.depth=Q,this.dispose()),this.viewport.set(0,0,A,B),this.scissor.set(0,0,A,B)}clone(){return new this.constructor().copy(this)}copy(A){this.width=A.width,this.height=A.height,this.depth=A.depth,this.scissor.copy(A.scissor),this.scissorTest=A.scissorTest,this.viewport.copy(A.viewport),this.texture=A.texture.clone(),this.texture.isRenderTargetTexture=!0;let B=Object.assign({},A.texture.image);return this.texture.source=new ov(B),this.depthBuffer=A.depthBuffer,this.stencilBuffer=A.stencilBuffer,A.depthTexture!==null&&(this.depthTexture=A.depthTexture.clone()),this.samples=A.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},zQ=class extends Jf{constructor(A=1,B=1,Q={}){super(A,B,Q),this.isWebGLRenderTarget=!0}},cv=class extends RB{constructor(A=null,B=1,Q=1,g=1){super(null),this.isDataArrayTexture=!0,this.image={data:A,width:B,height:Q,depth:g},this.magFilter=hB,this.minFilter=hB,this.wrapR=zB,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Wf=class extends RB{constructor(A=null,B=1,Q=1,g=1){super(null),this.isData3DTexture=!0,this.image={data:A,width:B,height:Q,depth:g},this.magFilter=hB,this.minFilter=hB,this.wrapR=zB,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var _B=class{constructor(A=0,B=0,Q=0,g=1){this.isQuaternion=!0,this._x=A,this._y=B,this._z=Q,this._w=g}static slerpFlat(A,B,Q,g,v,w,f){let C=Q[g+0],e=Q[g+1],P=Q[g+2],D=Q[g+3],t=v[w+0],n=v[w+1],s=v[w+2],i=v[w+3];if(f===0){A[B+0]=C,A[B+1]=e,A[B+2]=P,A[B+3]=D;return}if(f===1){A[B+0]=t,A[B+1]=n,A[B+2]=s,A[B+3]=i;return}if(D!==i||C!==t||e!==n||P!==s){let r=1-f,I=C*t+e*n+P*s+D*i,H=I>=0?1:-1,o=1-I*I;if(o>Number.EPSILON){let F=Math.sqrt(o),b=Math.atan2(F,I*H);r=Math.sin(r*b)/F,f=Math.sin(f*b)/F}let l=f*H;if(C=C*r+t*l,e=e*r+n*l,P=P*r+s*l,D=D*r+i*l,r===1-f){let F=1/Math.sqrt(C*C+e*e+P*P+D*D);C*=F,e*=F,P*=F,D*=F}}A[B]=C,A[B+1]=e,A[B+2]=P,A[B+3]=D}static multiplyQuaternionsFlat(A,B,Q,g,v,w){let f=Q[g],C=Q[g+1],e=Q[g+2],P=Q[g+3],D=v[w],t=v[w+1],n=v[w+2],s=v[w+3];return A[B]=f*s+P*D+C*n-e*t,A[B+1]=C*s+P*t+e*D-f*n,A[B+2]=e*s+P*n+f*t-C*D,A[B+3]=P*s-f*D-C*t-e*n,A}get x(){return this._x}set x(A){this._x=A,this._onChangeCallback()}get y(){return this._y}set y(A){this._y=A,this._onChangeCallback()}get z(){return this._z}set z(A){this._z=A,this._onChangeCallback()}get w(){return this._w}set w(A){this._w=A,this._onChangeCallback()}set(A,B,Q,g){return this._x=A,this._y=B,this._z=Q,this._w=g,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(A){return this._x=A.x,this._y=A.y,this._z=A.z,this._w=A.w,this._onChangeCallback(),this}setFromEuler(A,B=!0){let Q=A._x,g=A._y,v=A._z,w=A._order,f=Math.cos,C=Math.sin,e=f(Q/2),P=f(g/2),D=f(v/2),t=C(Q/2),n=C(g/2),s=C(v/2);switch(w){case"XYZ":this._x=t*P*D+e*n*s,this._y=e*n*D-t*P*s,this._z=e*P*s+t*n*D,this._w=e*P*D-t*n*s;break;case"YXZ":this._x=t*P*D+e*n*s,this._y=e*n*D-t*P*s,this._z=e*P*s-t*n*D,this._w=e*P*D+t*n*s;break;case"ZXY":this._x=t*P*D-e*n*s,this._y=e*n*D+t*P*s,this._z=e*P*s+t*n*D,this._w=e*P*D-t*n*s;break;case"ZYX":this._x=t*P*D-e*n*s,this._y=e*n*D+t*P*s,this._z=e*P*s-t*n*D,this._w=e*P*D+t*n*s;break;case"YZX":this._x=t*P*D+e*n*s,this._y=e*n*D+t*P*s,this._z=e*P*s-t*n*D,this._w=e*P*D-t*n*s;break;case"XZY":this._x=t*P*D-e*n*s,this._y=e*n*D-t*P*s,this._z=e*P*s+t*n*D,this._w=e*P*D+t*n*s;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+w)}return B===!0&&this._onChangeCallback(),this}setFromAxisAngle(A,B){let Q=B/2,g=Math.sin(Q);return this._x=A.x*g,this._y=A.y*g,this._z=A.z*g,this._w=Math.cos(Q),this._onChangeCallback(),this}setFromRotationMatrix(A){let B=A.elements,Q=B[0],g=B[4],v=B[8],w=B[1],f=B[5],C=B[9],e=B[2],P=B[6],D=B[10],t=Q+f+D;if(t>0){let n=.5/Math.sqrt(t+1);this._w=.25/n,this._x=(P-C)*n,this._y=(v-e)*n,this._z=(w-g)*n}else if(Q>f&&Q>D){let n=2*Math.sqrt(1+Q-f-D);this._w=(P-C)/n,this._x=.25*n,this._y=(g+w)/n,this._z=(v+e)/n}else if(f>D){let n=2*Math.sqrt(1+f-Q-D);this._w=(v-e)/n,this._x=(g+w)/n,this._y=.25*n,this._z=(C+P)/n}else{let n=2*Math.sqrt(1+D-Q-f);this._w=(w-g)/n,this._x=(v+e)/n,this._y=(C+P)/n,this._z=.25*n}return this._onChangeCallback(),this}setFromUnitVectors(A,B){let Q=A.dot(B)+1;return Q<Number.EPSILON?(Q=0,Math.abs(A.x)>Math.abs(A.z)?(this._x=-A.y,this._y=A.x,this._z=0,this._w=Q):(this._x=0,this._y=-A.z,this._z=A.y,this._w=Q)):(this._x=A.y*B.z-A.z*B.y,this._y=A.z*B.x-A.x*B.z,this._z=A.x*B.y-A.y*B.x,this._w=Q),this.normalize()}angleTo(A){return 2*Math.acos(Math.abs(aB(this.dot(A),-1,1)))}rotateTowards(A,B){let Q=this.angleTo(A);if(Q===0)return this;let g=Math.min(1,B/Q);return this.slerp(A,g),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(A){return this._x*A._x+this._y*A._y+this._z*A._z+this._w*A._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let A=this.length();return A===0?(this._x=0,this._y=0,this._z=0,this._w=1):(A=1/A,this._x=this._x*A,this._y=this._y*A,this._z=this._z*A,this._w=this._w*A),this._onChangeCallback(),this}multiply(A){return this.multiplyQuaternions(this,A)}premultiply(A){return this.multiplyQuaternions(A,this)}multiplyQuaternions(A,B){let Q=A._x,g=A._y,v=A._z,w=A._w,f=B._x,C=B._y,e=B._z,P=B._w;return this._x=Q*P+w*f+g*e-v*C,this._y=g*P+w*C+v*f-Q*e,this._z=v*P+w*e+Q*C-g*f,this._w=w*P-Q*f-g*C-v*e,this._onChangeCallback(),this}slerp(A,B){if(B===0)return this;if(B===1)return this.copy(A);let Q=this._x,g=this._y,v=this._z,w=this._w,f=w*A._w+Q*A._x+g*A._y+v*A._z;if(f<0?(this._w=-A._w,this._x=-A._x,this._y=-A._y,this._z=-A._z,f=-f):this.copy(A),f>=1)return this._w=w,this._x=Q,this._y=g,this._z=v,this;let C=1-f*f;if(C<=Number.EPSILON){let n=1-B;return this._w=n*w+B*this._w,this._x=n*Q+B*this._x,this._y=n*g+B*this._y,this._z=n*v+B*this._z,this.normalize(),this}let e=Math.sqrt(C),P=Math.atan2(e,f),D=Math.sin((1-B)*P)/e,t=Math.sin(B*P)/e;return this._w=w*D+this._w*t,this._x=Q*D+this._x*t,this._y=g*D+this._y*t,this._z=v*D+this._z*t,this._onChangeCallback(),this}slerpQuaternions(A,B,Q){return this.copy(A).slerp(B,Q)}random(){let A=Math.random(),B=Math.sqrt(1-A),Q=Math.sqrt(A),g=2*Math.PI*Math.random(),v=2*Math.PI*Math.random();return this.set(B*Math.cos(g),Q*Math.sin(v),Q*Math.cos(v),B*Math.sin(g))}equals(A){return A._x===this._x&&A._y===this._y&&A._z===this._z&&A._w===this._w}fromArray(A,B=0){return this._x=A[B],this._y=A[B+1],this._z=A[B+2],this._w=A[B+3],this._onChangeCallback(),this}toArray(A=[],B=0){return A[B]=this._x,A[B+1]=this._y,A[B+2]=this._z,A[B+3]=this._w,A}fromBufferAttribute(A,B){return this._x=A.getX(B),this._y=A.getY(B),this._z=A.getZ(B),this._w=A.getW(B),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(A){return this._onChangeCallback=A,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},x=class E{constructor(A=0,B=0,Q=0){E.prototype.isVector3=!0,this.x=A,this.y=B,this.z=Q}set(A,B,Q){return Q===void 0&&(Q=this.z),this.x=A,this.y=B,this.z=Q,this}setScalar(A){return this.x=A,this.y=A,this.z=A,this}setX(A){return this.x=A,this}setY(A){return this.y=A,this}setZ(A){return this.z=A,this}setComponent(A,B){switch(A){case 0:this.x=B;break;case 1:this.y=B;break;case 2:this.z=B;break;default:throw new Error("index is out of range: "+A)}return this}getComponent(A){switch(A){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+A)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(A){return this.x=A.x,this.y=A.y,this.z=A.z,this}add(A){return this.x+=A.x,this.y+=A.y,this.z+=A.z,this}addScalar(A){return this.x+=A,this.y+=A,this.z+=A,this}addVectors(A,B){return this.x=A.x+B.x,this.y=A.y+B.y,this.z=A.z+B.z,this}addScaledVector(A,B){return this.x+=A.x*B,this.y+=A.y*B,this.z+=A.z*B,this}sub(A){return this.x-=A.x,this.y-=A.y,this.z-=A.z,this}subScalar(A){return this.x-=A,this.y-=A,this.z-=A,this}subVectors(A,B){return this.x=A.x-B.x,this.y=A.y-B.y,this.z=A.z-B.z,this}multiply(A){return this.x*=A.x,this.y*=A.y,this.z*=A.z,this}multiplyScalar(A){return this.x*=A,this.y*=A,this.z*=A,this}multiplyVectors(A,B){return this.x=A.x*B.x,this.y=A.y*B.y,this.z=A.z*B.z,this}applyEuler(A){return this.applyQuaternion(SC.setFromEuler(A))}applyAxisAngle(A,B){return this.applyQuaternion(SC.setFromAxisAngle(A,B))}applyMatrix3(A){let B=this.x,Q=this.y,g=this.z,v=A.elements;return this.x=v[0]*B+v[3]*Q+v[6]*g,this.y=v[1]*B+v[4]*Q+v[7]*g,this.z=v[2]*B+v[5]*Q+v[8]*g,this}applyNormalMatrix(A){return this.applyMatrix3(A).normalize()}applyMatrix4(A){let B=this.x,Q=this.y,g=this.z,v=A.elements,w=1/(v[3]*B+v[7]*Q+v[11]*g+v[15]);return this.x=(v[0]*B+v[4]*Q+v[8]*g+v[12])*w,this.y=(v[1]*B+v[5]*Q+v[9]*g+v[13])*w,this.z=(v[2]*B+v[6]*Q+v[10]*g+v[14])*w,this}applyQuaternion(A){let B=this.x,Q=this.y,g=this.z,v=A.x,w=A.y,f=A.z,C=A.w,e=2*(w*g-f*Q),P=2*(f*B-v*g),D=2*(v*Q-w*B);return this.x=B+C*e+w*D-f*P,this.y=Q+C*P+f*e-v*D,this.z=g+C*D+v*P-w*e,this}project(A){return this.applyMatrix4(A.matrixWorldInverse).applyMatrix4(A.projectionMatrix)}unproject(A){return this.applyMatrix4(A.projectionMatrixInverse).applyMatrix4(A.matrixWorld)}transformDirection(A){let B=this.x,Q=this.y,g=this.z,v=A.elements;return this.x=v[0]*B+v[4]*Q+v[8]*g,this.y=v[1]*B+v[5]*Q+v[9]*g,this.z=v[2]*B+v[6]*Q+v[10]*g,this.normalize()}divide(A){return this.x/=A.x,this.y/=A.y,this.z/=A.z,this}divideScalar(A){return this.multiplyScalar(1/A)}min(A){return this.x=Math.min(this.x,A.x),this.y=Math.min(this.y,A.y),this.z=Math.min(this.z,A.z),this}max(A){return this.x=Math.max(this.x,A.x),this.y=Math.max(this.y,A.y),this.z=Math.max(this.z,A.z),this}clamp(A,B){return this.x=Math.max(A.x,Math.min(B.x,this.x)),this.y=Math.max(A.y,Math.min(B.y,this.y)),this.z=Math.max(A.z,Math.min(B.z,this.z)),this}clampScalar(A,B){return this.x=Math.max(A,Math.min(B,this.x)),this.y=Math.max(A,Math.min(B,this.y)),this.z=Math.max(A,Math.min(B,this.z)),this}clampLength(A,B){let Q=this.length();return this.divideScalar(Q||1).multiplyScalar(Math.max(A,Math.min(B,Q)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(A){return this.x*A.x+this.y*A.y+this.z*A.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(A){return this.normalize().multiplyScalar(A)}lerp(A,B){return this.x+=(A.x-this.x)*B,this.y+=(A.y-this.y)*B,this.z+=(A.z-this.z)*B,this}lerpVectors(A,B,Q){return this.x=A.x+(B.x-A.x)*Q,this.y=A.y+(B.y-A.y)*Q,this.z=A.z+(B.z-A.z)*Q,this}cross(A){return this.crossVectors(this,A)}crossVectors(A,B){let Q=A.x,g=A.y,v=A.z,w=B.x,f=B.y,C=B.z;return this.x=g*C-v*f,this.y=v*w-Q*C,this.z=Q*f-g*w,this}projectOnVector(A){let B=A.lengthSq();if(B===0)return this.set(0,0,0);let Q=A.dot(this)/B;return this.copy(A).multiplyScalar(Q)}projectOnPlane(A){return of.copy(this).projectOnVector(A),this.sub(of)}reflect(A){return this.sub(of.copy(A).multiplyScalar(2*this.dot(A)))}angleTo(A){let B=Math.sqrt(this.lengthSq()*A.lengthSq());if(B===0)return Math.PI/2;let Q=this.dot(A)/B;return Math.acos(aB(Q,-1,1))}distanceTo(A){return Math.sqrt(this.distanceToSquared(A))}distanceToSquared(A){let B=this.x-A.x,Q=this.y-A.y,g=this.z-A.z;return B*B+Q*Q+g*g}manhattanDistanceTo(A){return Math.abs(this.x-A.x)+Math.abs(this.y-A.y)+Math.abs(this.z-A.z)}setFromSpherical(A){return this.setFromSphericalCoords(A.radius,A.phi,A.theta)}setFromSphericalCoords(A,B,Q){let g=Math.sin(B)*A;return this.x=g*Math.sin(Q),this.y=Math.cos(B)*A,this.z=g*Math.cos(Q),this}setFromCylindrical(A){return this.setFromCylindricalCoords(A.radius,A.theta,A.y)}setFromCylindricalCoords(A,B,Q){return this.x=A*Math.sin(B),this.y=Q,this.z=A*Math.cos(B),this}setFromMatrixPosition(A){let B=A.elements;return this.x=B[12],this.y=B[13],this.z=B[14],this}setFromMatrixScale(A){let B=this.setFromMatrixColumn(A,0).length(),Q=this.setFromMatrixColumn(A,1).length(),g=this.setFromMatrixColumn(A,2).length();return this.x=B,this.y=Q,this.z=g,this}setFromMatrixColumn(A,B){return this.fromArray(A.elements,B*4)}setFromMatrix3Column(A,B){return this.fromArray(A.elements,B*3)}setFromEuler(A){return this.x=A._x,this.y=A._y,this.z=A._z,this}setFromColor(A){return this.x=A.r,this.y=A.g,this.z=A.b,this}equals(A){return A.x===this.x&&A.y===this.y&&A.z===this.z}fromArray(A,B=0){return this.x=A[B],this.y=A[B+1],this.z=A[B+2],this}toArray(A=[],B=0){return A[B]=this.x,A[B+1]=this.y,A[B+2]=this.z,A}fromBufferAttribute(A,B){return this.x=A.getX(B),this.y=A.getY(B),this.z=A.getZ(B),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let A=(Math.random()-.5)*2,B=Math.random()*Math.PI*2,Q=Math.sqrt(1-A**2);return this.x=Q*Math.cos(B),this.y=Q*Math.sin(B),this.z=A,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},of=new x,SC=new _B,EE=class{constructor(A=new x(1/0,1/0,1/0),B=new x(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=A,this.max=B}set(A,B){return this.min.copy(A),this.max.copy(B),this}setFromArray(A){this.makeEmpty();for(let B=0,Q=A.length;B<Q;B+=3)this.expandByPoint(JB.fromArray(A,B));return this}setFromBufferAttribute(A){this.makeEmpty();for(let B=0,Q=A.count;B<Q;B++)this.expandByPoint(JB.fromBufferAttribute(A,B));return this}setFromPoints(A){this.makeEmpty();for(let B=0,Q=A.length;B<Q;B++)this.expandByPoint(A[B]);return this}setFromCenterAndSize(A,B){let Q=JB.copy(B).multiplyScalar(.5);return this.min.copy(A).sub(Q),this.max.copy(A).add(Q),this}setFromObject(A,B=!1){return this.makeEmpty(),this.expandByObject(A,B)}clone(){return new this.constructor().copy(this)}copy(A){return this.min.copy(A.min),this.max.copy(A.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(A){return this.isEmpty()?A.set(0,0,0):A.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(A){return this.isEmpty()?A.set(0,0,0):A.subVectors(this.max,this.min)}expandByPoint(A){return this.min.min(A),this.max.max(A),this}expandByVector(A){return this.min.sub(A),this.max.add(A),this}expandByScalar(A){return this.min.addScalar(-A),this.max.addScalar(A),this}expandByObject(A,B=!1){A.updateWorldMatrix(!1,!1);let Q=A.geometry;if(Q!==void 0){let v=Q.getAttribute("position");if(B===!0&&v!==void 0&&A.isInstancedMesh!==!0)for(let w=0,f=v.count;w<f;w++)A.isMesh===!0?A.getVertexPosition(w,JB):JB.fromBufferAttribute(v,w),JB.applyMatrix4(A.matrixWorld),this.expandByPoint(JB);else A.boundingBox!==void 0?(A.boundingBox===null&&A.computeBoundingBox(),yg.copy(A.boundingBox)):(Q.boundingBox===null&&Q.computeBoundingBox(),yg.copy(Q.boundingBox)),yg.applyMatrix4(A.matrixWorld),this.union(yg)}let g=A.children;for(let v=0,w=g.length;v<w;v++)this.expandByObject(g[v],B);return this}containsPoint(A){return!(A.x<this.min.x||A.x>this.max.x||A.y<this.min.y||A.y>this.max.y||A.z<this.min.z||A.z>this.max.z)}containsBox(A){return this.min.x<=A.min.x&&A.max.x<=this.max.x&&this.min.y<=A.min.y&&A.max.y<=this.max.y&&this.min.z<=A.min.z&&A.max.z<=this.max.z}getParameter(A,B){return B.set((A.x-this.min.x)/(this.max.x-this.min.x),(A.y-this.min.y)/(this.max.y-this.min.y),(A.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(A){return!(A.max.x<this.min.x||A.min.x>this.max.x||A.max.y<this.min.y||A.min.y>this.max.y||A.max.z<this.min.z||A.min.z>this.max.z)}intersectsSphere(A){return this.clampPoint(A.center,JB),JB.distanceToSquared(A.center)<=A.radius*A.radius}intersectsPlane(A){let B,Q;return A.normal.x>0?(B=A.normal.x*this.min.x,Q=A.normal.x*this.max.x):(B=A.normal.x*this.max.x,Q=A.normal.x*this.min.x),A.normal.y>0?(B+=A.normal.y*this.min.y,Q+=A.normal.y*this.max.y):(B+=A.normal.y*this.max.y,Q+=A.normal.y*this.min.y),A.normal.z>0?(B+=A.normal.z*this.min.z,Q+=A.normal.z*this.max.z):(B+=A.normal.z*this.max.z,Q+=A.normal.z*this.min.z),B<=-A.constant&&Q>=-A.constant}intersectsTriangle(A){if(this.isEmpty())return!1;this.getCenter(Pg),Og.subVectors(this.max,Pg),HE.subVectors(A.a,Pg),uE.subVectors(A.b,Pg),dE.subVectors(A.c,Pg),hQ.subVectors(uE,HE),bQ.subVectors(dE,uE),qQ.subVectors(HE,dE);let B=[0,-hQ.z,hQ.y,0,-bQ.z,bQ.y,0,-qQ.z,qQ.y,hQ.z,0,-hQ.x,bQ.z,0,-bQ.x,qQ.z,0,-qQ.x,-hQ.y,hQ.x,0,-bQ.y,bQ.x,0,-qQ.y,qQ.x,0];return!cf(B,HE,uE,dE,Og)||(B=[1,0,0,0,1,0,0,0,1],!cf(B,HE,uE,dE,Og))?!1:(Ng.crossVectors(hQ,bQ),B=[Ng.x,Ng.y,Ng.z],cf(B,HE,uE,dE,Og))}clampPoint(A,B){return B.copy(A).clamp(this.min,this.max)}distanceToPoint(A){return this.clampPoint(A,JB).distanceTo(A)}getBoundingSphere(A){return this.isEmpty()?A.makeEmpty():(this.getCenter(A.center),A.radius=this.getSize(JB).length()*.5),A}intersect(A){return this.min.max(A.min),this.max.min(A.max),this.isEmpty()&&this.makeEmpty(),this}union(A){return this.min.min(A.min),this.max.max(A.max),this}applyMatrix4(A){return this.isEmpty()?this:(IQ[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(A),IQ[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(A),IQ[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(A),IQ[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(A),IQ[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(A),IQ[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(A),IQ[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(A),IQ[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(A),this.setFromPoints(IQ),this)}translate(A){return this.min.add(A),this.max.add(A),this}equals(A){return A.min.equals(this.min)&&A.max.equals(this.max)}},IQ=[new x,new x,new x,new x,new x,new x,new x,new x],JB=new x,yg=new EE,HE=new x,uE=new x,dE=new x,hQ=new x,bQ=new x,qQ=new x,Pg=new x,Og=new x,Ng=new x,JQ=new x;function cf(E,A,B,Q,g){for(let v=0,w=E.length-3;v<=w;v+=3){JQ.fromArray(E,v);let f=g.x*Math.abs(JQ.x)+g.y*Math.abs(JQ.y)+g.z*Math.abs(JQ.z),C=A.dot(JQ),e=B.dot(JQ),P=Q.dot(JQ);if(Math.max(-Math.max(C,e,P),Math.min(C,e,P))>f)return!1}return!0}var lt=new EE,tg=new x,af=new x,qE=class{constructor(A=new x,B=-1){this.isSphere=!0,this.center=A,this.radius=B}set(A,B){return this.center.copy(A),this.radius=B,this}setFromPoints(A,B){let Q=this.center;B!==void 0?Q.copy(B):lt.setFromPoints(A).getCenter(Q);let g=0;for(let v=0,w=A.length;v<w;v++)g=Math.max(g,Q.distanceToSquared(A[v]));return this.radius=Math.sqrt(g),this}copy(A){return this.center.copy(A.center),this.radius=A.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(A){return A.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(A){return A.distanceTo(this.center)-this.radius}intersectsSphere(A){let B=this.radius+A.radius;return A.center.distanceToSquared(this.center)<=B*B}intersectsBox(A){return A.intersectsSphere(this)}intersectsPlane(A){return Math.abs(A.distanceToPoint(this.center))<=this.radius}clampPoint(A,B){let Q=this.center.distanceToSquared(A);return B.copy(A),Q>this.radius*this.radius&&(B.sub(this.center).normalize(),B.multiplyScalar(this.radius).add(this.center)),B}getBoundingBox(A){return this.isEmpty()?(A.makeEmpty(),A):(A.set(this.center,this.center),A.expandByScalar(this.radius),A)}applyMatrix4(A){return this.center.applyMatrix4(A),this.radius=this.radius*A.getMaxScaleOnAxis(),this}translate(A){return this.center.add(A),this}expandByPoint(A){if(this.isEmpty())return this.center.copy(A),this.radius=0,this;tg.subVectors(A,this.center);let B=tg.lengthSq();if(B>this.radius*this.radius){let Q=Math.sqrt(B),g=(Q-this.radius)*.5;this.center.addScaledVector(tg,g/Q),this.radius+=g}return this}union(A){return A.isEmpty()?this:this.isEmpty()?(this.copy(A),this):(this.center.equals(A.center)===!0?this.radius=Math.max(this.radius,A.radius):(af.subVectors(A.center,this.center).setLength(A.radius),this.expandByPoint(tg.copy(A.center).add(af)),this.expandByPoint(tg.copy(A.center).sub(af))),this)}equals(A){return A.center.equals(this.center)&&A.radius===this.radius}clone(){return new this.constructor().copy(this)}},nQ=new x,zf=new x,Rg=new x,mQ=new x,Hf=new x,Zg=new x,uf=new x,gE=class{constructor(A=new x,B=new x(0,0,-1)){this.origin=A,this.direction=B}set(A,B){return this.origin.copy(A),this.direction.copy(B),this}copy(A){return this.origin.copy(A.origin),this.direction.copy(A.direction),this}at(A,B){return B.copy(this.origin).addScaledVector(this.direction,A)}lookAt(A){return this.direction.copy(A).sub(this.origin).normalize(),this}recast(A){return this.origin.copy(this.at(A,nQ)),this}closestPointToPoint(A,B){B.subVectors(A,this.origin);let Q=B.dot(this.direction);return Q<0?B.copy(this.origin):B.copy(this.origin).addScaledVector(this.direction,Q)}distanceToPoint(A){return Math.sqrt(this.distanceSqToPoint(A))}distanceSqToPoint(A){let B=nQ.subVectors(A,this.origin).dot(this.direction);return B<0?this.origin.distanceToSquared(A):(nQ.copy(this.origin).addScaledVector(this.direction,B),nQ.distanceToSquared(A))}distanceSqToSegment(A,B,Q,g){zf.copy(A).add(B).multiplyScalar(.5),Rg.copy(B).sub(A).normalize(),mQ.copy(this.origin).sub(zf);let v=A.distanceTo(B)*.5,w=-this.direction.dot(Rg),f=mQ.dot(this.direction),C=-mQ.dot(Rg),e=mQ.lengthSq(),P=Math.abs(1-w*w),D,t,n,s;if(P>0)if(D=w*C-f,t=w*f-C,s=v*P,D>=0)if(t>=-s)if(t<=s){let i=1/P;D*=i,t*=i,n=D*(D+w*t+2*f)+t*(w*D+t+2*C)+e}else t=v,D=Math.max(0,-(w*t+f)),n=-D*D+t*(t+2*C)+e;else t=-v,D=Math.max(0,-(w*t+f)),n=-D*D+t*(t+2*C)+e;else t<=-s?(D=Math.max(0,-(-w*v+f)),t=D>0?-v:Math.min(Math.max(-v,-C),v),n=-D*D+t*(t+2*C)+e):t<=s?(D=0,t=Math.min(Math.max(-v,-C),v),n=t*(t+2*C)+e):(D=Math.max(0,-(w*v+f)),t=D>0?v:Math.min(Math.max(-v,-C),v),n=-D*D+t*(t+2*C)+e);else t=w>0?-v:v,D=Math.max(0,-(w*t+f)),n=-D*D+t*(t+2*C)+e;return Q&&Q.copy(this.origin).addScaledVector(this.direction,D),g&&g.copy(zf).addScaledVector(Rg,t),n}intersectSphere(A,B){nQ.subVectors(A.center,this.origin);let Q=nQ.dot(this.direction),g=nQ.dot(nQ)-Q*Q,v=A.radius*A.radius;if(g>v)return null;let w=Math.sqrt(v-g),f=Q-w,C=Q+w;return C<0?null:f<0?this.at(C,B):this.at(f,B)}intersectsSphere(A){return this.distanceSqToPoint(A.center)<=A.radius*A.radius}distanceToPlane(A){let B=A.normal.dot(this.direction);if(B===0)return A.distanceToPoint(this.origin)===0?0:null;let Q=-(this.origin.dot(A.normal)+A.constant)/B;return Q>=0?Q:null}intersectPlane(A,B){let Q=this.distanceToPlane(A);return Q===null?null:this.at(Q,B)}intersectsPlane(A){let B=A.distanceToPoint(this.origin);return B===0||A.normal.dot(this.direction)*B<0}intersectBox(A,B){let Q,g,v,w,f,C,e=1/this.direction.x,P=1/this.direction.y,D=1/this.direction.z,t=this.origin;return e>=0?(Q=(A.min.x-t.x)*e,g=(A.max.x-t.x)*e):(Q=(A.max.x-t.x)*e,g=(A.min.x-t.x)*e),P>=0?(v=(A.min.y-t.y)*P,w=(A.max.y-t.y)*P):(v=(A.max.y-t.y)*P,w=(A.min.y-t.y)*P),Q>w||v>g||((v>Q||isNaN(Q))&&(Q=v),(w<g||isNaN(g))&&(g=w),D>=0?(f=(A.min.z-t.z)*D,C=(A.max.z-t.z)*D):(f=(A.max.z-t.z)*D,C=(A.min.z-t.z)*D),Q>C||f>g)||((f>Q||Q!==Q)&&(Q=f),(C<g||g!==g)&&(g=C),g<0)?null:this.at(Q>=0?Q:g,B)}intersectsBox(A){return this.intersectBox(A,nQ)!==null}intersectTriangle(A,B,Q,g,v){Hf.subVectors(B,A),Zg.subVectors(Q,A),uf.crossVectors(Hf,Zg);let w=this.direction.dot(uf),f;if(w>0){if(g)return null;f=1}else if(w<0)f=-1,w=-w;else return null;mQ.subVectors(this.origin,A);let C=f*this.direction.dot(Zg.crossVectors(mQ,Zg));if(C<0)return null;let e=f*this.direction.dot(Hf.cross(mQ));if(e<0||C+e>w)return null;let P=-f*mQ.dot(uf);return P<0?null:this.at(P/w,v)}applyMatrix4(A){return this.origin.applyMatrix4(A),this.direction.transformDirection(A),this}equals(A){return A.origin.equals(this.origin)&&A.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},fB=class E{constructor(A,B,Q,g,v,w,f,C,e,P,D,t,n,s,i,r){E.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],A!==void 0&&this.set(A,B,Q,g,v,w,f,C,e,P,D,t,n,s,i,r)}set(A,B,Q,g,v,w,f,C,e,P,D,t,n,s,i,r){let I=this.elements;return I[0]=A,I[4]=B,I[8]=Q,I[12]=g,I[1]=v,I[5]=w,I[9]=f,I[13]=C,I[2]=e,I[6]=P,I[10]=D,I[14]=t,I[3]=n,I[7]=s,I[11]=i,I[15]=r,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new E().fromArray(this.elements)}copy(A){let B=this.elements,Q=A.elements;return B[0]=Q[0],B[1]=Q[1],B[2]=Q[2],B[3]=Q[3],B[4]=Q[4],B[5]=Q[5],B[6]=Q[6],B[7]=Q[7],B[8]=Q[8],B[9]=Q[9],B[10]=Q[10],B[11]=Q[11],B[12]=Q[12],B[13]=Q[13],B[14]=Q[14],B[15]=Q[15],this}copyPosition(A){let B=this.elements,Q=A.elements;return B[12]=Q[12],B[13]=Q[13],B[14]=Q[14],this}setFromMatrix3(A){let B=A.elements;return this.set(B[0],B[3],B[6],0,B[1],B[4],B[7],0,B[2],B[5],B[8],0,0,0,0,1),this}extractBasis(A,B,Q){return A.setFromMatrixColumn(this,0),B.setFromMatrixColumn(this,1),Q.setFromMatrixColumn(this,2),this}makeBasis(A,B,Q){return this.set(A.x,B.x,Q.x,0,A.y,B.y,Q.y,0,A.z,B.z,Q.z,0,0,0,0,1),this}extractRotation(A){let B=this.elements,Q=A.elements,g=1/lE.setFromMatrixColumn(A,0).length(),v=1/lE.setFromMatrixColumn(A,1).length(),w=1/lE.setFromMatrixColumn(A,2).length();return B[0]=Q[0]*g,B[1]=Q[1]*g,B[2]=Q[2]*g,B[3]=0,B[4]=Q[4]*v,B[5]=Q[5]*v,B[6]=Q[6]*v,B[7]=0,B[8]=Q[8]*w,B[9]=Q[9]*w,B[10]=Q[10]*w,B[11]=0,B[12]=0,B[13]=0,B[14]=0,B[15]=1,this}makeRotationFromEuler(A){let B=this.elements,Q=A.x,g=A.y,v=A.z,w=Math.cos(Q),f=Math.sin(Q),C=Math.cos(g),e=Math.sin(g),P=Math.cos(v),D=Math.sin(v);if(A.order==="XYZ"){let t=w*P,n=w*D,s=f*P,i=f*D;B[0]=C*P,B[4]=-C*D,B[8]=e,B[1]=n+s*e,B[5]=t-i*e,B[9]=-f*C,B[2]=i-t*e,B[6]=s+n*e,B[10]=w*C}else if(A.order==="YXZ"){let t=C*P,n=C*D,s=e*P,i=e*D;B[0]=t+i*f,B[4]=s*f-n,B[8]=w*e,B[1]=w*D,B[5]=w*P,B[9]=-f,B[2]=n*f-s,B[6]=i+t*f,B[10]=w*C}else if(A.order==="ZXY"){let t=C*P,n=C*D,s=e*P,i=e*D;B[0]=t-i*f,B[4]=-w*D,B[8]=s+n*f,B[1]=n+s*f,B[5]=w*P,B[9]=i-t*f,B[2]=-w*e,B[6]=f,B[10]=w*C}else if(A.order==="ZYX"){let t=w*P,n=w*D,s=f*P,i=f*D;B[0]=C*P,B[4]=s*e-n,B[8]=t*e+i,B[1]=C*D,B[5]=i*e+t,B[9]=n*e-s,B[2]=-e,B[6]=f*C,B[10]=w*C}else if(A.order==="YZX"){let t=w*C,n=w*e,s=f*C,i=f*e;B[0]=C*P,B[4]=i-t*D,B[8]=s*D+n,B[1]=D,B[5]=w*P,B[9]=-f*P,B[2]=-e*P,B[6]=n*D+s,B[10]=t-i*D}else if(A.order==="XZY"){let t=w*C,n=w*e,s=f*C,i=f*e;B[0]=C*P,B[4]=-D,B[8]=e*P,B[1]=t*D+i,B[5]=w*P,B[9]=n*D-s,B[2]=s*D-n,B[6]=f*P,B[10]=i*D+t}return B[3]=0,B[7]=0,B[11]=0,B[12]=0,B[13]=0,B[14]=0,B[15]=1,this}makeRotationFromQuaternion(A){return this.compose(ht,A,bt)}lookAt(A,B,Q){let g=this.elements;return GB.subVectors(A,B),GB.lengthSq()===0&&(GB.z=1),GB.normalize(),pQ.crossVectors(Q,GB),pQ.lengthSq()===0&&(Math.abs(Q.z)===1?GB.x+=1e-4:GB.z+=1e-4,GB.normalize(),pQ.crossVectors(Q,GB)),pQ.normalize(),Vg.crossVectors(GB,pQ),g[0]=pQ.x,g[4]=Vg.x,g[8]=GB.x,g[1]=pQ.y,g[5]=Vg.y,g[9]=GB.y,g[2]=pQ.z,g[6]=Vg.z,g[10]=GB.z,this}multiply(A){return this.multiplyMatrices(this,A)}premultiply(A){return this.multiplyMatrices(A,this)}multiplyMatrices(A,B){let Q=A.elements,g=B.elements,v=this.elements,w=Q[0],f=Q[4],C=Q[8],e=Q[12],P=Q[1],D=Q[5],t=Q[9],n=Q[13],s=Q[2],i=Q[6],r=Q[10],I=Q[14],H=Q[3],o=Q[7],l=Q[11],F=Q[15],b=g[0],h=g[4],Z=g[8],a=g[12],u=g[1],y=g[5],q=g[9],EA=g[13],p=g[2],L=g[6],N=g[10],k=g[14],V=g[3],R=g[7],W=g[11],$=g[15];return v[0]=w*b+f*u+C*p+e*V,v[4]=w*h+f*y+C*L+e*R,v[8]=w*Z+f*q+C*N+e*W,v[12]=w*a+f*EA+C*k+e*$,v[1]=P*b+D*u+t*p+n*V,v[5]=P*h+D*y+t*L+n*R,v[9]=P*Z+D*q+t*N+n*W,v[13]=P*a+D*EA+t*k+n*$,v[2]=s*b+i*u+r*p+I*V,v[6]=s*h+i*y+r*L+I*R,v[10]=s*Z+i*q+r*N+I*W,v[14]=s*a+i*EA+r*k+I*$,v[3]=H*b+o*u+l*p+F*V,v[7]=H*h+o*y+l*L+F*R,v[11]=H*Z+o*q+l*N+F*W,v[15]=H*a+o*EA+l*k+F*$,this}multiplyScalar(A){let B=this.elements;return B[0]*=A,B[4]*=A,B[8]*=A,B[12]*=A,B[1]*=A,B[5]*=A,B[9]*=A,B[13]*=A,B[2]*=A,B[6]*=A,B[10]*=A,B[14]*=A,B[3]*=A,B[7]*=A,B[11]*=A,B[15]*=A,this}determinant(){let A=this.elements,B=A[0],Q=A[4],g=A[8],v=A[12],w=A[1],f=A[5],C=A[9],e=A[13],P=A[2],D=A[6],t=A[10],n=A[14],s=A[3],i=A[7],r=A[11],I=A[15];return s*(+v*C*D-g*e*D-v*f*t+Q*e*t+g*f*n-Q*C*n)+i*(+B*C*n-B*e*t+v*w*t-g*w*n+g*e*P-v*C*P)+r*(+B*e*D-B*f*n-v*w*D+Q*w*n+v*f*P-Q*e*P)+I*(-g*f*P-B*C*D+B*f*t+g*w*D-Q*w*t+Q*C*P)}transpose(){let A=this.elements,B;return B=A[1],A[1]=A[4],A[4]=B,B=A[2],A[2]=A[8],A[8]=B,B=A[6],A[6]=A[9],A[9]=B,B=A[3],A[3]=A[12],A[12]=B,B=A[7],A[7]=A[13],A[13]=B,B=A[11],A[11]=A[14],A[14]=B,this}setPosition(A,B,Q){let g=this.elements;return A.isVector3?(g[12]=A.x,g[13]=A.y,g[14]=A.z):(g[12]=A,g[13]=B,g[14]=Q),this}invert(){let A=this.elements,B=A[0],Q=A[1],g=A[2],v=A[3],w=A[4],f=A[5],C=A[6],e=A[7],P=A[8],D=A[9],t=A[10],n=A[11],s=A[12],i=A[13],r=A[14],I=A[15],H=D*r*e-i*t*e+i*C*n-f*r*n-D*C*I+f*t*I,o=s*t*e-P*r*e-s*C*n+w*r*n+P*C*I-w*t*I,l=P*i*e-s*D*e+s*f*n-w*i*n-P*f*I+w*D*I,F=s*D*C-P*i*C-s*f*t+w*i*t+P*f*r-w*D*r,b=B*H+Q*o+g*l+v*F;if(b===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let h=1/b;return A[0]=H*h,A[1]=(i*t*v-D*r*v-i*g*n+Q*r*n+D*g*I-Q*t*I)*h,A[2]=(f*r*v-i*C*v+i*g*e-Q*r*e-f*g*I+Q*C*I)*h,A[3]=(D*C*v-f*t*v-D*g*e+Q*t*e+f*g*n-Q*C*n)*h,A[4]=o*h,A[5]=(P*r*v-s*t*v+s*g*n-B*r*n-P*g*I+B*t*I)*h,A[6]=(s*C*v-w*r*v-s*g*e+B*r*e+w*g*I-B*C*I)*h,A[7]=(w*t*v-P*C*v+P*g*e-B*t*e-w*g*n+B*C*n)*h,A[8]=l*h,A[9]=(s*D*v-P*i*v-s*Q*n+B*i*n+P*Q*I-B*D*I)*h,A[10]=(w*i*v-s*f*v+s*Q*e-B*i*e-w*Q*I+B*f*I)*h,A[11]=(P*f*v-w*D*v-P*Q*e+B*D*e+w*Q*n-B*f*n)*h,A[12]=F*h,A[13]=(P*i*g-s*D*g+s*Q*t-B*i*t-P*Q*r+B*D*r)*h,A[14]=(s*f*g-w*i*g-s*Q*C+B*i*C+w*Q*r-B*f*r)*h,A[15]=(w*D*g-P*f*g+P*Q*C-B*D*C-w*Q*t+B*f*t)*h,this}scale(A){let B=this.elements,Q=A.x,g=A.y,v=A.z;return B[0]*=Q,B[4]*=g,B[8]*=v,B[1]*=Q,B[5]*=g,B[9]*=v,B[2]*=Q,B[6]*=g,B[10]*=v,B[3]*=Q,B[7]*=g,B[11]*=v,this}getMaxScaleOnAxis(){let A=this.elements,B=A[0]*A[0]+A[1]*A[1]+A[2]*A[2],Q=A[4]*A[4]+A[5]*A[5]+A[6]*A[6],g=A[8]*A[8]+A[9]*A[9]+A[10]*A[10];return Math.sqrt(Math.max(B,Q,g))}makeTranslation(A,B,Q){return A.isVector3?this.set(1,0,0,A.x,0,1,0,A.y,0,0,1,A.z,0,0,0,1):this.set(1,0,0,A,0,1,0,B,0,0,1,Q,0,0,0,1),this}makeRotationX(A){let B=Math.cos(A),Q=Math.sin(A);return this.set(1,0,0,0,0,B,-Q,0,0,Q,B,0,0,0,0,1),this}makeRotationY(A){let B=Math.cos(A),Q=Math.sin(A);return this.set(B,0,Q,0,0,1,0,0,-Q,0,B,0,0,0,0,1),this}makeRotationZ(A){let B=Math.cos(A),Q=Math.sin(A);return this.set(B,-Q,0,0,Q,B,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(A,B){let Q=Math.cos(B),g=Math.sin(B),v=1-Q,w=A.x,f=A.y,C=A.z,e=v*w,P=v*f;return this.set(e*w+Q,e*f-g*C,e*C+g*f,0,e*f+g*C,P*f+Q,P*C-g*w,0,e*C-g*f,P*C+g*w,v*C*C+Q,0,0,0,0,1),this}makeScale(A,B,Q){return this.set(A,0,0,0,0,B,0,0,0,0,Q,0,0,0,0,1),this}makeShear(A,B,Q,g,v,w){return this.set(1,Q,v,0,A,1,w,0,B,g,1,0,0,0,0,1),this}compose(A,B,Q){let g=this.elements,v=B._x,w=B._y,f=B._z,C=B._w,e=v+v,P=w+w,D=f+f,t=v*e,n=v*P,s=v*D,i=w*P,r=w*D,I=f*D,H=C*e,o=C*P,l=C*D,F=Q.x,b=Q.y,h=Q.z;return g[0]=(1-(i+I))*F,g[1]=(n+l)*F,g[2]=(s-o)*F,g[3]=0,g[4]=(n-l)*b,g[5]=(1-(t+I))*b,g[6]=(r+H)*b,g[7]=0,g[8]=(s+o)*h,g[9]=(r-H)*h,g[10]=(1-(t+i))*h,g[11]=0,g[12]=A.x,g[13]=A.y,g[14]=A.z,g[15]=1,this}decompose(A,B,Q){let g=this.elements,v=lE.set(g[0],g[1],g[2]).length(),w=lE.set(g[4],g[5],g[6]).length(),f=lE.set(g[8],g[9],g[10]).length();this.determinant()<0&&(v=-v),A.x=g[12],A.y=g[13],A.z=g[14],WB.copy(this);let e=1/v,P=1/w,D=1/f;return WB.elements[0]*=e,WB.elements[1]*=e,WB.elements[2]*=e,WB.elements[4]*=P,WB.elements[5]*=P,WB.elements[6]*=P,WB.elements[8]*=D,WB.elements[9]*=D,WB.elements[10]*=D,B.setFromRotationMatrix(WB),Q.x=v,Q.y=w,Q.z=f,this}makePerspective(A,B,Q,g,v,w,f=oQ){let C=this.elements,e=2*v/(B-A),P=2*v/(Q-g),D=(B+A)/(B-A),t=(Q+g)/(Q-g),n,s;if(f===oQ)n=-(w+v)/(w-v),s=-2*w*v/(w-v);else if(f===rv)n=-w/(w-v),s=-w*v/(w-v);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+f);return C[0]=e,C[4]=0,C[8]=D,C[12]=0,C[1]=0,C[5]=P,C[9]=t,C[13]=0,C[2]=0,C[6]=0,C[10]=n,C[14]=s,C[3]=0,C[7]=0,C[11]=-1,C[15]=0,this}makeOrthographic(A,B,Q,g,v,w,f=oQ){let C=this.elements,e=1/(B-A),P=1/(Q-g),D=1/(w-v),t=(B+A)*e,n=(Q+g)*P,s,i;if(f===oQ)s=(w+v)*D,i=-2*D;else if(f===rv)s=v*D,i=-1*D;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+f);return C[0]=2*e,C[4]=0,C[8]=0,C[12]=-t,C[1]=0,C[5]=2*P,C[9]=0,C[13]=-n,C[2]=0,C[6]=0,C[10]=i,C[14]=-s,C[3]=0,C[7]=0,C[11]=0,C[15]=1,this}equals(A){let B=this.elements,Q=A.elements;for(let g=0;g<16;g++)if(B[g]!==Q[g])return!1;return!0}fromArray(A,B=0){for(let Q=0;Q<16;Q++)this.elements[Q]=A[Q+B];return this}toArray(A=[],B=0){let Q=this.elements;return A[B]=Q[0],A[B+1]=Q[1],A[B+2]=Q[2],A[B+3]=Q[3],A[B+4]=Q[4],A[B+5]=Q[5],A[B+6]=Q[6],A[B+7]=Q[7],A[B+8]=Q[8],A[B+9]=Q[9],A[B+10]=Q[10],A[B+11]=Q[11],A[B+12]=Q[12],A[B+13]=Q[13],A[B+14]=Q[14],A[B+15]=Q[15],A}},lE=new x,WB=new fB,ht=new x(0,0,0),bt=new x(1,1,1),pQ=new x,Vg=new x,GB=new x,KC=new fB,_C=new _B,av=class E{constructor(A=0,B=0,Q=0,g=E.DEFAULT_ORDER){this.isEuler=!0,this._x=A,this._y=B,this._z=Q,this._order=g}get x(){return this._x}set x(A){this._x=A,this._onChangeCallback()}get y(){return this._y}set y(A){this._y=A,this._onChangeCallback()}get z(){return this._z}set z(A){this._z=A,this._onChangeCallback()}get order(){return this._order}set order(A){this._order=A,this._onChangeCallback()}set(A,B,Q,g=this._order){return this._x=A,this._y=B,this._z=Q,this._order=g,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(A){return this._x=A._x,this._y=A._y,this._z=A._z,this._order=A._order,this._onChangeCallback(),this}setFromRotationMatrix(A,B=this._order,Q=!0){let g=A.elements,v=g[0],w=g[4],f=g[8],C=g[1],e=g[5],P=g[9],D=g[2],t=g[6],n=g[10];switch(B){case"XYZ":this._y=Math.asin(aB(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-P,n),this._z=Math.atan2(-w,v)):(this._x=Math.atan2(t,e),this._z=0);break;case"YXZ":this._x=Math.asin(-aB(P,-1,1)),Math.abs(P)<.9999999?(this._y=Math.atan2(f,n),this._z=Math.atan2(C,e)):(this._y=Math.atan2(-D,v),this._z=0);break;case"ZXY":this._x=Math.asin(aB(t,-1,1)),Math.abs(t)<.9999999?(this._y=Math.atan2(-D,n),this._z=Math.atan2(-w,e)):(this._y=0,this._z=Math.atan2(C,v));break;case"ZYX":this._y=Math.asin(-aB(D,-1,1)),Math.abs(D)<.9999999?(this._x=Math.atan2(t,n),this._z=Math.atan2(C,v)):(this._x=0,this._z=Math.atan2(-w,e));break;case"YZX":this._z=Math.asin(aB(C,-1,1)),Math.abs(C)<.9999999?(this._x=Math.atan2(-P,e),this._y=Math.atan2(-D,v)):(this._x=0,this._y=Math.atan2(f,n));break;case"XZY":this._z=Math.asin(-aB(w,-1,1)),Math.abs(w)<.9999999?(this._x=Math.atan2(t,e),this._y=Math.atan2(f,v)):(this._x=Math.atan2(-P,n),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+B)}return this._order=B,Q===!0&&this._onChangeCallback(),this}setFromQuaternion(A,B,Q){return KC.makeRotationFromQuaternion(A),this.setFromRotationMatrix(KC,B,Q)}setFromVector3(A,B=this._order){return this.set(A.x,A.y,A.z,B)}reorder(A){return _C.setFromEuler(this),this.setFromQuaternion(_C,A)}equals(A){return A._x===this._x&&A._y===this._y&&A._z===this._z&&A._order===this._order}fromArray(A){return this._x=A[0],this._y=A[1],this._z=A[2],A[3]!==void 0&&(this._order=A[3]),this._onChangeCallback(),this}toArray(A=[],B=0){return A[B]=this._x,A[B+1]=this._y,A[B+2]=this._z,A[B+3]=this._order,A}_onChange(A){return this._onChangeCallback=A,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};av.DEFAULT_ORDER="XYZ";var cg=class{constructor(){this.mask=1}set(A){this.mask=(1<<A|0)>>>0}enable(A){this.mask|=1<<A|0}enableAll(){this.mask=-1}toggle(A){this.mask^=1<<A|0}disable(A){this.mask&=~(1<<A|0)}disableAll(){this.mask=0}test(A){return(this.mask&A.mask)!==0}isEnabled(A){return(this.mask&(1<<A|0))!==0}},mt=0,$C=new x,hE=new _B,rQ=new fB,kg=new x,Dg=new x,pt=new x,Ft=new _B,A7=new x(1,0,0),B7=new x(0,1,0),Q7=new x(0,0,1),xt={type:"added"},Gt={type:"removed"},iB=class E extends fQ{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:mt++}),this.uuid=_E(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=E.DEFAULT_UP.clone();let A=new x,B=new av,Q=new _B,g=new x(1,1,1);function v(){Q.setFromEuler(B,!1)}function w(){B.setFromQuaternion(Q,void 0,!1)}B._onChange(v),Q._onChange(w),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:A},rotation:{configurable:!0,enumerable:!0,value:B},quaternion:{configurable:!0,enumerable:!0,value:Q},scale:{configurable:!0,enumerable:!0,value:g},modelViewMatrix:{value:new fB},normalMatrix:{value:new NA}}),this.matrix=new fB,this.matrixWorld=new fB,this.matrixAutoUpdate=E.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=E.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new cg,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(A){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(A),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(A){return this.quaternion.premultiply(A),this}setRotationFromAxisAngle(A,B){this.quaternion.setFromAxisAngle(A,B)}setRotationFromEuler(A){this.quaternion.setFromEuler(A,!0)}setRotationFromMatrix(A){this.quaternion.setFromRotationMatrix(A)}setRotationFromQuaternion(A){this.quaternion.copy(A)}rotateOnAxis(A,B){return hE.setFromAxisAngle(A,B),this.quaternion.multiply(hE),this}rotateOnWorldAxis(A,B){return hE.setFromAxisAngle(A,B),this.quaternion.premultiply(hE),this}rotateX(A){return this.rotateOnAxis(A7,A)}rotateY(A){return this.rotateOnAxis(B7,A)}rotateZ(A){return this.rotateOnAxis(Q7,A)}translateOnAxis(A,B){return $C.copy(A).applyQuaternion(this.quaternion),this.position.add($C.multiplyScalar(B)),this}translateX(A){return this.translateOnAxis(A7,A)}translateY(A){return this.translateOnAxis(B7,A)}translateZ(A){return this.translateOnAxis(Q7,A)}localToWorld(A){return this.updateWorldMatrix(!0,!1),A.applyMatrix4(this.matrixWorld)}worldToLocal(A){return this.updateWorldMatrix(!0,!1),A.applyMatrix4(rQ.copy(this.matrixWorld).invert())}lookAt(A,B,Q){A.isVector3?kg.copy(A):kg.set(A,B,Q);let g=this.parent;this.updateWorldMatrix(!0,!1),Dg.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?rQ.lookAt(Dg,kg,this.up):rQ.lookAt(kg,Dg,this.up),this.quaternion.setFromRotationMatrix(rQ),g&&(rQ.extractRotation(g.matrixWorld),hE.setFromRotationMatrix(rQ),this.quaternion.premultiply(hE.invert()))}add(A){if(arguments.length>1){for(let B=0;B<arguments.length;B++)this.add(arguments[B]);return this}return A===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",A),this):(A&&A.isObject3D?(A.parent!==null&&A.parent.remove(A),A.parent=this,this.children.push(A),A.dispatchEvent(xt)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",A),this)}remove(A){if(arguments.length>1){for(let Q=0;Q<arguments.length;Q++)this.remove(arguments[Q]);return this}let B=this.children.indexOf(A);return B!==-1&&(A.parent=null,this.children.splice(B,1),A.dispatchEvent(Gt)),this}removeFromParent(){let A=this.parent;return A!==null&&A.remove(this),this}clear(){return this.remove(...this.children)}attach(A){return this.updateWorldMatrix(!0,!1),rQ.copy(this.matrixWorld).invert(),A.parent!==null&&(A.parent.updateWorldMatrix(!0,!1),rQ.multiply(A.parent.matrixWorld)),A.applyMatrix4(rQ),this.add(A),A.updateWorldMatrix(!1,!0),this}getObjectById(A){return this.getObjectByProperty("id",A)}getObjectByName(A){return this.getObjectByProperty("name",A)}getObjectByProperty(A,B){if(this[A]===B)return this;for(let Q=0,g=this.children.length;Q<g;Q++){let w=this.children[Q].getObjectByProperty(A,B);if(w!==void 0)return w}}getObjectsByProperty(A,B,Q=[]){this[A]===B&&Q.push(this);let g=this.children;for(let v=0,w=g.length;v<w;v++)g[v].getObjectsByProperty(A,B,Q);return Q}getWorldPosition(A){return this.updateWorldMatrix(!0,!1),A.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(A){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Dg,A,pt),A}getWorldScale(A){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Dg,Ft,A),A}getWorldDirection(A){this.updateWorldMatrix(!0,!1);let B=this.matrixWorld.elements;return A.set(B[8],B[9],B[10]).normalize()}raycast(){}traverse(A){A(this);let B=this.children;for(let Q=0,g=B.length;Q<g;Q++)B[Q].traverse(A)}traverseVisible(A){if(this.visible===!1)return;A(this);let B=this.children;for(let Q=0,g=B.length;Q<g;Q++)B[Q].traverseVisible(A)}traverseAncestors(A){let B=this.parent;B!==null&&(A(B),B.traverseAncestors(A))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(A){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||A)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,A=!0);let B=this.children;for(let Q=0,g=B.length;Q<g;Q++){let v=B[Q];(v.matrixWorldAutoUpdate===!0||A===!0)&&v.updateMatrixWorld(A)}}updateWorldMatrix(A,B){let Q=this.parent;if(A===!0&&Q!==null&&Q.matrixWorldAutoUpdate===!0&&Q.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),B===!0){let g=this.children;for(let v=0,w=g.length;v<w;v++){let f=g[v];f.matrixWorldAutoUpdate===!0&&f.updateWorldMatrix(!1,!0)}}}toJSON(A){let B=A===void 0||typeof A=="string",Q={};B&&(A={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},Q.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let g={};g.uuid=this.uuid,g.type=this.type,this.name!==""&&(g.name=this.name),this.castShadow===!0&&(g.castShadow=!0),this.receiveShadow===!0&&(g.receiveShadow=!0),this.visible===!1&&(g.visible=!1),this.frustumCulled===!1&&(g.frustumCulled=!1),this.renderOrder!==0&&(g.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(g.userData=this.userData),g.layers=this.layers.mask,g.matrix=this.matrix.toArray(),g.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(g.matrixAutoUpdate=!1),this.isInstancedMesh&&(g.type="InstancedMesh",g.count=this.count,g.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(g.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(g.type="BatchedMesh",g.perObjectFrustumCulled=this.perObjectFrustumCulled,g.sortObjects=this.sortObjects,g.drawRanges=this._drawRanges,g.reservedRanges=this._reservedRanges,g.visibility=this._visibility,g.active=this._active,g.bounds=this._bounds.map(f=>({boxInitialized:f.boxInitialized,boxMin:f.box.min.toArray(),boxMax:f.box.max.toArray(),sphereInitialized:f.sphereInitialized,sphereRadius:f.sphere.radius,sphereCenter:f.sphere.center.toArray()})),g.maxGeometryCount=this._maxGeometryCount,g.maxVertexCount=this._maxVertexCount,g.maxIndexCount=this._maxIndexCount,g.geometryInitialized=this._geometryInitialized,g.geometryCount=this._geometryCount,g.matricesTexture=this._matricesTexture.toJSON(A),this.boundingSphere!==null&&(g.boundingSphere={center:g.boundingSphere.center.toArray(),radius:g.boundingSphere.radius}),this.boundingBox!==null&&(g.boundingBox={min:g.boundingBox.min.toArray(),max:g.boundingBox.max.toArray()}));function v(f,C){return f[C.uuid]===void 0&&(f[C.uuid]=C.toJSON(A)),C.uuid}if(this.isScene)this.background&&(this.background.isColor?g.background=this.background.toJSON():this.background.isTexture&&(g.background=this.background.toJSON(A).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(g.environment=this.environment.toJSON(A).uuid);else if(this.isMesh||this.isLine||this.isPoints){g.geometry=v(A.geometries,this.geometry);let f=this.geometry.parameters;if(f!==void 0&&f.shapes!==void 0){let C=f.shapes;if(Array.isArray(C))for(let e=0,P=C.length;e<P;e++){let D=C[e];v(A.shapes,D)}else v(A.shapes,C)}}if(this.isSkinnedMesh&&(g.bindMode=this.bindMode,g.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(v(A.skeletons,this.skeleton),g.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let f=[];for(let C=0,e=this.material.length;C<e;C++)f.push(v(A.materials,this.material[C]));g.material=f}else g.material=v(A.materials,this.material);if(this.children.length>0){g.children=[];for(let f=0;f<this.children.length;f++)g.children.push(this.children[f].toJSON(A).object)}if(this.animations.length>0){g.animations=[];for(let f=0;f<this.animations.length;f++){let C=this.animations[f];g.animations.push(v(A.animations,C))}}if(B){let f=w(A.geometries),C=w(A.materials),e=w(A.textures),P=w(A.images),D=w(A.shapes),t=w(A.skeletons),n=w(A.animations),s=w(A.nodes);f.length>0&&(Q.geometries=f),C.length>0&&(Q.materials=C),e.length>0&&(Q.textures=e),P.length>0&&(Q.images=P),D.length>0&&(Q.shapes=D),t.length>0&&(Q.skeletons=t),n.length>0&&(Q.animations=n),s.length>0&&(Q.nodes=s)}return Q.object=g,Q;function w(f){let C=[];for(let e in f){let P=f[e];delete P.metadata,C.push(P)}return C}}clone(A){return new this.constructor().copy(this,A)}copy(A,B=!0){if(this.name=A.name,this.up.copy(A.up),this.position.copy(A.position),this.rotation.order=A.rotation.order,this.quaternion.copy(A.quaternion),this.scale.copy(A.scale),this.matrix.copy(A.matrix),this.matrixWorld.copy(A.matrixWorld),this.matrixAutoUpdate=A.matrixAutoUpdate,this.matrixWorldAutoUpdate=A.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=A.matrixWorldNeedsUpdate,this.layers.mask=A.layers.mask,this.visible=A.visible,this.castShadow=A.castShadow,this.receiveShadow=A.receiveShadow,this.frustumCulled=A.frustumCulled,this.renderOrder=A.renderOrder,this.animations=A.animations.slice(),this.userData=JSON.parse(JSON.stringify(A.userData)),B===!0)for(let Q=0;Q<A.children.length;Q++){let g=A.children[Q];this.add(g.clone())}return this}};iB.DEFAULT_UP=new x(0,1,0);iB.DEFAULT_MATRIX_AUTO_UPDATE=!0;iB.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var SB=new x,sQ=new x,df=new x,iQ=new x,bE=new x,mE=new x,E7=new x,lf=new x,hf=new x,bf=new x,qg=!1,TE=class E{constructor(A=new x,B=new x,Q=new x){this.a=A,this.b=B,this.c=Q}static getNormal(A,B,Q,g){g.subVectors(Q,B),SB.subVectors(A,B),g.cross(SB);let v=g.lengthSq();return v>0?g.multiplyScalar(1/Math.sqrt(v)):g.set(0,0,0)}static getBarycoord(A,B,Q,g,v){SB.subVectors(g,B),sQ.subVectors(Q,B),df.subVectors(A,B);let w=SB.dot(SB),f=SB.dot(sQ),C=SB.dot(df),e=sQ.dot(sQ),P=sQ.dot(df),D=w*e-f*f;if(D===0)return v.set(0,0,0),null;let t=1/D,n=(e*C-f*P)*t,s=(w*P-f*C)*t;return v.set(1-n-s,s,n)}static containsPoint(A,B,Q,g){return this.getBarycoord(A,B,Q,g,iQ)===null?!1:iQ.x>=0&&iQ.y>=0&&iQ.x+iQ.y<=1}static getUV(A,B,Q,g,v,w,f,C){return qg===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),qg=!0),this.getInterpolation(A,B,Q,g,v,w,f,C)}static getInterpolation(A,B,Q,g,v,w,f,C){return this.getBarycoord(A,B,Q,g,iQ)===null?(C.x=0,C.y=0,"z"in C&&(C.z=0),"w"in C&&(C.w=0),null):(C.setScalar(0),C.addScaledVector(v,iQ.x),C.addScaledVector(w,iQ.y),C.addScaledVector(f,iQ.z),C)}static isFrontFacing(A,B,Q,g){return SB.subVectors(Q,B),sQ.subVectors(A,B),SB.cross(sQ).dot(g)<0}set(A,B,Q){return this.a.copy(A),this.b.copy(B),this.c.copy(Q),this}setFromPointsAndIndices(A,B,Q,g){return this.a.copy(A[B]),this.b.copy(A[Q]),this.c.copy(A[g]),this}setFromAttributeAndIndices(A,B,Q,g){return this.a.fromBufferAttribute(A,B),this.b.fromBufferAttribute(A,Q),this.c.fromBufferAttribute(A,g),this}clone(){return new this.constructor().copy(this)}copy(A){return this.a.copy(A.a),this.b.copy(A.b),this.c.copy(A.c),this}getArea(){return SB.subVectors(this.c,this.b),sQ.subVectors(this.a,this.b),SB.cross(sQ).length()*.5}getMidpoint(A){return A.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(A){return E.getNormal(this.a,this.b,this.c,A)}getPlane(A){return A.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(A,B){return E.getBarycoord(A,this.a,this.b,this.c,B)}getUV(A,B,Q,g,v){return qg===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),qg=!0),E.getInterpolation(A,this.a,this.b,this.c,B,Q,g,v)}getInterpolation(A,B,Q,g,v){return E.getInterpolation(A,this.a,this.b,this.c,B,Q,g,v)}containsPoint(A){return E.containsPoint(A,this.a,this.b,this.c)}isFrontFacing(A){return E.isFrontFacing(this.a,this.b,this.c,A)}intersectsBox(A){return A.intersectsTriangle(this)}closestPointToPoint(A,B){let Q=this.a,g=this.b,v=this.c,w,f;bE.subVectors(g,Q),mE.subVectors(v,Q),lf.subVectors(A,Q);let C=bE.dot(lf),e=mE.dot(lf);if(C<=0&&e<=0)return B.copy(Q);hf.subVectors(A,g);let P=bE.dot(hf),D=mE.dot(hf);if(P>=0&&D<=P)return B.copy(g);let t=C*D-P*e;if(t<=0&&C>=0&&P<=0)return w=C/(C-P),B.copy(Q).addScaledVector(bE,w);bf.subVectors(A,v);let n=bE.dot(bf),s=mE.dot(bf);if(s>=0&&n<=s)return B.copy(v);let i=n*e-C*s;if(i<=0&&e>=0&&s<=0)return f=e/(e-s),B.copy(Q).addScaledVector(mE,f);let r=P*s-n*D;if(r<=0&&D-P>=0&&n-s>=0)return E7.subVectors(v,g),f=(D-P)/(D-P+(n-s)),B.copy(g).addScaledVector(E7,f);let I=1/(r+i+t);return w=i*I,f=t*I,B.copy(Q).addScaledVector(bE,w).addScaledVector(mE,f)}equals(A){return A.a.equals(this.a)&&A.b.equals(this.b)&&A.c.equals(this.c)}},K7={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},FQ={h:0,s:0,l:0},Jg={h:0,s:0,l:0};function mf(E,A,B){return B<0&&(B+=1),B>1&&(B-=1),B<1/6?E+(A-E)*6*B:B<1/2?A:B<2/3?E+(A-E)*6*(2/3-B):E}var lA=class{constructor(A,B,Q){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(A,B,Q)}set(A,B,Q){if(B===void 0&&Q===void 0){let g=A;g&&g.isColor?this.copy(g):typeof g=="number"?this.setHex(g):typeof g=="string"&&this.setStyle(g)}else this.setRGB(A,B,Q);return this}setScalar(A){return this.r=A,this.g=A,this.b=A,this}setHex(A,B=eB){return A=Math.floor(A),this.r=(A>>16&255)/255,this.g=(A>>8&255)/255,this.b=(A&255)/255,KA.toWorkingColorSpace(this,B),this}setRGB(A,B,Q,g=KA.workingColorSpace){return this.r=A,this.g=B,this.b=Q,KA.toWorkingColorSpace(this,g),this}setHSL(A,B,Q,g=KA.workingColorSpace){if(A=dw(A,1),B=aB(B,0,1),Q=aB(Q,0,1),B===0)this.r=this.g=this.b=Q;else{let v=Q<=.5?Q*(1+B):Q+B-Q*B,w=2*Q-v;this.r=mf(w,v,A+1/3),this.g=mf(w,v,A),this.b=mf(w,v,A-1/3)}return KA.toWorkingColorSpace(this,g),this}setStyle(A,B=eB){function Q(v){v!==void 0&&parseFloat(v)<1&&console.warn("THREE.Color: Alpha component of "+A+" will be ignored.")}let g;if(g=/^(\w+)\(([^\)]*)\)/.exec(A)){let v,w=g[1],f=g[2];switch(w){case"rgb":case"rgba":if(v=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return Q(v[4]),this.setRGB(Math.min(255,parseInt(v[1],10))/255,Math.min(255,parseInt(v[2],10))/255,Math.min(255,parseInt(v[3],10))/255,B);if(v=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return Q(v[4]),this.setRGB(Math.min(100,parseInt(v[1],10))/100,Math.min(100,parseInt(v[2],10))/100,Math.min(100,parseInt(v[3],10))/100,B);break;case"hsl":case"hsla":if(v=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return Q(v[4]),this.setHSL(parseFloat(v[1])/360,parseFloat(v[2])/100,parseFloat(v[3])/100,B);break;default:console.warn("THREE.Color: Unknown color model "+A)}}else if(g=/^\#([A-Fa-f\d]+)$/.exec(A)){let v=g[1],w=v.length;if(w===3)return this.setRGB(parseInt(v.charAt(0),16)/15,parseInt(v.charAt(1),16)/15,parseInt(v.charAt(2),16)/15,B);if(w===6)return this.setHex(parseInt(v,16),B);console.warn("THREE.Color: Invalid hex color "+A)}else if(A&&A.length>0)return this.setColorName(A,B);return this}setColorName(A,B=eB){let Q=K7[A.toLowerCase()];return Q!==void 0?this.setHex(Q,B):console.warn("THREE.Color: Unknown color "+A),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(A){return this.r=A.r,this.g=A.g,this.b=A.b,this}copySRGBToLinear(A){return this.r=NE(A.r),this.g=NE(A.g),this.b=NE(A.b),this}copyLinearToSRGB(A){return this.r=sf(A.r),this.g=sf(A.g),this.b=sf(A.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(A=eB){return KA.fromWorkingColorSpace(cB.copy(this),A),Math.round(aB(cB.r*255,0,255))*65536+Math.round(aB(cB.g*255,0,255))*256+Math.round(aB(cB.b*255,0,255))}getHexString(A=eB){return("000000"+this.getHex(A).toString(16)).slice(-6)}getHSL(A,B=KA.workingColorSpace){KA.fromWorkingColorSpace(cB.copy(this),B);let Q=cB.r,g=cB.g,v=cB.b,w=Math.max(Q,g,v),f=Math.min(Q,g,v),C,e,P=(f+w)/2;if(f===w)C=0,e=0;else{let D=w-f;switch(e=P<=.5?D/(w+f):D/(2-w-f),w){case Q:C=(g-v)/D+(g<v?6:0);break;case g:C=(v-Q)/D+2;break;case v:C=(Q-g)/D+4;break}C/=6}return A.h=C,A.s=e,A.l=P,A}getRGB(A,B=KA.workingColorSpace){return KA.fromWorkingColorSpace(cB.copy(this),B),A.r=cB.r,A.g=cB.g,A.b=cB.b,A}getStyle(A=eB){KA.fromWorkingColorSpace(cB.copy(this),A);let B=cB.r,Q=cB.g,g=cB.b;return A!==eB?`color(${A} ${B.toFixed(3)} ${Q.toFixed(3)} ${g.toFixed(3)})`:`rgb(${Math.round(B*255)},${Math.round(Q*255)},${Math.round(g*255)})`}offsetHSL(A,B,Q){return this.getHSL(FQ),this.setHSL(FQ.h+A,FQ.s+B,FQ.l+Q)}add(A){return this.r+=A.r,this.g+=A.g,this.b+=A.b,this}addColors(A,B){return this.r=A.r+B.r,this.g=A.g+B.g,this.b=A.b+B.b,this}addScalar(A){return this.r+=A,this.g+=A,this.b+=A,this}sub(A){return this.r=Math.max(0,this.r-A.r),this.g=Math.max(0,this.g-A.g),this.b=Math.max(0,this.b-A.b),this}multiply(A){return this.r*=A.r,this.g*=A.g,this.b*=A.b,this}multiplyScalar(A){return this.r*=A,this.g*=A,this.b*=A,this}lerp(A,B){return this.r+=(A.r-this.r)*B,this.g+=(A.g-this.g)*B,this.b+=(A.b-this.b)*B,this}lerpColors(A,B,Q){return this.r=A.r+(B.r-A.r)*Q,this.g=A.g+(B.g-A.g)*Q,this.b=A.b+(B.b-A.b)*Q,this}lerpHSL(A,B){this.getHSL(FQ),A.getHSL(Jg);let Q=rg(FQ.h,Jg.h,B),g=rg(FQ.s,Jg.s,B),v=rg(FQ.l,Jg.l,B);return this.setHSL(Q,g,v),this}setFromVector3(A){return this.r=A.x,this.g=A.y,this.b=A.z,this}applyMatrix3(A){let B=this.r,Q=this.g,g=this.b,v=A.elements;return this.r=v[0]*B+v[3]*Q+v[6]*g,this.g=v[1]*B+v[4]*Q+v[7]*g,this.b=v[2]*B+v[5]*Q+v[8]*g,this}equals(A){return A.r===this.r&&A.g===this.g&&A.b===this.b}fromArray(A,B=0){return this.r=A[B],this.g=A[B+1],this.b=A[B+2],this}toArray(A=[],B=0){return A[B]=this.r,A[B+1]=this.g,A[B+2]=this.b,A}fromBufferAttribute(A,B){return this.r=A.getX(B),this.g=A.getY(B),this.b=A.getZ(B),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},cB=new lA;lA.NAMES=K7;var Lt=0,jQ=class extends fQ{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Lt++}),this.uuid=_E(),this.name="",this.type="Material",this.blending=OE,this.side=YQ,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=yf,this.blendDst=Of,this.blendEquation=_Q,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new lA(0,0,0),this.blendAlpha=0,this.depthFunc=ev,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=RC,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=aE,this.stencilZFail=aE,this.stencilZPass=aE,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(A){this._alphaTest>0!=A>0&&this.version++,this._alphaTest=A}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(A){if(A!==void 0)for(let B in A){let Q=A[B];if(Q===void 0){console.warn(`THREE.Material: parameter '${B}' has value of undefined.`);continue}let g=this[B];if(g===void 0){console.warn(`THREE.Material: '${B}' is not a property of THREE.${this.type}.`);continue}g&&g.isColor?g.set(Q):g&&g.isVector3&&Q&&Q.isVector3?g.copy(Q):this[B]=Q}}toJSON(A){let B=A===void 0||typeof A=="string";B&&(A={textures:{},images:{}});let Q={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};Q.uuid=this.uuid,Q.type=this.type,this.name!==""&&(Q.name=this.name),this.color&&this.color.isColor&&(Q.color=this.color.getHex()),this.roughness!==void 0&&(Q.roughness=this.roughness),this.metalness!==void 0&&(Q.metalness=this.metalness),this.sheen!==void 0&&(Q.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(Q.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(Q.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(Q.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(Q.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(Q.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(Q.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(Q.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(Q.shininess=this.shininess),this.clearcoat!==void 0&&(Q.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(Q.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(Q.clearcoatMap=this.clearcoatMap.toJSON(A).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(Q.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(A).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(Q.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(A).uuid,Q.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(Q.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(Q.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(Q.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(Q.iridescenceMap=this.iridescenceMap.toJSON(A).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(Q.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(A).uuid),this.anisotropy!==void 0&&(Q.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(Q.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(Q.anisotropyMap=this.anisotropyMap.toJSON(A).uuid),this.map&&this.map.isTexture&&(Q.map=this.map.toJSON(A).uuid),this.matcap&&this.matcap.isTexture&&(Q.matcap=this.matcap.toJSON(A).uuid),this.alphaMap&&this.alphaMap.isTexture&&(Q.alphaMap=this.alphaMap.toJSON(A).uuid),this.lightMap&&this.lightMap.isTexture&&(Q.lightMap=this.lightMap.toJSON(A).uuid,Q.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(Q.aoMap=this.aoMap.toJSON(A).uuid,Q.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(Q.bumpMap=this.bumpMap.toJSON(A).uuid,Q.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(Q.normalMap=this.normalMap.toJSON(A).uuid,Q.normalMapType=this.normalMapType,Q.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(Q.displacementMap=this.displacementMap.toJSON(A).uuid,Q.displacementScale=this.displacementScale,Q.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(Q.roughnessMap=this.roughnessMap.toJSON(A).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(Q.metalnessMap=this.metalnessMap.toJSON(A).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(Q.emissiveMap=this.emissiveMap.toJSON(A).uuid),this.specularMap&&this.specularMap.isTexture&&(Q.specularMap=this.specularMap.toJSON(A).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(Q.specularIntensityMap=this.specularIntensityMap.toJSON(A).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(Q.specularColorMap=this.specularColorMap.toJSON(A).uuid),this.envMap&&this.envMap.isTexture&&(Q.envMap=this.envMap.toJSON(A).uuid,this.combine!==void 0&&(Q.combine=this.combine)),this.envMapIntensity!==void 0&&(Q.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(Q.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(Q.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(Q.gradientMap=this.gradientMap.toJSON(A).uuid),this.transmission!==void 0&&(Q.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(Q.transmissionMap=this.transmissionMap.toJSON(A).uuid),this.thickness!==void 0&&(Q.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(Q.thicknessMap=this.thicknessMap.toJSON(A).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(Q.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(Q.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(Q.size=this.size),this.shadowSide!==null&&(Q.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(Q.sizeAttenuation=this.sizeAttenuation),this.blending!==OE&&(Q.blending=this.blending),this.side!==YQ&&(Q.side=this.side),this.vertexColors===!0&&(Q.vertexColors=!0),this.opacity<1&&(Q.opacity=this.opacity),this.transparent===!0&&(Q.transparent=!0),this.blendSrc!==yf&&(Q.blendSrc=this.blendSrc),this.blendDst!==Of&&(Q.blendDst=this.blendDst),this.blendEquation!==_Q&&(Q.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(Q.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(Q.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(Q.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(Q.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(Q.blendAlpha=this.blendAlpha),this.depthFunc!==ev&&(Q.depthFunc=this.depthFunc),this.depthTest===!1&&(Q.depthTest=this.depthTest),this.depthWrite===!1&&(Q.depthWrite=this.depthWrite),this.colorWrite===!1&&(Q.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(Q.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==RC&&(Q.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(Q.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(Q.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==aE&&(Q.stencilFail=this.stencilFail),this.stencilZFail!==aE&&(Q.stencilZFail=this.stencilZFail),this.stencilZPass!==aE&&(Q.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(Q.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(Q.rotation=this.rotation),this.polygonOffset===!0&&(Q.polygonOffset=!0),this.polygonOffsetFactor!==0&&(Q.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(Q.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(Q.linewidth=this.linewidth),this.dashSize!==void 0&&(Q.dashSize=this.dashSize),this.gapSize!==void 0&&(Q.gapSize=this.gapSize),this.scale!==void 0&&(Q.scale=this.scale),this.dithering===!0&&(Q.dithering=!0),this.alphaTest>0&&(Q.alphaTest=this.alphaTest),this.alphaHash===!0&&(Q.alphaHash=!0),this.alphaToCoverage===!0&&(Q.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(Q.premultipliedAlpha=!0),this.forceSinglePass===!0&&(Q.forceSinglePass=!0),this.wireframe===!0&&(Q.wireframe=!0),this.wireframeLinewidth>1&&(Q.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(Q.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(Q.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(Q.flatShading=!0),this.visible===!1&&(Q.visible=!1),this.toneMapped===!1&&(Q.toneMapped=!1),this.fog===!1&&(Q.fog=!1),Object.keys(this.userData).length>0&&(Q.userData=this.userData);function g(v){let w=[];for(let f in v){let C=v[f];delete C.metadata,w.push(C)}return w}if(B){let v=g(A.textures),w=g(A.images);v.length>0&&(Q.textures=v),w.length>0&&(Q.images=w)}return Q}clone(){return new this.constructor().copy(this)}copy(A){this.name=A.name,this.blending=A.blending,this.side=A.side,this.vertexColors=A.vertexColors,this.opacity=A.opacity,this.transparent=A.transparent,this.blendSrc=A.blendSrc,this.blendDst=A.blendDst,this.blendEquation=A.blendEquation,this.blendSrcAlpha=A.blendSrcAlpha,this.blendDstAlpha=A.blendDstAlpha,this.blendEquationAlpha=A.blendEquationAlpha,this.blendColor.copy(A.blendColor),this.blendAlpha=A.blendAlpha,this.depthFunc=A.depthFunc,this.depthTest=A.depthTest,this.depthWrite=A.depthWrite,this.stencilWriteMask=A.stencilWriteMask,this.stencilFunc=A.stencilFunc,this.stencilRef=A.stencilRef,this.stencilFuncMask=A.stencilFuncMask,this.stencilFail=A.stencilFail,this.stencilZFail=A.stencilZFail,this.stencilZPass=A.stencilZPass,this.stencilWrite=A.stencilWrite;let B=A.clippingPlanes,Q=null;if(B!==null){let g=B.length;Q=new Array(g);for(let v=0;v!==g;++v)Q[v]=B[v].clone()}return this.clippingPlanes=Q,this.clipIntersection=A.clipIntersection,this.clipShadows=A.clipShadows,this.shadowSide=A.shadowSide,this.colorWrite=A.colorWrite,this.precision=A.precision,this.polygonOffset=A.polygonOffset,this.polygonOffsetFactor=A.polygonOffsetFactor,this.polygonOffsetUnits=A.polygonOffsetUnits,this.dithering=A.dithering,this.alphaTest=A.alphaTest,this.alphaHash=A.alphaHash,this.alphaToCoverage=A.alphaToCoverage,this.premultipliedAlpha=A.premultipliedAlpha,this.forceSinglePass=A.forceSinglePass,this.visible=A.visible,this.toneMapped=A.toneMapped,this.userData=JSON.parse(JSON.stringify(A.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(A){A===!0&&this.version++}},JE=class extends jQ{constructor(A){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new lA(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Y7,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(A)}copy(A){return super.copy(A),this.color.copy(A.color),this.map=A.map,this.lightMap=A.lightMap,this.lightMapIntensity=A.lightMapIntensity,this.aoMap=A.aoMap,this.aoMapIntensity=A.aoMapIntensity,this.specularMap=A.specularMap,this.alphaMap=A.alphaMap,this.envMap=A.envMap,this.combine=A.combine,this.reflectivity=A.reflectivity,this.refractionRatio=A.refractionRatio,this.wireframe=A.wireframe,this.wireframeLinewidth=A.wireframeLinewidth,this.wireframeLinecap=A.wireframeLinecap,this.wireframeLinejoin=A.wireframeLinejoin,this.fog=A.fog,this}};var CB=new x,Wg=new hA,NB=class{constructor(A,B,Q=!1){if(Array.isArray(A))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=A,this.itemSize=B,this.count=A!==void 0?A.length/B:0,this.normalized=Q,this.usage=ZC,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=GQ,this.version=0}onUploadCallback(){}set needsUpdate(A){A===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(A){return this.usage=A,this}addUpdateRange(A,B){this.updateRanges.push({start:A,count:B})}clearUpdateRanges(){this.updateRanges.length=0}copy(A){return this.name=A.name,this.array=new A.array.constructor(A.array),this.itemSize=A.itemSize,this.count=A.count,this.normalized=A.normalized,this.usage=A.usage,this.gpuType=A.gpuType,this}copyAt(A,B,Q){A*=this.itemSize,Q*=B.itemSize;for(let g=0,v=this.itemSize;g<v;g++)this.array[A+g]=B.array[Q+g];return this}copyArray(A){return this.array.set(A),this}applyMatrix3(A){if(this.itemSize===2)for(let B=0,Q=this.count;B<Q;B++)Wg.fromBufferAttribute(this,B),Wg.applyMatrix3(A),this.setXY(B,Wg.x,Wg.y);else if(this.itemSize===3)for(let B=0,Q=this.count;B<Q;B++)CB.fromBufferAttribute(this,B),CB.applyMatrix3(A),this.setXYZ(B,CB.x,CB.y,CB.z);return this}applyMatrix4(A){for(let B=0,Q=this.count;B<Q;B++)CB.fromBufferAttribute(this,B),CB.applyMatrix4(A),this.setXYZ(B,CB.x,CB.y,CB.z);return this}applyNormalMatrix(A){for(let B=0,Q=this.count;B<Q;B++)CB.fromBufferAttribute(this,B),CB.applyNormalMatrix(A),this.setXYZ(B,CB.x,CB.y,CB.z);return this}transformDirection(A){for(let B=0,Q=this.count;B<Q;B++)CB.fromBufferAttribute(this,B),CB.transformDirection(A),this.setXYZ(B,CB.x,CB.y,CB.z);return this}set(A,B=0){return this.array.set(A,B),this}getComponent(A,B){let Q=this.array[A*this.itemSize+B];return this.normalized&&(Q=YE(Q,this.array)),Q}setComponent(A,B,Q){return this.normalized&&(Q=dB(Q,this.array)),this.array[A*this.itemSize+B]=Q,this}getX(A){let B=this.array[A*this.itemSize];return this.normalized&&(B=YE(B,this.array)),B}setX(A,B){return this.normalized&&(B=dB(B,this.array)),this.array[A*this.itemSize]=B,this}getY(A){let B=this.array[A*this.itemSize+1];return this.normalized&&(B=YE(B,this.array)),B}setY(A,B){return this.normalized&&(B=dB(B,this.array)),this.array[A*this.itemSize+1]=B,this}getZ(A){let B=this.array[A*this.itemSize+2];return this.normalized&&(B=YE(B,this.array)),B}setZ(A,B){return this.normalized&&(B=dB(B,this.array)),this.array[A*this.itemSize+2]=B,this}getW(A){let B=this.array[A*this.itemSize+3];return this.normalized&&(B=YE(B,this.array)),B}setW(A,B){return this.normalized&&(B=dB(B,this.array)),this.array[A*this.itemSize+3]=B,this}setXY(A,B,Q){return A*=this.itemSize,this.normalized&&(B=dB(B,this.array),Q=dB(Q,this.array)),this.array[A+0]=B,this.array[A+1]=Q,this}setXYZ(A,B,Q,g){return A*=this.itemSize,this.normalized&&(B=dB(B,this.array),Q=dB(Q,this.array),g=dB(g,this.array)),this.array[A+0]=B,this.array[A+1]=Q,this.array[A+2]=g,this}setXYZW(A,B,Q,g,v){return A*=this.itemSize,this.normalized&&(B=dB(B,this.array),Q=dB(Q,this.array),g=dB(g,this.array),v=dB(v,this.array)),this.array[A+0]=B,this.array[A+1]=Q,this.array[A+2]=g,this.array[A+3]=v,this}onUpload(A){return this.onUploadCallback=A,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let A={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(A.name=this.name),this.usage!==ZC&&(A.usage=this.usage),A}};var zv=class extends NB{constructor(A,B,Q){super(new Uint16Array(A),B,Q)}};var Hv=class extends NB{constructor(A,B,Q){super(new Uint32Array(A),B,Q)}};var XB=class extends NB{constructor(A,B,Q){super(new Float32Array(A),B,Q)}};var Ut=0,jB=new fB,pf=new iB,pE=new x,LB=new EE,Ig=new EE,rB=new x,YB=class E extends fQ{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Ut++}),this.uuid=_E(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(A){return Array.isArray(A)?this.index=new(S7(A)?Hv:zv)(A,1):this.index=A,this}getAttribute(A){return this.attributes[A]}setAttribute(A,B){return this.attributes[A]=B,this}deleteAttribute(A){return delete this.attributes[A],this}hasAttribute(A){return this.attributes[A]!==void 0}addGroup(A,B,Q=0){this.groups.push({start:A,count:B,materialIndex:Q})}clearGroups(){this.groups=[]}setDrawRange(A,B){this.drawRange.start=A,this.drawRange.count=B}applyMatrix4(A){let B=this.attributes.position;B!==void 0&&(B.applyMatrix4(A),B.needsUpdate=!0);let Q=this.attributes.normal;if(Q!==void 0){let v=new NA().getNormalMatrix(A);Q.applyNormalMatrix(v),Q.needsUpdate=!0}let g=this.attributes.tangent;return g!==void 0&&(g.transformDirection(A),g.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(A){return jB.makeRotationFromQuaternion(A),this.applyMatrix4(jB),this}rotateX(A){return jB.makeRotationX(A),this.applyMatrix4(jB),this}rotateY(A){return jB.makeRotationY(A),this.applyMatrix4(jB),this}rotateZ(A){return jB.makeRotationZ(A),this.applyMatrix4(jB),this}translate(A,B,Q){return jB.makeTranslation(A,B,Q),this.applyMatrix4(jB),this}scale(A,B,Q){return jB.makeScale(A,B,Q),this.applyMatrix4(jB),this}lookAt(A){return pf.lookAt(A),pf.updateMatrix(),this.applyMatrix4(pf.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(pE).negate(),this.translate(pE.x,pE.y,pE.z),this}setFromPoints(A){let B=[];for(let Q=0,g=A.length;Q<g;Q++){let v=A[Q];B.push(v.x,v.y,v.z||0)}return this.setAttribute("position",new XB(B,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new EE);let A=this.attributes.position,B=this.morphAttributes.position;if(A&&A.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new x(-1/0,-1/0,-1/0),new x(1/0,1/0,1/0));return}if(A!==void 0){if(this.boundingBox.setFromBufferAttribute(A),B)for(let Q=0,g=B.length;Q<g;Q++){let v=B[Q];LB.setFromBufferAttribute(v),this.morphTargetsRelative?(rB.addVectors(this.boundingBox.min,LB.min),this.boundingBox.expandByPoint(rB),rB.addVectors(this.boundingBox.max,LB.max),this.boundingBox.expandByPoint(rB)):(this.boundingBox.expandByPoint(LB.min),this.boundingBox.expandByPoint(LB.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new qE);let A=this.attributes.position,B=this.morphAttributes.position;if(A&&A.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new x,1/0);return}if(A){let Q=this.boundingSphere.center;if(LB.setFromBufferAttribute(A),B)for(let v=0,w=B.length;v<w;v++){let f=B[v];Ig.setFromBufferAttribute(f),this.morphTargetsRelative?(rB.addVectors(LB.min,Ig.min),LB.expandByPoint(rB),rB.addVectors(LB.max,Ig.max),LB.expandByPoint(rB)):(LB.expandByPoint(Ig.min),LB.expandByPoint(Ig.max))}LB.getCenter(Q);let g=0;for(let v=0,w=A.count;v<w;v++)rB.fromBufferAttribute(A,v),g=Math.max(g,Q.distanceToSquared(rB));if(B)for(let v=0,w=B.length;v<w;v++){let f=B[v],C=this.morphTargetsRelative;for(let e=0,P=f.count;e<P;e++)rB.fromBufferAttribute(f,e),C&&(pE.fromBufferAttribute(A,e),rB.add(pE)),g=Math.max(g,Q.distanceToSquared(rB))}this.boundingSphere.radius=Math.sqrt(g),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let A=this.index,B=this.attributes;if(A===null||B.position===void 0||B.normal===void 0||B.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let Q=A.array,g=B.position.array,v=B.normal.array,w=B.uv.array,f=g.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new NB(new Float32Array(4*f),4));let C=this.getAttribute("tangent").array,e=[],P=[];for(let u=0;u<f;u++)e[u]=new x,P[u]=new x;let D=new x,t=new x,n=new x,s=new hA,i=new hA,r=new hA,I=new x,H=new x;function o(u,y,q){D.fromArray(g,u*3),t.fromArray(g,y*3),n.fromArray(g,q*3),s.fromArray(w,u*2),i.fromArray(w,y*2),r.fromArray(w,q*2),t.sub(D),n.sub(D),i.sub(s),r.sub(s);let EA=1/(i.x*r.y-r.x*i.y);isFinite(EA)&&(I.copy(t).multiplyScalar(r.y).addScaledVector(n,-i.y).multiplyScalar(EA),H.copy(n).multiplyScalar(i.x).addScaledVector(t,-r.x).multiplyScalar(EA),e[u].add(I),e[y].add(I),e[q].add(I),P[u].add(H),P[y].add(H),P[q].add(H))}let l=this.groups;l.length===0&&(l=[{start:0,count:Q.length}]);for(let u=0,y=l.length;u<y;++u){let q=l[u],EA=q.start,p=q.count;for(let L=EA,N=EA+p;L<N;L+=3)o(Q[L+0],Q[L+1],Q[L+2])}let F=new x,b=new x,h=new x,Z=new x;function a(u){h.fromArray(v,u*3),Z.copy(h);let y=e[u];F.copy(y),F.sub(h.multiplyScalar(h.dot(y))).normalize(),b.crossVectors(Z,y);let EA=b.dot(P[u])<0?-1:1;C[u*4]=F.x,C[u*4+1]=F.y,C[u*4+2]=F.z,C[u*4+3]=EA}for(let u=0,y=l.length;u<y;++u){let q=l[u],EA=q.start,p=q.count;for(let L=EA,N=EA+p;L<N;L+=3)a(Q[L+0]),a(Q[L+1]),a(Q[L+2])}}computeVertexNormals(){let A=this.index,B=this.getAttribute("position");if(B!==void 0){let Q=this.getAttribute("normal");if(Q===void 0)Q=new NB(new Float32Array(B.count*3),3),this.setAttribute("normal",Q);else for(let t=0,n=Q.count;t<n;t++)Q.setXYZ(t,0,0,0);let g=new x,v=new x,w=new x,f=new x,C=new x,e=new x,P=new x,D=new x;if(A)for(let t=0,n=A.count;t<n;t+=3){let s=A.getX(t+0),i=A.getX(t+1),r=A.getX(t+2);g.fromBufferAttribute(B,s),v.fromBufferAttribute(B,i),w.fromBufferAttribute(B,r),P.subVectors(w,v),D.subVectors(g,v),P.cross(D),f.fromBufferAttribute(Q,s),C.fromBufferAttribute(Q,i),e.fromBufferAttribute(Q,r),f.add(P),C.add(P),e.add(P),Q.setXYZ(s,f.x,f.y,f.z),Q.setXYZ(i,C.x,C.y,C.z),Q.setXYZ(r,e.x,e.y,e.z)}else for(let t=0,n=B.count;t<n;t+=3)g.fromBufferAttribute(B,t+0),v.fromBufferAttribute(B,t+1),w.fromBufferAttribute(B,t+2),P.subVectors(w,v),D.subVectors(g,v),P.cross(D),Q.setXYZ(t+0,P.x,P.y,P.z),Q.setXYZ(t+1,P.x,P.y,P.z),Q.setXYZ(t+2,P.x,P.y,P.z);this.normalizeNormals(),Q.needsUpdate=!0}}normalizeNormals(){let A=this.attributes.normal;for(let B=0,Q=A.count;B<Q;B++)rB.fromBufferAttribute(A,B),rB.normalize(),A.setXYZ(B,rB.x,rB.y,rB.z)}toNonIndexed(){function A(f,C){let e=f.array,P=f.itemSize,D=f.normalized,t=new e.constructor(C.length*P),n=0,s=0;for(let i=0,r=C.length;i<r;i++){f.isInterleavedBufferAttribute?n=C[i]*f.data.stride+f.offset:n=C[i]*P;for(let I=0;I<P;I++)t[s++]=e[n++]}return new NB(t,P,D)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let B=new E,Q=this.index.array,g=this.attributes;for(let f in g){let C=g[f],e=A(C,Q);B.setAttribute(f,e)}let v=this.morphAttributes;for(let f in v){let C=[],e=v[f];for(let P=0,D=e.length;P<D;P++){let t=e[P],n=A(t,Q);C.push(n)}B.morphAttributes[f]=C}B.morphTargetsRelative=this.morphTargetsRelative;let w=this.groups;for(let f=0,C=w.length;f<C;f++){let e=w[f];B.addGroup(e.start,e.count,e.materialIndex)}return B}toJSON(){let A={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(A.uuid=this.uuid,A.type=this.type,this.name!==""&&(A.name=this.name),Object.keys(this.userData).length>0&&(A.userData=this.userData),this.parameters!==void 0){let C=this.parameters;for(let e in C)C[e]!==void 0&&(A[e]=C[e]);return A}A.data={attributes:{}};let B=this.index;B!==null&&(A.data.index={type:B.array.constructor.name,array:Array.prototype.slice.call(B.array)});let Q=this.attributes;for(let C in Q){let e=Q[C];A.data.attributes[C]=e.toJSON(A.data)}let g={},v=!1;for(let C in this.morphAttributes){let e=this.morphAttributes[C],P=[];for(let D=0,t=e.length;D<t;D++){let n=e[D];P.push(n.toJSON(A.data))}P.length>0&&(g[C]=P,v=!0)}v&&(A.data.morphAttributes=g,A.data.morphTargetsRelative=this.morphTargetsRelative);let w=this.groups;w.length>0&&(A.data.groups=JSON.parse(JSON.stringify(w)));let f=this.boundingSphere;return f!==null&&(A.data.boundingSphere={center:f.center.toArray(),radius:f.radius}),A}clone(){return new this.constructor().copy(this)}copy(A){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let B={};this.name=A.name;let Q=A.index;Q!==null&&this.setIndex(Q.clone(B));let g=A.attributes;for(let e in g){let P=g[e];this.setAttribute(e,P.clone(B))}let v=A.morphAttributes;for(let e in v){let P=[],D=v[e];for(let t=0,n=D.length;t<n;t++)P.push(D[t].clone(B));this.morphAttributes[e]=P}this.morphTargetsRelative=A.morphTargetsRelative;let w=A.groups;for(let e=0,P=w.length;e<P;e++){let D=w[e];this.addGroup(D.start,D.count,D.materialIndex)}let f=A.boundingBox;f!==null&&(this.boundingBox=f.clone());let C=A.boundingSphere;return C!==null&&(this.boundingSphere=C.clone()),this.drawRange.start=A.drawRange.start,this.drawRange.count=A.drawRange.count,this.userData=A.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},g7=new fB,WQ=new gE,Sg=new qE,v7=new x,FE=new x,xE=new x,GE=new x,Ff=new x,Kg=new x,_g=new hA,$g=new hA,Av=new hA,f7=new x,w7=new x,C7=new x,Bv=new x,Qv=new x,UB=class extends iB{constructor(A=new YB,B=new JE){super(),this.isMesh=!0,this.type="Mesh",this.geometry=A,this.material=B,this.updateMorphTargets()}copy(A,B){return super.copy(A,B),A.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=A.morphTargetInfluences.slice()),A.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},A.morphTargetDictionary)),this.material=Array.isArray(A.material)?A.material.slice():A.material,this.geometry=A.geometry,this}updateMorphTargets(){let B=this.geometry.morphAttributes,Q=Object.keys(B);if(Q.length>0){let g=B[Q[0]];if(g!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let v=0,w=g.length;v<w;v++){let f=g[v].name||String(v);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=v}}}}getVertexPosition(A,B){let Q=this.geometry,g=Q.attributes.position,v=Q.morphAttributes.position,w=Q.morphTargetsRelative;B.fromBufferAttribute(g,A);let f=this.morphTargetInfluences;if(v&&f){Kg.set(0,0,0);for(let C=0,e=v.length;C<e;C++){let P=f[C],D=v[C];P!==0&&(Ff.fromBufferAttribute(D,A),w?Kg.addScaledVector(Ff,P):Kg.addScaledVector(Ff.sub(B),P))}B.add(Kg)}return B}raycast(A,B){let Q=this.geometry,g=this.material,v=this.matrixWorld;g!==void 0&&(Q.boundingSphere===null&&Q.computeBoundingSphere(),Sg.copy(Q.boundingSphere),Sg.applyMatrix4(v),WQ.copy(A.ray).recast(A.near),!(Sg.containsPoint(WQ.origin)===!1&&(WQ.intersectSphere(Sg,v7)===null||WQ.origin.distanceToSquared(v7)>(A.far-A.near)**2))&&(g7.copy(v).invert(),WQ.copy(A.ray).applyMatrix4(g7),!(Q.boundingBox!==null&&WQ.intersectsBox(Q.boundingBox)===!1)&&this._computeIntersections(A,B,WQ)))}_computeIntersections(A,B,Q){let g,v=this.geometry,w=this.material,f=v.index,C=v.attributes.position,e=v.attributes.uv,P=v.attributes.uv1,D=v.attributes.normal,t=v.groups,n=v.drawRange;if(f!==null)if(Array.isArray(w))for(let s=0,i=t.length;s<i;s++){let r=t[s],I=w[r.materialIndex],H=Math.max(r.start,n.start),o=Math.min(f.count,Math.min(r.start+r.count,n.start+n.count));for(let l=H,F=o;l<F;l+=3){let b=f.getX(l),h=f.getX(l+1),Z=f.getX(l+2);g=Ev(this,I,A,Q,e,P,D,b,h,Z),g&&(g.faceIndex=Math.floor(l/3),g.face.materialIndex=r.materialIndex,B.push(g))}}else{let s=Math.max(0,n.start),i=Math.min(f.count,n.start+n.count);for(let r=s,I=i;r<I;r+=3){let H=f.getX(r),o=f.getX(r+1),l=f.getX(r+2);g=Ev(this,w,A,Q,e,P,D,H,o,l),g&&(g.faceIndex=Math.floor(r/3),B.push(g))}}else if(C!==void 0)if(Array.isArray(w))for(let s=0,i=t.length;s<i;s++){let r=t[s],I=w[r.materialIndex],H=Math.max(r.start,n.start),o=Math.min(C.count,Math.min(r.start+r.count,n.start+n.count));for(let l=H,F=o;l<F;l+=3){let b=l,h=l+1,Z=l+2;g=Ev(this,I,A,Q,e,P,D,b,h,Z),g&&(g.faceIndex=Math.floor(l/3),g.face.materialIndex=r.materialIndex,B.push(g))}}else{let s=Math.max(0,n.start),i=Math.min(C.count,n.start+n.count);for(let r=s,I=i;r<I;r+=3){let H=r,o=r+1,l=r+2;g=Ev(this,w,A,Q,e,P,D,H,o,l),g&&(g.faceIndex=Math.floor(r/3),B.push(g))}}}};function Xt(E,A,B,Q,g,v,w,f){let C;if(A.side===FB?C=Q.intersectTriangle(w,v,g,!0,f):C=Q.intersectTriangle(g,v,w,A.side===YQ,f),C===null)return null;Qv.copy(f),Qv.applyMatrix4(E.matrixWorld);let e=B.ray.origin.distanceTo(Qv);return e<B.near||e>B.far?null:{distance:e,point:Qv.clone(),object:E}}function Ev(E,A,B,Q,g,v,w,f,C,e){E.getVertexPosition(f,FE),E.getVertexPosition(C,xE),E.getVertexPosition(e,GE);let P=Xt(E,A,B,Q,FE,xE,GE,Bv);if(P){g&&(_g.fromBufferAttribute(g,f),$g.fromBufferAttribute(g,C),Av.fromBufferAttribute(g,e),P.uv=TE.getInterpolation(Bv,FE,xE,GE,_g,$g,Av,new hA)),v&&(_g.fromBufferAttribute(v,f),$g.fromBufferAttribute(v,C),Av.fromBufferAttribute(v,e),P.uv1=TE.getInterpolation(Bv,FE,xE,GE,_g,$g,Av,new hA),P.uv2=P.uv1),w&&(f7.fromBufferAttribute(w,f),w7.fromBufferAttribute(w,C),C7.fromBufferAttribute(w,e),P.normal=TE.getInterpolation(Bv,FE,xE,GE,f7,w7,C7,new x),P.normal.dot(Q.direction)>0&&P.normal.multiplyScalar(-1));let D={a:f,b:C,c:e,normal:new x,materialIndex:0};TE.getNormal(FE,xE,GE,D.normal),P.face=D}return P}var ag=class E extends YB{constructor(A=1,B=1,Q=1,g=1,v=1,w=1){super(),this.type="BoxGeometry",this.parameters={width:A,height:B,depth:Q,widthSegments:g,heightSegments:v,depthSegments:w};let f=this;g=Math.floor(g),v=Math.floor(v),w=Math.floor(w);let C=[],e=[],P=[],D=[],t=0,n=0;s("z","y","x",-1,-1,Q,B,A,w,v,0),s("z","y","x",1,-1,Q,B,-A,w,v,1),s("x","z","y",1,1,A,Q,B,g,w,2),s("x","z","y",1,-1,A,Q,-B,g,w,3),s("x","y","z",1,-1,A,B,Q,g,v,4),s("x","y","z",-1,-1,A,B,-Q,g,v,5),this.setIndex(C),this.setAttribute("position",new XB(e,3)),this.setAttribute("normal",new XB(P,3)),this.setAttribute("uv",new XB(D,2));function s(i,r,I,H,o,l,F,b,h,Z,a){let u=l/h,y=F/Z,q=l/2,EA=F/2,p=b/2,L=h+1,N=Z+1,k=0,V=0,R=new x;for(let W=0;W<N;W++){let $=W*y-EA;for(let eA=0;eA<L;eA++){let O=eA*u-q;R[i]=O*H,R[r]=$*o,R[I]=p,e.push(R.x,R.y,R.z),R[i]=0,R[r]=0,R[I]=b>0?1:-1,P.push(R.x,R.y,R.z),D.push(eA/h),D.push(1-W/Z),k+=1}}for(let W=0;W<Z;W++)for(let $=0;$<h;$++){let eA=t+$+L*W,O=t+$+L*(W+1),S=t+($+1)+L*(W+1),tA=t+($+1)+L*W;C.push(eA,O,tA),C.push(O,S,tA),V+=6}f.addGroup(n,V,a),n+=V,t+=k}}copy(A){return super.copy(A),this.parameters=Object.assign({},A.parameters),this}static fromJSON(A){return new E(A.width,A.height,A.depth,A.widthSegments,A.heightSegments,A.depthSegments)}};function WE(E){let A={};for(let B in E){A[B]={};for(let Q in E[B]){let g=E[B][Q];g&&(g.isColor||g.isMatrix3||g.isMatrix4||g.isVector2||g.isVector3||g.isVector4||g.isTexture||g.isQuaternion)?g.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),A[B][Q]=null):A[B][Q]=g.clone():Array.isArray(g)?A[B][Q]=g.slice():A[B][Q]=g}}return A}function lB(E){let A={};for(let B=0;B<E.length;B++){let Q=WE(E[B]);for(let g in Q)A[g]=Q[g]}return A}function Yt(E){let A=[];for(let B=0;B<E.length;B++)A.push(E[B].clone());return A}function _7(E){return E.getRenderTarget()===null?E.outputColorSpace:KA.workingColorSpace}var Tt={clone:WE,merge:lB},jt=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,yt=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,HQ=class extends jQ{constructor(A){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=jt,this.fragmentShader=yt,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,A!==void 0&&this.setValues(A)}copy(A){return super.copy(A),this.fragmentShader=A.fragmentShader,this.vertexShader=A.vertexShader,this.uniforms=WE(A.uniforms),this.uniformsGroups=Yt(A.uniformsGroups),this.defines=Object.assign({},A.defines),this.wireframe=A.wireframe,this.wireframeLinewidth=A.wireframeLinewidth,this.fog=A.fog,this.lights=A.lights,this.clipping=A.clipping,this.extensions=Object.assign({},A.extensions),this.glslVersion=A.glslVersion,this}toJSON(A){let B=super.toJSON(A);B.glslVersion=this.glslVersion,B.uniforms={};for(let g in this.uniforms){let w=this.uniforms[g].value;w&&w.isTexture?B.uniforms[g]={type:"t",value:w.toJSON(A).uuid}:w&&w.isColor?B.uniforms[g]={type:"c",value:w.getHex()}:w&&w.isVector2?B.uniforms[g]={type:"v2",value:w.toArray()}:w&&w.isVector3?B.uniforms[g]={type:"v3",value:w.toArray()}:w&&w.isVector4?B.uniforms[g]={type:"v4",value:w.toArray()}:w&&w.isMatrix3?B.uniforms[g]={type:"m3",value:w.toArray()}:w&&w.isMatrix4?B.uniforms[g]={type:"m4",value:w.toArray()}:B.uniforms[g]={value:w}}Object.keys(this.defines).length>0&&(B.defines=this.defines),B.vertexShader=this.vertexShader,B.fragmentShader=this.fragmentShader,B.lights=this.lights,B.clipping=this.clipping;let Q={};for(let g in this.extensions)this.extensions[g]===!0&&(Q[g]=!0);return Object.keys(Q).length>0&&(B.extensions=Q),B}},uv=class extends iB{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new fB,this.projectionMatrix=new fB,this.projectionMatrixInverse=new fB,this.coordinateSystem=oQ}copy(A,B){return super.copy(A,B),this.matrixWorldInverse.copy(A.matrixWorldInverse),this.projectionMatrix.copy(A.projectionMatrix),this.projectionMatrixInverse.copy(A.projectionMatrixInverse),this.coordinateSystem=A.coordinateSystem,this}getWorldDirection(A){return super.getWorldDirection(A).negate()}updateMatrixWorld(A){super.updateMatrixWorld(A),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(A,B){super.updateWorldMatrix(A,B),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},mB=class extends uv{constructor(A=50,B=1,Q=.1,g=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=A,this.zoom=1,this.near=Q,this.far=g,this.focus=10,this.aspect=B,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(A,B){return super.copy(A,B),this.fov=A.fov,this.zoom=A.zoom,this.near=A.near,this.far=A.far,this.focus=A.focus,this.aspect=A.aspect,this.view=A.view===null?null:Object.assign({},A.view),this.filmGauge=A.filmGauge,this.filmOffset=A.filmOffset,this}setFocalLength(A){let B=.5*this.getFilmHeight()/A;this.fov=og*2*Math.atan(B),this.updateProjectionMatrix()}getFocalLength(){let A=Math.tan(ng*.5*this.fov);return .5*this.getFilmHeight()/A}getEffectiveFOV(){return og*2*Math.atan(Math.tan(ng*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(A,B,Q,g,v,w){this.aspect=A/B,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=A,this.view.fullHeight=B,this.view.offsetX=Q,this.view.offsetY=g,this.view.width=v,this.view.height=w,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let A=this.near,B=A*Math.tan(ng*.5*this.fov)/this.zoom,Q=2*B,g=this.aspect*Q,v=-.5*g,w=this.view;if(this.view!==null&&this.view.enabled){let C=w.fullWidth,e=w.fullHeight;v+=w.offsetX*g/C,B-=w.offsetY*Q/e,g*=w.width/C,Q*=w.height/e}let f=this.filmOffset;f!==0&&(v+=A*f/this.getFilmWidth()),this.projectionMatrix.makePerspective(v,v+g,B,B-Q,A,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(A){let B=super.toJSON(A);return B.object.fov=this.fov,B.object.zoom=this.zoom,B.object.near=this.near,B.object.far=this.far,B.object.focus=this.focus,B.object.aspect=this.aspect,this.view!==null&&(B.object.view=Object.assign({},this.view)),B.object.filmGauge=this.filmGauge,B.object.filmOffset=this.filmOffset,B}},LE=-90,UE=1,Sf=class extends iB{constructor(A,B,Q){super(),this.type="CubeCamera",this.renderTarget=Q,this.coordinateSystem=null,this.activeMipmapLevel=0;let g=new mB(LE,UE,A,B);g.layers=this.layers,this.add(g);let v=new mB(LE,UE,A,B);v.layers=this.layers,this.add(v);let w=new mB(LE,UE,A,B);w.layers=this.layers,this.add(w);let f=new mB(LE,UE,A,B);f.layers=this.layers,this.add(f);let C=new mB(LE,UE,A,B);C.layers=this.layers,this.add(C);let e=new mB(LE,UE,A,B);e.layers=this.layers,this.add(e)}updateCoordinateSystem(){let A=this.coordinateSystem,B=this.children.concat(),[Q,g,v,w,f,C]=B;for(let e of B)this.remove(e);if(A===oQ)Q.up.set(0,1,0),Q.lookAt(1,0,0),g.up.set(0,1,0),g.lookAt(-1,0,0),v.up.set(0,0,-1),v.lookAt(0,1,0),w.up.set(0,0,1),w.lookAt(0,-1,0),f.up.set(0,1,0),f.lookAt(0,0,1),C.up.set(0,1,0),C.lookAt(0,0,-1);else if(A===rv)Q.up.set(0,-1,0),Q.lookAt(-1,0,0),g.up.set(0,-1,0),g.lookAt(1,0,0),v.up.set(0,0,1),v.lookAt(0,1,0),w.up.set(0,0,-1),w.lookAt(0,-1,0),f.up.set(0,-1,0),f.lookAt(0,0,1),C.up.set(0,-1,0),C.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+A);for(let e of B)this.add(e),e.updateMatrixWorld()}update(A,B){this.parent===null&&this.updateMatrixWorld();let{renderTarget:Q,activeMipmapLevel:g}=this;this.coordinateSystem!==A.coordinateSystem&&(this.coordinateSystem=A.coordinateSystem,this.updateCoordinateSystem());let[v,w,f,C,e,P]=this.children,D=A.getRenderTarget(),t=A.getActiveCubeFace(),n=A.getActiveMipmapLevel(),s=A.xr.enabled;A.xr.enabled=!1;let i=Q.texture.generateMipmaps;Q.texture.generateMipmaps=!1,A.setRenderTarget(Q,0,g),A.render(B,v),A.setRenderTarget(Q,1,g),A.render(B,w),A.setRenderTarget(Q,2,g),A.render(B,f),A.setRenderTarget(Q,3,g),A.render(B,C),A.setRenderTarget(Q,4,g),A.render(B,e),Q.texture.generateMipmaps=i,A.setRenderTarget(Q,5,g),A.render(B,P),A.setRenderTarget(D,t,n),A.xr.enabled=s,Q.texture.needsPMREMUpdate=!0}},dv=class extends RB{constructor(A,B,Q,g,v,w,f,C,e,P){A=A!==void 0?A:[],B=B!==void 0?B:ZE,super(A,B,Q,g,v,w,f,C,e,P),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(A){this.image=A}},Kf=class extends zQ{constructor(A=1,B={}){super(A,A,B),this.isWebGLCubeRenderTarget=!0;let Q={width:A,height:A,depth:1},g=[Q,Q,Q,Q,Q,Q];B.encoding!==void 0&&(sg("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),B.colorSpace=B.encoding===QE?eB:OB),this.texture=new dv(g,B.mapping,B.wrapS,B.wrapT,B.magFilter,B.minFilter,B.format,B.type,B.anisotropy,B.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=B.generateMipmaps!==void 0?B.generateMipmaps:!1,this.texture.minFilter=B.minFilter!==void 0?B.minFilter:bB}fromEquirectangularTexture(A,B){this.texture.type=B.type,this.texture.colorSpace=B.colorSpace,this.texture.generateMipmaps=B.generateMipmaps,this.texture.minFilter=B.minFilter,this.texture.magFilter=B.magFilter;let Q={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},g=new ag(5,5,5),v=new HQ({name:"CubemapFromEquirect",uniforms:WE(Q.uniforms),vertexShader:Q.vertexShader,fragmentShader:Q.fragmentShader,side:FB,blending:LQ});v.uniforms.tEquirect.value=B;let w=new UB(g,v),f=B.minFilter;return B.minFilter===TQ&&(B.minFilter=bB),new Sf(1,10,this).update(A,w),B.minFilter=f,w.geometry.dispose(),w.material.dispose(),this}clear(A,B,Q,g){let v=A.getRenderTarget();for(let w=0;w<6;w++)A.setRenderTarget(this,w),A.clear(B,Q,g);A.setRenderTarget(v)}},xf=new x,Ot=new x,Nt=new NA,pB=class{constructor(A=new x(1,0,0),B=0){this.isPlane=!0,this.normal=A,this.constant=B}set(A,B){return this.normal.copy(A),this.constant=B,this}setComponents(A,B,Q,g){return this.normal.set(A,B,Q),this.constant=g,this}setFromNormalAndCoplanarPoint(A,B){return this.normal.copy(A),this.constant=-B.dot(this.normal),this}setFromCoplanarPoints(A,B,Q){let g=xf.subVectors(Q,B).cross(Ot.subVectors(A,B)).normalize();return this.setFromNormalAndCoplanarPoint(g,A),this}copy(A){return this.normal.copy(A.normal),this.constant=A.constant,this}normalize(){let A=1/this.normal.length();return this.normal.multiplyScalar(A),this.constant*=A,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(A){return this.normal.dot(A)+this.constant}distanceToSphere(A){return this.distanceToPoint(A.center)-A.radius}projectPoint(A,B){return B.copy(A).addScaledVector(this.normal,-this.distanceToPoint(A))}intersectLine(A,B){let Q=A.delta(xf),g=this.normal.dot(Q);if(g===0)return this.distanceToPoint(A.start)===0?B.copy(A.start):null;let v=-(A.start.dot(this.normal)+this.constant)/g;return v<0||v>1?null:B.copy(A.start).addScaledVector(Q,v)}intersectsLine(A){let B=this.distanceToPoint(A.start),Q=this.distanceToPoint(A.end);return B<0&&Q>0||Q<0&&B>0}intersectsBox(A){return A.intersectsPlane(this)}intersectsSphere(A){return A.intersectsPlane(this)}coplanarPoint(A){return A.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(A,B){let Q=B||Nt.getNormalMatrix(A),g=this.coplanarPoint(xf).applyMatrix4(A),v=this.normal.applyMatrix3(Q).normalize();return this.constant=-g.dot(v),this}translate(A){return this.constant-=A.dot(this.normal),this}equals(A){return A.normal.equals(this.normal)&&A.constant===this.constant}clone(){return new this.constructor().copy(this)}},SQ=new qE,gv=new x,zg=class{constructor(A=new pB,B=new pB,Q=new pB,g=new pB,v=new pB,w=new pB){this.planes=[A,B,Q,g,v,w]}set(A,B,Q,g,v,w){let f=this.planes;return f[0].copy(A),f[1].copy(B),f[2].copy(Q),f[3].copy(g),f[4].copy(v),f[5].copy(w),this}copy(A){let B=this.planes;for(let Q=0;Q<6;Q++)B[Q].copy(A.planes[Q]);return this}setFromProjectionMatrix(A,B=oQ){let Q=this.planes,g=A.elements,v=g[0],w=g[1],f=g[2],C=g[3],e=g[4],P=g[5],D=g[6],t=g[7],n=g[8],s=g[9],i=g[10],r=g[11],I=g[12],H=g[13],o=g[14],l=g[15];if(Q[0].setComponents(C-v,t-e,r-n,l-I).normalize(),Q[1].setComponents(C+v,t+e,r+n,l+I).normalize(),Q[2].setComponents(C+w,t+P,r+s,l+H).normalize(),Q[3].setComponents(C-w,t-P,r-s,l-H).normalize(),Q[4].setComponents(C-f,t-D,r-i,l-o).normalize(),B===oQ)Q[5].setComponents(C+f,t+D,r+i,l+o).normalize();else if(B===rv)Q[5].setComponents(f,D,i,o).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+B);return this}intersectsObject(A){if(A.boundingSphere!==void 0)A.boundingSphere===null&&A.computeBoundingSphere(),SQ.copy(A.boundingSphere).applyMatrix4(A.matrixWorld);else{let B=A.geometry;B.boundingSphere===null&&B.computeBoundingSphere(),SQ.copy(B.boundingSphere).applyMatrix4(A.matrixWorld)}return this.intersectsSphere(SQ)}intersectsSprite(A){return SQ.center.set(0,0,0),SQ.radius=.7071067811865476,SQ.applyMatrix4(A.matrixWorld),this.intersectsSphere(SQ)}intersectsSphere(A){let B=this.planes,Q=A.center,g=-A.radius;for(let v=0;v<6;v++)if(B[v].distanceToPoint(Q)<g)return!1;return!0}intersectsBox(A){let B=this.planes;for(let Q=0;Q<6;Q++){let g=B[Q];if(gv.x=g.normal.x>0?A.max.x:A.min.x,gv.y=g.normal.y>0?A.max.y:A.min.y,gv.z=g.normal.z>0?A.max.z:A.min.z,g.distanceToPoint(gv)<0)return!1}return!0}containsPoint(A){let B=this.planes;for(let Q=0;Q<6;Q++)if(B[Q].distanceToPoint(A)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function $7(){let E=null,A=!1,B=null,Q=null;function g(v,w){B(v,w),Q=E.requestAnimationFrame(g)}return{start:function(){A!==!0&&B!==null&&(Q=E.requestAnimationFrame(g),A=!0)},stop:function(){E.cancelAnimationFrame(Q),A=!1},setAnimationLoop:function(v){B=v},setContext:function(v){E=v}}}function Rt(E,A){let B=A.isWebGL2,Q=new WeakMap;function g(e,P){let D=e.array,t=e.usage,n=D.byteLength,s=E.createBuffer();E.bindBuffer(P,s),E.bufferData(P,D,t),e.onUploadCallback();let i;if(D instanceof Float32Array)i=E.FLOAT;else if(D instanceof Uint16Array)if(e.isFloat16BufferAttribute)if(B)i=E.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else i=E.UNSIGNED_SHORT;else if(D instanceof Int16Array)i=E.SHORT;else if(D instanceof Uint32Array)i=E.UNSIGNED_INT;else if(D instanceof Int32Array)i=E.INT;else if(D instanceof Int8Array)i=E.BYTE;else if(D instanceof Uint8Array)i=E.UNSIGNED_BYTE;else if(D instanceof Uint8ClampedArray)i=E.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+D);return{buffer:s,type:i,bytesPerElement:D.BYTES_PER_ELEMENT,version:e.version,size:n}}function v(e,P,D){let t=P.array,n=P._updateRange,s=P.updateRanges;if(E.bindBuffer(D,e),n.count===-1&&s.length===0&&E.bufferSubData(D,0,t),s.length!==0){for(let i=0,r=s.length;i<r;i++){let I=s[i];B?E.bufferSubData(D,I.start*t.BYTES_PER_ELEMENT,t,I.start,I.count):E.bufferSubData(D,I.start*t.BYTES_PER_ELEMENT,t.subarray(I.start,I.start+I.count))}P.clearUpdateRanges()}n.count!==-1&&(B?E.bufferSubData(D,n.offset*t.BYTES_PER_ELEMENT,t,n.offset,n.count):E.bufferSubData(D,n.offset*t.BYTES_PER_ELEMENT,t.subarray(n.offset,n.offset+n.count)),n.count=-1),P.onUploadCallback()}function w(e){return e.isInterleavedBufferAttribute&&(e=e.data),Q.get(e)}function f(e){e.isInterleavedBufferAttribute&&(e=e.data);let P=Q.get(e);P&&(E.deleteBuffer(P.buffer),Q.delete(e))}function C(e,P){if(e.isGLBufferAttribute){let t=Q.get(e);(!t||t.version<e.version)&&Q.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}e.isInterleavedBufferAttribute&&(e=e.data);let D=Q.get(e);if(D===void 0)Q.set(e,g(e,P));else if(D.version<e.version){if(D.size!==e.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");v(D.buffer,e,P),D.version=e.version}}return{get:w,remove:f,update:C}}var Hg=class E extends YB{constructor(A=1,B=1,Q=1,g=1){super(),this.type="PlaneGeometry",this.parameters={width:A,height:B,widthSegments:Q,heightSegments:g};let v=A/2,w=B/2,f=Math.floor(Q),C=Math.floor(g),e=f+1,P=C+1,D=A/f,t=B/C,n=[],s=[],i=[],r=[];for(let I=0;I<P;I++){let H=I*t-w;for(let o=0;o<e;o++){let l=o*D-v;s.push(l,-H,0),i.push(0,0,1),r.push(o/f),r.push(1-I/C)}}for(let I=0;I<C;I++)for(let H=0;H<f;H++){let o=H+e*I,l=H+e*(I+1),F=H+1+e*(I+1),b=H+1+e*I;n.push(o,l,b),n.push(l,F,b)}this.setIndex(n),this.setAttribute("position",new XB(s,3)),this.setAttribute("normal",new XB(i,3)),this.setAttribute("uv",new XB(r,2))}copy(A){return super.copy(A),this.parameters=Object.assign({},A.parameters),this}static fromJSON(A){return new E(A.width,A.height,A.widthSegments,A.heightSegments)}},Zt=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Vt=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,kt=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,qt=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Jt=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Wt=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,St=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Kt=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,_t=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,$t=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,AD=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,BD=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,QD=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ED=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,gD=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,vD=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,fD=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,wD=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,CD=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,eD=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,PD=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,tD=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,DD=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,ID=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,nD=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,rD=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,sD=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,iD=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,MD=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,oD=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,cD="gl_FragColor = linearToOutputTexel( gl_FragColor );",aD=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,zD=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,HD=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,uD=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,dD=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,lD=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,hD=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,bD=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,mD=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,pD=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,FD=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,xD=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,GD=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,LD=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,UD=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,XD=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,YD=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,TD=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,jD=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,yD=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,OD=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ND=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,RD=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,ZD=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,VD=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,kD=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,qD=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,JD=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,WD=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,SD=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,KD=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,_D=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,$D=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,AI=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,BI=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,QI=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,EI=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,gI=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,vI=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,fI=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,wI=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,CI=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,eI=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,PI=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,tI=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,DI=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,II=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,nI=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,rI=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,sI=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,iI=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,MI=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,oI=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,cI=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,aI=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,zI=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,HI=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,uI=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,dI=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,lI=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,hI=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,bI=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,mI=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,pI=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,FI=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,xI=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,GI=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,LI=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,UI=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,XI=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,YI=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,TI=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,jI=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,yI=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,OI=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,NI=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,RI=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,ZI=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,VI=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,kI=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qI=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,JI=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,WI=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,SI=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,KI=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,_I=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,$I=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,A8=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,B8=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Q8=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,E8=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,g8=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,v8=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,f8=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,w8=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,C8=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,e8=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,P8=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,t8=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,D8=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,I8=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,n8=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,r8=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,s8=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,i8=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,M8=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,o8=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,c8=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,a8=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,z8=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,XA={alphahash_fragment:Zt,alphahash_pars_fragment:Vt,alphamap_fragment:kt,alphamap_pars_fragment:qt,alphatest_fragment:Jt,alphatest_pars_fragment:Wt,aomap_fragment:St,aomap_pars_fragment:Kt,batching_pars_vertex:_t,batching_vertex:$t,begin_vertex:AD,beginnormal_vertex:BD,bsdfs:QD,iridescence_fragment:ED,bumpmap_pars_fragment:gD,clipping_planes_fragment:vD,clipping_planes_pars_fragment:fD,clipping_planes_pars_vertex:wD,clipping_planes_vertex:CD,color_fragment:eD,color_pars_fragment:PD,color_pars_vertex:tD,color_vertex:DD,common:ID,cube_uv_reflection_fragment:nD,defaultnormal_vertex:rD,displacementmap_pars_vertex:sD,displacementmap_vertex:iD,emissivemap_fragment:MD,emissivemap_pars_fragment:oD,colorspace_fragment:cD,colorspace_pars_fragment:aD,envmap_fragment:zD,envmap_common_pars_fragment:HD,envmap_pars_fragment:uD,envmap_pars_vertex:dD,envmap_physical_pars_fragment:YD,envmap_vertex:lD,fog_vertex:hD,fog_pars_vertex:bD,fog_fragment:mD,fog_pars_fragment:pD,gradientmap_pars_fragment:FD,lightmap_fragment:xD,lightmap_pars_fragment:GD,lights_lambert_fragment:LD,lights_lambert_pars_fragment:UD,lights_pars_begin:XD,lights_toon_fragment:TD,lights_toon_pars_fragment:jD,lights_phong_fragment:yD,lights_phong_pars_fragment:OD,lights_physical_fragment:ND,lights_physical_pars_fragment:RD,lights_fragment_begin:ZD,lights_fragment_maps:VD,lights_fragment_end:kD,logdepthbuf_fragment:qD,logdepthbuf_pars_fragment:JD,logdepthbuf_pars_vertex:WD,logdepthbuf_vertex:SD,map_fragment:KD,map_pars_fragment:_D,map_particle_fragment:$D,map_particle_pars_fragment:AI,metalnessmap_fragment:BI,metalnessmap_pars_fragment:QI,morphcolor_vertex:EI,morphnormal_vertex:gI,morphtarget_pars_vertex:vI,morphtarget_vertex:fI,normal_fragment_begin:wI,normal_fragment_maps:CI,normal_pars_fragment:eI,normal_pars_vertex:PI,normal_vertex:tI,normalmap_pars_fragment:DI,clearcoat_normal_fragment_begin:II,clearcoat_normal_fragment_maps:nI,clearcoat_pars_fragment:rI,iridescence_pars_fragment:sI,opaque_fragment:iI,packing:MI,premultiplied_alpha_fragment:oI,project_vertex:cI,dithering_fragment:aI,dithering_pars_fragment:zI,roughnessmap_fragment:HI,roughnessmap_pars_fragment:uI,shadowmap_pars_fragment:dI,shadowmap_pars_vertex:lI,shadowmap_vertex:hI,shadowmask_pars_fragment:bI,skinbase_vertex:mI,skinning_pars_vertex:pI,skinning_vertex:FI,skinnormal_vertex:xI,specularmap_fragment:GI,specularmap_pars_fragment:LI,tonemapping_fragment:UI,tonemapping_pars_fragment:XI,transmission_fragment:YI,transmission_pars_fragment:TI,uv_pars_fragment:jI,uv_pars_vertex:yI,uv_vertex:OI,worldpos_vertex:NI,background_vert:RI,background_frag:ZI,backgroundCube_vert:VI,backgroundCube_frag:kI,cube_vert:qI,cube_frag:JI,depth_vert:WI,depth_frag:SI,distanceRGBA_vert:KI,distanceRGBA_frag:_I,equirect_vert:$I,equirect_frag:A8,linedashed_vert:B8,linedashed_frag:Q8,meshbasic_vert:E8,meshbasic_frag:g8,meshlambert_vert:v8,meshlambert_frag:f8,meshmatcap_vert:w8,meshmatcap_frag:C8,meshnormal_vert:e8,meshnormal_frag:P8,meshphong_vert:t8,meshphong_frag:D8,meshphysical_vert:I8,meshphysical_frag:n8,meshtoon_vert:r8,meshtoon_frag:s8,points_vert:i8,points_frag:M8,shadow_vert:o8,shadow_frag:c8,sprite_vert:a8,sprite_frag:z8},CA={common:{diffuse:{value:new lA(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new NA},alphaMap:{value:null},alphaMapTransform:{value:new NA},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new NA}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new NA}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new NA}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new NA},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new NA},normalScale:{value:new hA(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new NA},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new NA}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new NA}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new NA}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new lA(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new lA(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new NA},alphaTest:{value:0},uvTransform:{value:new NA}},sprite:{diffuse:{value:new lA(16777215)},opacity:{value:1},center:{value:new hA(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new NA},alphaMap:{value:null},alphaMapTransform:{value:new NA},alphaTest:{value:0}}},vQ={basic:{uniforms:lB([CA.common,CA.specularmap,CA.envmap,CA.aomap,CA.lightmap,CA.fog]),vertexShader:XA.meshbasic_vert,fragmentShader:XA.meshbasic_frag},lambert:{uniforms:lB([CA.common,CA.specularmap,CA.envmap,CA.aomap,CA.lightmap,CA.emissivemap,CA.bumpmap,CA.normalmap,CA.displacementmap,CA.fog,CA.lights,{emissive:{value:new lA(0)}}]),vertexShader:XA.meshlambert_vert,fragmentShader:XA.meshlambert_frag},phong:{uniforms:lB([CA.common,CA.specularmap,CA.envmap,CA.aomap,CA.lightmap,CA.emissivemap,CA.bumpmap,CA.normalmap,CA.displacementmap,CA.fog,CA.lights,{emissive:{value:new lA(0)},specular:{value:new lA(1118481)},shininess:{value:30}}]),vertexShader:XA.meshphong_vert,fragmentShader:XA.meshphong_frag},standard:{uniforms:lB([CA.common,CA.envmap,CA.aomap,CA.lightmap,CA.emissivemap,CA.bumpmap,CA.normalmap,CA.displacementmap,CA.roughnessmap,CA.metalnessmap,CA.fog,CA.lights,{emissive:{value:new lA(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:XA.meshphysical_vert,fragmentShader:XA.meshphysical_frag},toon:{uniforms:lB([CA.common,CA.aomap,CA.lightmap,CA.emissivemap,CA.bumpmap,CA.normalmap,CA.displacementmap,CA.gradientmap,CA.fog,CA.lights,{emissive:{value:new lA(0)}}]),vertexShader:XA.meshtoon_vert,fragmentShader:XA.meshtoon_frag},matcap:{uniforms:lB([CA.common,CA.bumpmap,CA.normalmap,CA.displacementmap,CA.fog,{matcap:{value:null}}]),vertexShader:XA.meshmatcap_vert,fragmentShader:XA.meshmatcap_frag},points:{uniforms:lB([CA.points,CA.fog]),vertexShader:XA.points_vert,fragmentShader:XA.points_frag},dashed:{uniforms:lB([CA.common,CA.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:XA.linedashed_vert,fragmentShader:XA.linedashed_frag},depth:{uniforms:lB([CA.common,CA.displacementmap]),vertexShader:XA.depth_vert,fragmentShader:XA.depth_frag},normal:{uniforms:lB([CA.common,CA.bumpmap,CA.normalmap,CA.displacementmap,{opacity:{value:1}}]),vertexShader:XA.meshnormal_vert,fragmentShader:XA.meshnormal_frag},sprite:{uniforms:lB([CA.sprite,CA.fog]),vertexShader:XA.sprite_vert,fragmentShader:XA.sprite_frag},background:{uniforms:{uvTransform:{value:new NA},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:XA.background_vert,fragmentShader:XA.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:XA.backgroundCube_vert,fragmentShader:XA.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:XA.cube_vert,fragmentShader:XA.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:XA.equirect_vert,fragmentShader:XA.equirect_frag},distanceRGBA:{uniforms:lB([CA.common,CA.displacementmap,{referencePosition:{value:new x},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:XA.distanceRGBA_vert,fragmentShader:XA.distanceRGBA_frag},shadow:{uniforms:lB([CA.lights,CA.fog,{color:{value:new lA(0)},opacity:{value:1}}]),vertexShader:XA.shadow_vert,fragmentShader:XA.shadow_frag}};vQ.physical={uniforms:lB([vQ.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new NA},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new NA},clearcoatNormalScale:{value:new hA(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new NA},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new NA},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new NA},sheen:{value:0},sheenColor:{value:new lA(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new NA},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new NA},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new NA},transmissionSamplerSize:{value:new hA},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new NA},attenuationDistance:{value:0},attenuationColor:{value:new lA(0)},specularColor:{value:new lA(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new NA},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new NA},anisotropyVector:{value:new hA},anisotropyMap:{value:null},anisotropyMapTransform:{value:new NA}}]),vertexShader:XA.meshphysical_vert,fragmentShader:XA.meshphysical_frag};var vv={r:0,b:0,g:0};function H8(E,A,B,Q,g,v,w){let f=new lA(0),C=v===!0?0:1,e,P,D=null,t=0,n=null;function s(r,I){let H=!1,o=I.isScene===!0?I.background:null;o&&o.isTexture&&(o=(I.backgroundBlurriness>0?B:A).get(o)),o===null?i(f,C):o&&o.isColor&&(i(o,1),H=!0);let l=E.xr.getEnvironmentBlendMode();l==="additive"?Q.buffers.color.setClear(0,0,0,1,w):l==="alpha-blend"&&Q.buffers.color.setClear(0,0,0,0,w),(E.autoClear||H)&&E.clear(E.autoClearColor,E.autoClearDepth,E.autoClearStencil),o&&(o.isCubeTexture||o.mapping===Lv)?(P===void 0&&(P=new UB(new ag(1,1,1),new HQ({name:"BackgroundCubeMaterial",uniforms:WE(vQ.backgroundCube.uniforms),vertexShader:vQ.backgroundCube.vertexShader,fragmentShader:vQ.backgroundCube.fragmentShader,side:FB,depthTest:!1,depthWrite:!1,fog:!1})),P.geometry.deleteAttribute("normal"),P.geometry.deleteAttribute("uv"),P.onBeforeRender=function(F,b,h){this.matrixWorld.copyPosition(h.matrixWorld)},Object.defineProperty(P.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),g.update(P)),P.material.uniforms.envMap.value=o,P.material.uniforms.flipEnvMap.value=o.isCubeTexture&&o.isRenderTargetTexture===!1?-1:1,P.material.uniforms.backgroundBlurriness.value=I.backgroundBlurriness,P.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,P.material.toneMapped=KA.getTransfer(o.colorSpace)!==QB,(D!==o||t!==o.version||n!==E.toneMapping)&&(P.material.needsUpdate=!0,D=o,t=o.version,n=E.toneMapping),P.layers.enableAll(),r.unshift(P,P.geometry,P.material,0,0,null)):o&&o.isTexture&&(e===void 0&&(e=new UB(new Hg(2,2),new HQ({name:"BackgroundMaterial",uniforms:WE(vQ.background.uniforms),vertexShader:vQ.background.vertexShader,fragmentShader:vQ.background.fragmentShader,side:YQ,depthTest:!1,depthWrite:!1,fog:!1})),e.geometry.deleteAttribute("normal"),Object.defineProperty(e.material,"map",{get:function(){return this.uniforms.t2D.value}}),g.update(e)),e.material.uniforms.t2D.value=o,e.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,e.material.toneMapped=KA.getTransfer(o.colorSpace)!==QB,o.matrixAutoUpdate===!0&&o.updateMatrix(),e.material.uniforms.uvTransform.value.copy(o.matrix),(D!==o||t!==o.version||n!==E.toneMapping)&&(e.material.needsUpdate=!0,D=o,t=o.version,n=E.toneMapping),e.layers.enableAll(),r.unshift(e,e.geometry,e.material,0,0,null))}function i(r,I){r.getRGB(vv,_7(E)),Q.buffers.color.setClear(vv.r,vv.g,vv.b,I,w)}return{getClearColor:function(){return f},setClearColor:function(r,I=1){f.set(r),C=I,i(f,C)},getClearAlpha:function(){return C},setClearAlpha:function(r){C=r,i(f,C)},render:s}}function u8(E,A,B,Q){let g=E.getParameter(E.MAX_VERTEX_ATTRIBS),v=Q.isWebGL2?null:A.get("OES_vertex_array_object"),w=Q.isWebGL2||v!==null,f={},C=r(null),e=C,P=!1;function D(p,L,N,k,V){let R=!1;if(w){let W=i(k,N,L);e!==W&&(e=W,n(e.object)),R=I(p,k,N,V),R&&H(p,k,N,V)}else{let W=L.wireframe===!0;(e.geometry!==k.id||e.program!==N.id||e.wireframe!==W)&&(e.geometry=k.id,e.program=N.id,e.wireframe=W,R=!0)}V!==null&&B.update(V,E.ELEMENT_ARRAY_BUFFER),(R||P)&&(P=!1,Z(p,L,N,k),V!==null&&E.bindBuffer(E.ELEMENT_ARRAY_BUFFER,B.get(V).buffer))}function t(){return Q.isWebGL2?E.createVertexArray():v.createVertexArrayOES()}function n(p){return Q.isWebGL2?E.bindVertexArray(p):v.bindVertexArrayOES(p)}function s(p){return Q.isWebGL2?E.deleteVertexArray(p):v.deleteVertexArrayOES(p)}function i(p,L,N){let k=N.wireframe===!0,V=f[p.id];V===void 0&&(V={},f[p.id]=V);let R=V[L.id];R===void 0&&(R={},V[L.id]=R);let W=R[k];return W===void 0&&(W=r(t()),R[k]=W),W}function r(p){let L=[],N=[],k=[];for(let V=0;V<g;V++)L[V]=0,N[V]=0,k[V]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:L,enabledAttributes:N,attributeDivisors:k,object:p,attributes:{},index:null}}function I(p,L,N,k){let V=e.attributes,R=L.attributes,W=0,$=N.getAttributes();for(let eA in $)if($[eA].location>=0){let S=V[eA],tA=R[eA];if(tA===void 0&&(eA==="instanceMatrix"&&p.instanceMatrix&&(tA=p.instanceMatrix),eA==="instanceColor"&&p.instanceColor&&(tA=p.instanceColor)),S===void 0||S.attribute!==tA||tA&&S.data!==tA.data)return!0;W++}return e.attributesNum!==W||e.index!==k}function H(p,L,N,k){let V={},R=L.attributes,W=0,$=N.getAttributes();for(let eA in $)if($[eA].location>=0){let S=R[eA];S===void 0&&(eA==="instanceMatrix"&&p.instanceMatrix&&(S=p.instanceMatrix),eA==="instanceColor"&&p.instanceColor&&(S=p.instanceColor));let tA={};tA.attribute=S,S&&S.data&&(tA.data=S.data),V[eA]=tA,W++}e.attributes=V,e.attributesNum=W,e.index=k}function o(){let p=e.newAttributes;for(let L=0,N=p.length;L<N;L++)p[L]=0}function l(p){F(p,0)}function F(p,L){let N=e.newAttributes,k=e.enabledAttributes,V=e.attributeDivisors;N[p]=1,k[p]===0&&(E.enableVertexAttribArray(p),k[p]=1),V[p]!==L&&((Q.isWebGL2?E:A.get("ANGLE_instanced_arrays"))[Q.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](p,L),V[p]=L)}function b(){let p=e.newAttributes,L=e.enabledAttributes;for(let N=0,k=L.length;N<k;N++)L[N]!==p[N]&&(E.disableVertexAttribArray(N),L[N]=0)}function h(p,L,N,k,V,R,W){W===!0?E.vertexAttribIPointer(p,L,N,V,R):E.vertexAttribPointer(p,L,N,k,V,R)}function Z(p,L,N,k){if(Q.isWebGL2===!1&&(p.isInstancedMesh||k.isInstancedBufferGeometry)&&A.get("ANGLE_instanced_arrays")===null)return;o();let V=k.attributes,R=N.getAttributes(),W=L.defaultAttributeValues;for(let $ in R){let eA=R[$];if(eA.location>=0){let O=V[$];if(O===void 0&&($==="instanceMatrix"&&p.instanceMatrix&&(O=p.instanceMatrix),$==="instanceColor"&&p.instanceColor&&(O=p.instanceColor)),O!==void 0){let S=O.normalized,tA=O.itemSize,MA=B.get(O);if(MA===void 0)continue;let sA=MA.buffer,pA=MA.type,FA=MA.bytesPerElement,HA=Q.isWebGL2===!0&&(pA===E.INT||pA===E.UNSIGNED_INT||O.gpuType===j7);if(O.isInterleavedBufferAttribute){let ZA=O.data,U=ZA.stride,DB=O.offset;if(ZA.isInstancedInterleavedBuffer){for(let aA=0;aA<eA.locationSize;aA++)F(eA.location+aA,ZA.meshPerAttribute);p.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ZA.meshPerAttribute*ZA.count)}else for(let aA=0;aA<eA.locationSize;aA++)l(eA.location+aA);E.bindBuffer(E.ARRAY_BUFFER,sA);for(let aA=0;aA<eA.locationSize;aA++)h(eA.location+aA,tA/eA.locationSize,pA,S,U*FA,(DB+tA/eA.locationSize*aA)*FA,HA)}else{if(O.isInstancedBufferAttribute){for(let ZA=0;ZA<eA.locationSize;ZA++)F(eA.location+ZA,O.meshPerAttribute);p.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=O.meshPerAttribute*O.count)}else for(let ZA=0;ZA<eA.locationSize;ZA++)l(eA.location+ZA);E.bindBuffer(E.ARRAY_BUFFER,sA);for(let ZA=0;ZA<eA.locationSize;ZA++)h(eA.location+ZA,tA/eA.locationSize,pA,S,tA*FA,tA/eA.locationSize*ZA*FA,HA)}}else if(W!==void 0){let S=W[$];if(S!==void 0)switch(S.length){case 2:E.vertexAttrib2fv(eA.location,S);break;case 3:E.vertexAttrib3fv(eA.location,S);break;case 4:E.vertexAttrib4fv(eA.location,S);break;default:E.vertexAttrib1fv(eA.location,S)}}}}b()}function a(){q();for(let p in f){let L=f[p];for(let N in L){let k=L[N];for(let V in k)s(k[V].object),delete k[V];delete L[N]}delete f[p]}}function u(p){if(f[p.id]===void 0)return;let L=f[p.id];for(let N in L){let k=L[N];for(let V in k)s(k[V].object),delete k[V];delete L[N]}delete f[p.id]}function y(p){for(let L in f){let N=f[L];if(N[p.id]===void 0)continue;let k=N[p.id];for(let V in k)s(k[V].object),delete k[V];delete N[p.id]}}function q(){EA(),P=!0,e!==C&&(e=C,n(e.object))}function EA(){C.geometry=null,C.program=null,C.wireframe=!1}return{setup:D,reset:q,resetDefaultState:EA,dispose:a,releaseStatesOfGeometry:u,releaseStatesOfProgram:y,initAttributes:o,enableAttribute:l,disableUnusedAttributes:b}}function d8(E,A,B,Q){let g=Q.isWebGL2,v;function w(P){v=P}function f(P,D){E.drawArrays(v,P,D),B.update(D,v,1)}function C(P,D,t){if(t===0)return;let n,s;if(g)n=E,s="drawArraysInstanced";else if(n=A.get("ANGLE_instanced_arrays"),s="drawArraysInstancedANGLE",n===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}n[s](v,P,D,t),B.update(D,v,t)}function e(P,D,t){if(t===0)return;let n=A.get("WEBGL_multi_draw");if(n===null)for(let s=0;s<t;s++)this.render(P[s],D[s]);else{n.multiDrawArraysWEBGL(v,P,0,D,0,t);let s=0;for(let i=0;i<t;i++)s+=D[i];B.update(s,v,1)}}this.setMode=w,this.render=f,this.renderInstances=C,this.renderMultiDraw=e}function l8(E,A,B){let Q;function g(){if(Q!==void 0)return Q;if(A.has("EXT_texture_filter_anisotropic")===!0){let h=A.get("EXT_texture_filter_anisotropic");Q=E.getParameter(h.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else Q=0;return Q}function v(h){if(h==="highp"){if(E.getShaderPrecisionFormat(E.VERTEX_SHADER,E.HIGH_FLOAT).precision>0&&E.getShaderPrecisionFormat(E.FRAGMENT_SHADER,E.HIGH_FLOAT).precision>0)return"highp";h="mediump"}return h==="mediump"&&E.getShaderPrecisionFormat(E.VERTEX_SHADER,E.MEDIUM_FLOAT).precision>0&&E.getShaderPrecisionFormat(E.FRAGMENT_SHADER,E.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let w=typeof WebGL2RenderingContext<"u"&&E.constructor.name==="WebGL2RenderingContext",f=B.precision!==void 0?B.precision:"highp",C=v(f);C!==f&&(console.warn("THREE.WebGLRenderer:",f,"not supported, using",C,"instead."),f=C);let e=w||A.has("WEBGL_draw_buffers"),P=B.logarithmicDepthBuffer===!0,D=E.getParameter(E.MAX_TEXTURE_IMAGE_UNITS),t=E.getParameter(E.MAX_VERTEX_TEXTURE_IMAGE_UNITS),n=E.getParameter(E.MAX_TEXTURE_SIZE),s=E.getParameter(E.MAX_CUBE_MAP_TEXTURE_SIZE),i=E.getParameter(E.MAX_VERTEX_ATTRIBS),r=E.getParameter(E.MAX_VERTEX_UNIFORM_VECTORS),I=E.getParameter(E.MAX_VARYING_VECTORS),H=E.getParameter(E.MAX_FRAGMENT_UNIFORM_VECTORS),o=t>0,l=w||A.has("OES_texture_float"),F=o&&l,b=w?E.getParameter(E.MAX_SAMPLES):0;return{isWebGL2:w,drawBuffers:e,getMaxAnisotropy:g,getMaxPrecision:v,precision:f,logarithmicDepthBuffer:P,maxTextures:D,maxVertexTextures:t,maxTextureSize:n,maxCubemapSize:s,maxAttributes:i,maxVertexUniforms:r,maxVaryings:I,maxFragmentUniforms:H,vertexTextures:o,floatFragmentTextures:l,floatVertexTextures:F,maxSamples:b}}function h8(E){let A=this,B=null,Q=0,g=!1,v=!1,w=new pB,f=new NA,C={value:null,needsUpdate:!1};this.uniform=C,this.numPlanes=0,this.numIntersection=0,this.init=function(D,t){let n=D.length!==0||t||Q!==0||g;return g=t,Q=D.length,n},this.beginShadows=function(){v=!0,P(null)},this.endShadows=function(){v=!1},this.setGlobalState=function(D,t){B=P(D,t,0)},this.setState=function(D,t,n){let s=D.clippingPlanes,i=D.clipIntersection,r=D.clipShadows,I=E.get(D);if(!g||s===null||s.length===0||v&&!r)v?P(null):e();else{let H=v?0:Q,o=H*4,l=I.clippingState||null;C.value=l,l=P(s,t,o,n);for(let F=0;F!==o;++F)l[F]=B[F];I.clippingState=l,this.numIntersection=i?this.numPlanes:0,this.numPlanes+=H}};function e(){C.value!==B&&(C.value=B,C.needsUpdate=Q>0),A.numPlanes=Q,A.numIntersection=0}function P(D,t,n,s){let i=D!==null?D.length:0,r=null;if(i!==0){if(r=C.value,s!==!0||r===null){let I=n+i*4,H=t.matrixWorldInverse;f.getNormalMatrix(H),(r===null||r.length<I)&&(r=new Float32Array(I));for(let o=0,l=n;o!==i;++o,l+=4)w.copy(D[o]).applyMatrix4(H,f),w.normal.toArray(r,l),r[l+3]=w.constant}C.value=r,C.needsUpdate=!0}return A.numPlanes=i,A.numIntersection=0,r}}function b8(E){let A=new WeakMap;function B(w,f){return f===Nf?w.mapping=ZE:f===Rf&&(w.mapping=VE),w}function Q(w){if(w&&w.isTexture){let f=w.mapping;if(f===Nf||f===Rf)if(A.has(w)){let C=A.get(w).texture;return B(C,w.mapping)}else{let C=w.image;if(C&&C.height>0){let e=new Kf(C.height/2);return e.fromEquirectangularTexture(E,w),A.set(w,e),w.addEventListener("dispose",g),B(e.texture,w.mapping)}else return null}}return w}function g(w){let f=w.target;f.removeEventListener("dispose",g);let C=A.get(f);C!==void 0&&(A.delete(f),C.dispose())}function v(){A=new WeakMap}return{get:Q,dispose:v}}var lv=class extends uv{constructor(A=-1,B=1,Q=1,g=-1,v=.1,w=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=A,this.right=B,this.top=Q,this.bottom=g,this.near=v,this.far=w,this.updateProjectionMatrix()}copy(A,B){return super.copy(A,B),this.left=A.left,this.right=A.right,this.top=A.top,this.bottom=A.bottom,this.near=A.near,this.far=A.far,this.zoom=A.zoom,this.view=A.view===null?null:Object.assign({},A.view),this}setViewOffset(A,B,Q,g,v,w){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=A,this.view.fullHeight=B,this.view.offsetX=Q,this.view.offsetY=g,this.view.width=v,this.view.height=w,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let A=(this.right-this.left)/(2*this.zoom),B=(this.top-this.bottom)/(2*this.zoom),Q=(this.right+this.left)/2,g=(this.top+this.bottom)/2,v=Q-A,w=Q+A,f=g+B,C=g-B;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,P=(this.top-this.bottom)/this.view.fullHeight/this.zoom;v+=e*this.view.offsetX,w=v+e*this.view.width,f-=P*this.view.offsetY,C=f-P*this.view.height}this.projectionMatrix.makeOrthographic(v,w,f,C,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(A){let B=super.toJSON(A);return B.object.zoom=this.zoom,B.object.left=this.left,B.object.right=this.right,B.object.top=this.top,B.object.bottom=this.bottom,B.object.near=this.near,B.object.far=this.far,this.view!==null&&(B.object.view=Object.assign({},this.view)),B}},jE=4,e7=[.125,.215,.35,.446,.526,.582],$Q=20,Gf=new lv,P7=new lA,Lf=null,Uf=0,Xf=0,KQ=(1+Math.sqrt(5))/2,XE=1/KQ,t7=[new x(1,1,1),new x(-1,1,1),new x(1,1,-1),new x(-1,1,-1),new x(0,KQ,XE),new x(0,KQ,-XE),new x(XE,0,KQ),new x(-XE,0,KQ),new x(KQ,XE,0),new x(-KQ,XE,0)],hv=class{constructor(A){this._renderer=A,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(A,B=0,Q=.1,g=100){Lf=this._renderer.getRenderTarget(),Uf=this._renderer.getActiveCubeFace(),Xf=this._renderer.getActiveMipmapLevel(),this._setSize(256);let v=this._allocateTargets();return v.depthBuffer=!0,this._sceneToCubeUV(A,Q,g,v),B>0&&this._blur(v,0,0,B),this._applyPMREM(v),this._cleanup(v),v}fromEquirectangular(A,B=null){return this._fromTexture(A,B)}fromCubemap(A,B=null){return this._fromTexture(A,B)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=n7(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=I7(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(A){this._lodMax=Math.floor(Math.log2(A)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let A=0;A<this._lodPlanes.length;A++)this._lodPlanes[A].dispose()}_cleanup(A){this._renderer.setRenderTarget(Lf,Uf,Xf),A.scissorTest=!1,fv(A,0,0,A.width,A.height)}_fromTexture(A,B){A.mapping===ZE||A.mapping===VE?this._setSize(A.image.length===0?16:A.image[0].width||A.image[0].image.width):this._setSize(A.image.width/4),Lf=this._renderer.getRenderTarget(),Uf=this._renderer.getActiveCubeFace(),Xf=this._renderer.getActiveMipmapLevel();let Q=B||this._allocateTargets();return this._textureToCubeUV(A,Q),this._applyPMREM(Q),this._cleanup(Q),Q}_allocateTargets(){let A=3*Math.max(this._cubeSize,112),B=4*this._cubeSize,Q={magFilter:bB,minFilter:bB,generateMipmaps:!1,type:Mg,format:KB,colorSpace:aQ,depthBuffer:!1},g=D7(A,B,Q);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==A||this._pingPongRenderTarget.height!==B){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=D7(A,B,Q);let{_lodMax:v}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=m8(v)),this._blurMaterial=p8(v,A,B)}return g}_compileMaterial(A){let B=new UB(this._lodPlanes[0],A);this._renderer.compile(B,Gf)}_sceneToCubeUV(A,B,Q,g){let f=new mB(90,1,B,Q),C=[1,-1,1,1,1,1],e=[1,1,1,-1,-1,-1],P=this._renderer,D=P.autoClear,t=P.toneMapping;P.getClearColor(P7),P.toneMapping=UQ,P.autoClear=!1;let n=new JE({name:"PMREM.Background",side:FB,depthWrite:!1,depthTest:!1}),s=new UB(new ag,n),i=!1,r=A.background;r?r.isColor&&(n.color.copy(r),A.background=null,i=!0):(n.color.copy(P7),i=!0);for(let I=0;I<6;I++){let H=I%3;H===0?(f.up.set(0,C[I],0),f.lookAt(e[I],0,0)):H===1?(f.up.set(0,0,C[I]),f.lookAt(0,e[I],0)):(f.up.set(0,C[I],0),f.lookAt(0,0,e[I]));let o=this._cubeSize;fv(g,H*o,I>2?o:0,o,o),P.setRenderTarget(g),i&&P.render(s,f),P.render(A,f)}s.geometry.dispose(),s.material.dispose(),P.toneMapping=t,P.autoClear=D,A.background=r}_textureToCubeUV(A,B){let Q=this._renderer,g=A.mapping===ZE||A.mapping===VE;g?(this._cubemapMaterial===null&&(this._cubemapMaterial=n7()),this._cubemapMaterial.uniforms.flipEnvMap.value=A.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=I7());let v=g?this._cubemapMaterial:this._equirectMaterial,w=new UB(this._lodPlanes[0],v),f=v.uniforms;f.envMap.value=A;let C=this._cubeSize;fv(B,0,0,3*C,2*C),Q.setRenderTarget(B),Q.render(w,Gf)}_applyPMREM(A){let B=this._renderer,Q=B.autoClear;B.autoClear=!1;for(let g=1;g<this._lodPlanes.length;g++){let v=Math.sqrt(this._sigmas[g]*this._sigmas[g]-this._sigmas[g-1]*this._sigmas[g-1]),w=t7[(g-1)%t7.length];this._blur(A,g-1,g,v,w)}B.autoClear=Q}_blur(A,B,Q,g,v){let w=this._pingPongRenderTarget;this._halfBlur(A,w,B,Q,g,"latitudinal",v),this._halfBlur(w,A,Q,Q,g,"longitudinal",v)}_halfBlur(A,B,Q,g,v,w,f){let C=this._renderer,e=this._blurMaterial;w!=="latitudinal"&&w!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let P=3,D=new UB(this._lodPlanes[g],e),t=e.uniforms,n=this._sizeLods[Q]-1,s=isFinite(v)?Math.PI/(2*n):2*Math.PI/(2*$Q-1),i=v/s,r=isFinite(v)?1+Math.floor(P*i):$Q;r>$Q&&console.warn(`sigmaRadians, ${v}, is too large and will clip, as it requested ${r} samples when the maximum is set to ${$Q}`);let I=[],H=0;for(let h=0;h<$Q;++h){let Z=h/i,a=Math.exp(-Z*Z/2);I.push(a),h===0?H+=a:h<r&&(H+=2*a)}for(let h=0;h<I.length;h++)I[h]=I[h]/H;t.envMap.value=A.texture,t.samples.value=r,t.weights.value=I,t.latitudinal.value=w==="latitudinal",f&&(t.poleAxis.value=f);let{_lodMax:o}=this;t.dTheta.value=s,t.mipInt.value=o-Q;let l=this._sizeLods[g],F=3*l*(g>o-jE?g-o+jE:0),b=4*(this._cubeSize-l);fv(B,F,b,3*l,2*l),C.setRenderTarget(B),C.render(D,Gf)}};function m8(E){let A=[],B=[],Q=[],g=E,v=E-jE+1+e7.length;for(let w=0;w<v;w++){let f=Math.pow(2,g);B.push(f);let C=1/f;w>E-jE?C=e7[w-E+jE-1]:w===0&&(C=0),Q.push(C);let e=1/(f-2),P=-e,D=1+e,t=[P,P,D,P,D,D,P,P,D,D,P,D],n=6,s=6,i=3,r=2,I=1,H=new Float32Array(i*s*n),o=new Float32Array(r*s*n),l=new Float32Array(I*s*n);for(let b=0;b<n;b++){let h=b%3*2/3-1,Z=b>2?0:-1,a=[h,Z,0,h+2/3,Z,0,h+2/3,Z+1,0,h,Z,0,h+2/3,Z+1,0,h,Z+1,0];H.set(a,i*s*b),o.set(t,r*s*b);let u=[b,b,b,b,b,b];l.set(u,I*s*b)}let F=new YB;F.setAttribute("position",new NB(H,i)),F.setAttribute("uv",new NB(o,r)),F.setAttribute("faceIndex",new NB(l,I)),A.push(F),g>jE&&g--}return{lodPlanes:A,sizeLods:B,sigmas:Q}}function D7(E,A,B){let Q=new zQ(E,A,B);return Q.texture.mapping=Lv,Q.texture.name="PMREM.cubeUv",Q.scissorTest=!0,Q}function fv(E,A,B,Q,g){E.viewport.set(A,B,Q,g),E.scissor.set(A,B,Q,g)}function p8(E,A,B){let Q=new Float32Array($Q),g=new x(0,1,0);return new HQ({name:"SphericalGaussianBlur",defines:{n:$Q,CUBEUV_TEXEL_WIDTH:1/A,CUBEUV_TEXEL_HEIGHT:1/B,CUBEUV_MAX_MIP:`${E}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:Q},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:g}},vertexShader:lw(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:LQ,depthTest:!1,depthWrite:!1})}function I7(){return new HQ({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:lw(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:LQ,depthTest:!1,depthWrite:!1})}function n7(){return new HQ({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:lw(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:LQ,depthTest:!1,depthWrite:!1})}function lw(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function F8(E){let A=new WeakMap,B=null;function Q(f){if(f&&f.isTexture){let C=f.mapping,e=C===Nf||C===Rf,P=C===ZE||C===VE;if(e||P)if(f.isRenderTargetTexture&&f.needsPMREMUpdate===!0){f.needsPMREMUpdate=!1;let D=A.get(f);return B===null&&(B=new hv(E)),D=e?B.fromEquirectangular(f,D):B.fromCubemap(f,D),A.set(f,D),D.texture}else{if(A.has(f))return A.get(f).texture;{let D=f.image;if(e&&D&&D.height>0||P&&D&&g(D)){B===null&&(B=new hv(E));let t=e?B.fromEquirectangular(f):B.fromCubemap(f);return A.set(f,t),f.addEventListener("dispose",v),t.texture}else return null}}}return f}function g(f){let C=0,e=6;for(let P=0;P<e;P++)f[P]!==void 0&&C++;return C===e}function v(f){let C=f.target;C.removeEventListener("dispose",v);let e=A.get(C);e!==void 0&&(A.delete(C),e.dispose())}function w(){A=new WeakMap,B!==null&&(B.dispose(),B=null)}return{get:Q,dispose:w}}function x8(E){let A={};function B(Q){if(A[Q]!==void 0)return A[Q];let g;switch(Q){case"WEBGL_depth_texture":g=E.getExtension("WEBGL_depth_texture")||E.getExtension("MOZ_WEBGL_depth_texture")||E.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":g=E.getExtension("EXT_texture_filter_anisotropic")||E.getExtension("MOZ_EXT_texture_filter_anisotropic")||E.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":g=E.getExtension("WEBGL_compressed_texture_s3tc")||E.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||E.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":g=E.getExtension("WEBGL_compressed_texture_pvrtc")||E.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:g=E.getExtension(Q)}return A[Q]=g,g}return{has:function(Q){return B(Q)!==null},init:function(Q){Q.isWebGL2?(B("EXT_color_buffer_float"),B("WEBGL_clip_cull_distance")):(B("WEBGL_depth_texture"),B("OES_texture_float"),B("OES_texture_half_float"),B("OES_texture_half_float_linear"),B("OES_standard_derivatives"),B("OES_element_index_uint"),B("OES_vertex_array_object"),B("ANGLE_instanced_arrays")),B("OES_texture_float_linear"),B("EXT_color_buffer_half_float"),B("WEBGL_multisampled_render_to_texture")},get:function(Q){let g=B(Q);return g===null&&console.warn("THREE.WebGLRenderer: "+Q+" extension not supported."),g}}}function G8(E,A,B,Q){let g={},v=new WeakMap;function w(D){let t=D.target;t.index!==null&&A.remove(t.index);for(let s in t.attributes)A.remove(t.attributes[s]);for(let s in t.morphAttributes){let i=t.morphAttributes[s];for(let r=0,I=i.length;r<I;r++)A.remove(i[r])}t.removeEventListener("dispose",w),delete g[t.id];let n=v.get(t);n&&(A.remove(n),v.delete(t)),Q.releaseStatesOfGeometry(t),t.isInstancedBufferGeometry===!0&&delete t._maxInstanceCount,B.memory.geometries--}function f(D,t){return g[t.id]===!0||(t.addEventListener("dispose",w),g[t.id]=!0,B.memory.geometries++),t}function C(D){let t=D.attributes;for(let s in t)A.update(t[s],E.ARRAY_BUFFER);let n=D.morphAttributes;for(let s in n){let i=n[s];for(let r=0,I=i.length;r<I;r++)A.update(i[r],E.ARRAY_BUFFER)}}function e(D){let t=[],n=D.index,s=D.attributes.position,i=0;if(n!==null){let H=n.array;i=n.version;for(let o=0,l=H.length;o<l;o+=3){let F=H[o+0],b=H[o+1],h=H[o+2];t.push(F,b,b,h,h,F)}}else if(s!==void 0){let H=s.array;i=s.version;for(let o=0,l=H.length/3-1;o<l;o+=3){let F=o+0,b=o+1,h=o+2;t.push(F,b,b,h,h,F)}}else return;let r=new(S7(t)?Hv:zv)(t,1);r.version=i;let I=v.get(D);I&&A.remove(I),v.set(D,r)}function P(D){let t=v.get(D);if(t){let n=D.index;n!==null&&t.version<n.version&&e(D)}else e(D);return v.get(D)}return{get:f,update:C,getWireframeAttribute:P}}function L8(E,A,B,Q){let g=Q.isWebGL2,v;function w(n){v=n}let f,C;function e(n){f=n.type,C=n.bytesPerElement}function P(n,s){E.drawElements(v,s,f,n*C),B.update(s,v,1)}function D(n,s,i){if(i===0)return;let r,I;if(g)r=E,I="drawElementsInstanced";else if(r=A.get("ANGLE_instanced_arrays"),I="drawElementsInstancedANGLE",r===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}r[I](v,s,f,n*C,i),B.update(s,v,i)}function t(n,s,i){if(i===0)return;let r=A.get("WEBGL_multi_draw");if(r===null)for(let I=0;I<i;I++)this.render(n[I]/C,s[I]);else{r.multiDrawElementsWEBGL(v,s,0,f,n,0,i);let I=0;for(let H=0;H<i;H++)I+=s[H];B.update(I,v,1)}}this.setMode=w,this.setIndex=e,this.render=P,this.renderInstances=D,this.renderMultiDraw=t}function U8(E){let A={geometries:0,textures:0},B={frame:0,calls:0,triangles:0,points:0,lines:0};function Q(v,w,f){switch(B.calls++,w){case E.TRIANGLES:B.triangles+=f*(v/3);break;case E.LINES:B.lines+=f*(v/2);break;case E.LINE_STRIP:B.lines+=f*(v-1);break;case E.LINE_LOOP:B.lines+=f*v;break;case E.POINTS:B.points+=f*v;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",w);break}}function g(){B.calls=0,B.triangles=0,B.points=0,B.lines=0}return{memory:A,render:B,programs:null,autoReset:!0,reset:g,update:Q}}function X8(E,A){return E[0]-A[0]}function Y8(E,A){return Math.abs(A[1])-Math.abs(E[1])}function T8(E,A,B){let Q={},g=new Float32Array(8),v=new WeakMap,w=new sB,f=[];for(let e=0;e<8;e++)f[e]=[e,0];function C(e,P,D){let t=e.morphTargetInfluences;if(A.isWebGL2===!0){let n=P.morphAttributes.position||P.morphAttributes.normal||P.morphAttributes.color,s=n!==void 0?n.length:0,i=v.get(P);if(i===void 0||i.count!==s){let p=function(){q.dispose(),v.delete(P),P.removeEventListener("dispose",p)};i!==void 0&&i.texture.dispose();let H=P.morphAttributes.position!==void 0,o=P.morphAttributes.normal!==void 0,l=P.morphAttributes.color!==void 0,F=P.morphAttributes.position||[],b=P.morphAttributes.normal||[],h=P.morphAttributes.color||[],Z=0;H===!0&&(Z=1),o===!0&&(Z=2),l===!0&&(Z=3);let a=P.attributes.position.count*Z,u=1;a>A.maxTextureSize&&(u=Math.ceil(a/A.maxTextureSize),a=A.maxTextureSize);let y=new Float32Array(a*u*4*s),q=new cv(y,a,u,s);q.type=GQ,q.needsUpdate=!0;let EA=Z*4;for(let L=0;L<s;L++){let N=F[L],k=b[L],V=h[L],R=a*u*4*L;for(let W=0;W<N.count;W++){let $=W*EA;H===!0&&(w.fromBufferAttribute(N,W),y[R+$+0]=w.x,y[R+$+1]=w.y,y[R+$+2]=w.z,y[R+$+3]=0),o===!0&&(w.fromBufferAttribute(k,W),y[R+$+4]=w.x,y[R+$+5]=w.y,y[R+$+6]=w.z,y[R+$+7]=0),l===!0&&(w.fromBufferAttribute(V,W),y[R+$+8]=w.x,y[R+$+9]=w.y,y[R+$+10]=w.z,y[R+$+11]=V.itemSize===4?w.w:1)}}i={count:s,texture:q,size:new hA(a,u)},v.set(P,i),P.addEventListener("dispose",p)}let r=0;for(let H=0;H<t.length;H++)r+=t[H];let I=P.morphTargetsRelative?1:1-r;D.getUniforms().setValue(E,"morphTargetBaseInfluence",I),D.getUniforms().setValue(E,"morphTargetInfluences",t),D.getUniforms().setValue(E,"morphTargetsTexture",i.texture,B),D.getUniforms().setValue(E,"morphTargetsTextureSize",i.size)}else{let n=t===void 0?0:t.length,s=Q[P.id];if(s===void 0||s.length!==n){s=[];for(let o=0;o<n;o++)s[o]=[o,0];Q[P.id]=s}for(let o=0;o<n;o++){let l=s[o];l[0]=o,l[1]=t[o]}s.sort(Y8);for(let o=0;o<8;o++)o<n&&s[o][1]?(f[o][0]=s[o][0],f[o][1]=s[o][1]):(f[o][0]=Number.MAX_SAFE_INTEGER,f[o][1]=0);f.sort(X8);let i=P.morphAttributes.position,r=P.morphAttributes.normal,I=0;for(let o=0;o<8;o++){let l=f[o],F=l[0],b=l[1];F!==Number.MAX_SAFE_INTEGER&&b?(i&&P.getAttribute("morphTarget"+o)!==i[F]&&P.setAttribute("morphTarget"+o,i[F]),r&&P.getAttribute("morphNormal"+o)!==r[F]&&P.setAttribute("morphNormal"+o,r[F]),g[o]=b,I+=b):(i&&P.hasAttribute("morphTarget"+o)===!0&&P.deleteAttribute("morphTarget"+o),r&&P.hasAttribute("morphNormal"+o)===!0&&P.deleteAttribute("morphNormal"+o),g[o]=0)}let H=P.morphTargetsRelative?1:1-I;D.getUniforms().setValue(E,"morphTargetBaseInfluence",H),D.getUniforms().setValue(E,"morphTargetInfluences",g)}}return{update:C}}function j8(E,A,B,Q){let g=new WeakMap;function v(C){let e=Q.render.frame,P=C.geometry,D=A.get(C,P);if(g.get(D)!==e&&(A.update(D),g.set(D,e)),C.isInstancedMesh&&(C.hasEventListener("dispose",f)===!1&&C.addEventListener("dispose",f),g.get(C)!==e&&(B.update(C.instanceMatrix,E.ARRAY_BUFFER),C.instanceColor!==null&&B.update(C.instanceColor,E.ARRAY_BUFFER),g.set(C,e))),C.isSkinnedMesh){let t=C.skeleton;g.get(t)!==e&&(t.update(),g.set(t,e))}return D}function w(){g=new WeakMap}function f(C){let e=C.target;e.removeEventListener("dispose",f),B.remove(e.instanceMatrix),e.instanceColor!==null&&B.remove(e.instanceColor)}return{update:v,dispose:w}}var bv=class extends RB{constructor(A,B,Q,g,v,w,f,C,e,P){if(P=P!==void 0?P:BE,P!==BE&&P!==kE)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");Q===void 0&&P===BE&&(Q=xQ),Q===void 0&&P===kE&&(Q=AE),super(null,g,v,w,f,C,P,Q,e),this.isDepthTexture=!0,this.image={width:A,height:B},this.magFilter=f!==void 0?f:hB,this.minFilter=C!==void 0?C:hB,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(A){return super.copy(A),this.compareFunction=A.compareFunction,this}toJSON(A){let B=super.toJSON(A);return this.compareFunction!==null&&(B.compareFunction=this.compareFunction),B}},Ae=new RB,Be=new bv(1,1);Be.compareFunction=J7;var Qe=new cv,Ee=new Wf,ge=new dv,r7=[],s7=[],i7=new Float32Array(16),M7=new Float32Array(9),o7=new Float32Array(4);function $E(E,A,B){let Q=E[0];if(Q<=0||Q>0)return E;let g=A*B,v=r7[g];if(v===void 0&&(v=new Float32Array(g),r7[g]=v),A!==0){Q.toArray(v,0);for(let w=1,f=0;w!==A;++w)f+=B,E[w].toArray(v,f)}return v}function PB(E,A){if(E.length!==A.length)return!1;for(let B=0,Q=E.length;B<Q;B++)if(E[B]!==A[B])return!1;return!0}function tB(E,A){for(let B=0,Q=A.length;B<Q;B++)E[B]=A[B]}function Xv(E,A){let B=s7[A];B===void 0&&(B=new Int32Array(A),s7[A]=B);for(let Q=0;Q!==A;++Q)B[Q]=E.allocateTextureUnit();return B}function y8(E,A){let B=this.cache;B[0]!==A&&(E.uniform1f(this.addr,A),B[0]=A)}function O8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y)&&(E.uniform2f(this.addr,A.x,A.y),B[0]=A.x,B[1]=A.y);else{if(PB(B,A))return;E.uniform2fv(this.addr,A),tB(B,A)}}function N8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z)&&(E.uniform3f(this.addr,A.x,A.y,A.z),B[0]=A.x,B[1]=A.y,B[2]=A.z);else if(A.r!==void 0)(B[0]!==A.r||B[1]!==A.g||B[2]!==A.b)&&(E.uniform3f(this.addr,A.r,A.g,A.b),B[0]=A.r,B[1]=A.g,B[2]=A.b);else{if(PB(B,A))return;E.uniform3fv(this.addr,A),tB(B,A)}}function R8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z||B[3]!==A.w)&&(E.uniform4f(this.addr,A.x,A.y,A.z,A.w),B[0]=A.x,B[1]=A.y,B[2]=A.z,B[3]=A.w);else{if(PB(B,A))return;E.uniform4fv(this.addr,A),tB(B,A)}}function Z8(E,A){let B=this.cache,Q=A.elements;if(Q===void 0){if(PB(B,A))return;E.uniformMatrix2fv(this.addr,!1,A),tB(B,A)}else{if(PB(B,Q))return;o7.set(Q),E.uniformMatrix2fv(this.addr,!1,o7),tB(B,Q)}}function V8(E,A){let B=this.cache,Q=A.elements;if(Q===void 0){if(PB(B,A))return;E.uniformMatrix3fv(this.addr,!1,A),tB(B,A)}else{if(PB(B,Q))return;M7.set(Q),E.uniformMatrix3fv(this.addr,!1,M7),tB(B,Q)}}function k8(E,A){let B=this.cache,Q=A.elements;if(Q===void 0){if(PB(B,A))return;E.uniformMatrix4fv(this.addr,!1,A),tB(B,A)}else{if(PB(B,Q))return;i7.set(Q),E.uniformMatrix4fv(this.addr,!1,i7),tB(B,Q)}}function q8(E,A){let B=this.cache;B[0]!==A&&(E.uniform1i(this.addr,A),B[0]=A)}function J8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y)&&(E.uniform2i(this.addr,A.x,A.y),B[0]=A.x,B[1]=A.y);else{if(PB(B,A))return;E.uniform2iv(this.addr,A),tB(B,A)}}function W8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z)&&(E.uniform3i(this.addr,A.x,A.y,A.z),B[0]=A.x,B[1]=A.y,B[2]=A.z);else{if(PB(B,A))return;E.uniform3iv(this.addr,A),tB(B,A)}}function S8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z||B[3]!==A.w)&&(E.uniform4i(this.addr,A.x,A.y,A.z,A.w),B[0]=A.x,B[1]=A.y,B[2]=A.z,B[3]=A.w);else{if(PB(B,A))return;E.uniform4iv(this.addr,A),tB(B,A)}}function K8(E,A){let B=this.cache;B[0]!==A&&(E.uniform1ui(this.addr,A),B[0]=A)}function _8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y)&&(E.uniform2ui(this.addr,A.x,A.y),B[0]=A.x,B[1]=A.y);else{if(PB(B,A))return;E.uniform2uiv(this.addr,A),tB(B,A)}}function $8(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z)&&(E.uniform3ui(this.addr,A.x,A.y,A.z),B[0]=A.x,B[1]=A.y,B[2]=A.z);else{if(PB(B,A))return;E.uniform3uiv(this.addr,A),tB(B,A)}}function An(E,A){let B=this.cache;if(A.x!==void 0)(B[0]!==A.x||B[1]!==A.y||B[2]!==A.z||B[3]!==A.w)&&(E.uniform4ui(this.addr,A.x,A.y,A.z,A.w),B[0]=A.x,B[1]=A.y,B[2]=A.z,B[3]=A.w);else{if(PB(B,A))return;E.uniform4uiv(this.addr,A),tB(B,A)}}function Bn(E,A,B){let Q=this.cache,g=B.allocateTextureUnit();Q[0]!==g&&(E.uniform1i(this.addr,g),Q[0]=g);let v=this.type===E.SAMPLER_2D_SHADOW?Be:Ae;B.setTexture2D(A||v,g)}function Qn(E,A,B){let Q=this.cache,g=B.allocateTextureUnit();Q[0]!==g&&(E.uniform1i(this.addr,g),Q[0]=g),B.setTexture3D(A||Ee,g)}function En(E,A,B){let Q=this.cache,g=B.allocateTextureUnit();Q[0]!==g&&(E.uniform1i(this.addr,g),Q[0]=g),B.setTextureCube(A||ge,g)}function gn(E,A,B){let Q=this.cache,g=B.allocateTextureUnit();Q[0]!==g&&(E.uniform1i(this.addr,g),Q[0]=g),B.setTexture2DArray(A||Qe,g)}function vn(E){switch(E){case 5126:return y8;case 35664:return O8;case 35665:return N8;case 35666:return R8;case 35674:return Z8;case 35675:return V8;case 35676:return k8;case 5124:case 35670:return q8;case 35667:case 35671:return J8;case 35668:case 35672:return W8;case 35669:case 35673:return S8;case 5125:return K8;case 36294:return _8;case 36295:return $8;case 36296:return An;case 35678:case 36198:case 36298:case 36306:case 35682:return Bn;case 35679:case 36299:case 36307:return Qn;case 35680:case 36300:case 36308:case 36293:return En;case 36289:case 36303:case 36311:case 36292:return gn}}function fn(E,A){E.uniform1fv(this.addr,A)}function wn(E,A){let B=$E(A,this.size,2);E.uniform2fv(this.addr,B)}function Cn(E,A){let B=$E(A,this.size,3);E.uniform3fv(this.addr,B)}function en(E,A){let B=$E(A,this.size,4);E.uniform4fv(this.addr,B)}function Pn(E,A){let B=$E(A,this.size,4);E.uniformMatrix2fv(this.addr,!1,B)}function tn(E,A){let B=$E(A,this.size,9);E.uniformMatrix3fv(this.addr,!1,B)}function Dn(E,A){let B=$E(A,this.size,16);E.uniformMatrix4fv(this.addr,!1,B)}function In(E,A){E.uniform1iv(this.addr,A)}function nn(E,A){E.uniform2iv(this.addr,A)}function rn(E,A){E.uniform3iv(this.addr,A)}function sn(E,A){E.uniform4iv(this.addr,A)}function Mn(E,A){E.uniform1uiv(this.addr,A)}function on(E,A){E.uniform2uiv(this.addr,A)}function cn(E,A){E.uniform3uiv(this.addr,A)}function an(E,A){E.uniform4uiv(this.addr,A)}function zn(E,A,B){let Q=this.cache,g=A.length,v=Xv(B,g);PB(Q,v)||(E.uniform1iv(this.addr,v),tB(Q,v));for(let w=0;w!==g;++w)B.setTexture2D(A[w]||Ae,v[w])}function Hn(E,A,B){let Q=this.cache,g=A.length,v=Xv(B,g);PB(Q,v)||(E.uniform1iv(this.addr,v),tB(Q,v));for(let w=0;w!==g;++w)B.setTexture3D(A[w]||Ee,v[w])}function un(E,A,B){let Q=this.cache,g=A.length,v=Xv(B,g);PB(Q,v)||(E.uniform1iv(this.addr,v),tB(Q,v));for(let w=0;w!==g;++w)B.setTextureCube(A[w]||ge,v[w])}function dn(E,A,B){let Q=this.cache,g=A.length,v=Xv(B,g);PB(Q,v)||(E.uniform1iv(this.addr,v),tB(Q,v));for(let w=0;w!==g;++w)B.setTexture2DArray(A[w]||Qe,v[w])}function ln(E){switch(E){case 5126:return fn;case 35664:return wn;case 35665:return Cn;case 35666:return en;case 35674:return Pn;case 35675:return tn;case 35676:return Dn;case 5124:case 35670:return In;case 35667:case 35671:return nn;case 35668:case 35672:return rn;case 35669:case 35673:return sn;case 5125:return Mn;case 36294:return on;case 36295:return cn;case 36296:return an;case 35678:case 36198:case 36298:case 36306:case 35682:return zn;case 35679:case 36299:case 36307:return Hn;case 35680:case 36300:case 36308:case 36293:return un;case 36289:case 36303:case 36311:case 36292:return dn}}var _f=class{constructor(A,B,Q){this.id=A,this.addr=Q,this.cache=[],this.type=B.type,this.setValue=vn(B.type)}},$f=class{constructor(A,B,Q){this.id=A,this.addr=Q,this.cache=[],this.type=B.type,this.size=B.size,this.setValue=ln(B.type)}},Aw=class{constructor(A){this.id=A,this.seq=[],this.map={}}setValue(A,B,Q){let g=this.seq;for(let v=0,w=g.length;v!==w;++v){let f=g[v];f.setValue(A,B[f.id],Q)}}},Yf=/(\w+)(\])?(\[|\.)?/g;function c7(E,A){E.seq.push(A),E.map[A.id]=A}function hn(E,A,B){let Q=E.name,g=Q.length;for(Yf.lastIndex=0;;){let v=Yf.exec(Q),w=Yf.lastIndex,f=v[1],C=v[2]==="]",e=v[3];if(C&&(f=f|0),e===void 0||e==="["&&w+2===g){c7(B,e===void 0?new _f(f,E,A):new $f(f,E,A));break}else{let D=B.map[f];D===void 0&&(D=new Aw(f),c7(B,D)),B=D}}}var RE=class{constructor(A,B){this.seq=[],this.map={};let Q=A.getProgramParameter(B,A.ACTIVE_UNIFORMS);for(let g=0;g<Q;++g){let v=A.getActiveUniform(B,g),w=A.getUniformLocation(B,v.name);hn(v,w,this)}}setValue(A,B,Q,g){let v=this.map[B];v!==void 0&&v.setValue(A,Q,g)}setOptional(A,B,Q){let g=B[Q];g!==void 0&&this.setValue(A,Q,g)}static upload(A,B,Q,g){for(let v=0,w=B.length;v!==w;++v){let f=B[v],C=Q[f.id];C.needsUpdate!==!1&&f.setValue(A,C.value,g)}}static seqWithValue(A,B){let Q=[];for(let g=0,v=A.length;g!==v;++g){let w=A[g];w.id in B&&Q.push(w)}return Q}};function a7(E,A,B){let Q=E.createShader(A);return E.shaderSource(Q,B),E.compileShader(Q),Q}var bn=37297,mn=0;function pn(E,A){let B=E.split(`
`),Q=[],g=Math.max(A-6,0),v=Math.min(A+6,B.length);for(let w=g;w<v;w++){let f=w+1;Q.push(`${f===A?">":" "} ${f}: ${B[w]}`)}return Q.join(`
`)}function Fn(E){let A=KA.getPrimaries(KA.workingColorSpace),B=KA.getPrimaries(E),Q;switch(A===B?Q="":A===nv&&B===Iv?Q="LinearDisplayP3ToLinearSRGB":A===Iv&&B===nv&&(Q="LinearSRGBToLinearDisplayP3"),E){case aQ:case Uv:return[Q,"LinearTransferOETF"];case eB:case uw:return[Q,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",E),[Q,"LinearTransferOETF"]}}function z7(E,A,B){let Q=E.getShaderParameter(A,E.COMPILE_STATUS),g=E.getShaderInfoLog(A).trim();if(Q&&g==="")return"";let v=/ERROR: 0:(\d+)/.exec(g);if(v){let w=parseInt(v[1]);return B.toUpperCase()+`

`+g+`

`+pn(E.getShaderSource(A),w)}else return g}function xn(E,A){let B=Fn(A);return`vec4 ${E}( vec4 value ) { return ${B[0]}( ${B[1]}( value ) ); }`}function Gn(E,A){let B;switch(A){case TP:B="Linear";break;case jP:B="Reinhard";break;case yP:B="OptimizedCineon";break;case zw:B="ACESFilmic";break;case NP:B="AgX";break;case OP:B="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",A),B="Linear"}return"vec3 "+E+"( vec3 color ) { return "+B+"ToneMapping( color ); }"}function Ln(E){return[E.extensionDerivatives||E.envMapCubeUVHeight||E.bumpMap||E.normalMapTangentSpace||E.clearcoatNormalMap||E.flatShading||E.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(E.extensionFragDepth||E.logarithmicDepthBuffer)&&E.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",E.extensionDrawBuffers&&E.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(E.extensionShaderTextureLOD||E.envMap||E.transmission)&&E.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(yE).join(`
`)}function Un(E){return[E.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(yE).join(`
`)}function Xn(E){let A=[];for(let B in E){let Q=E[B];Q!==!1&&A.push("#define "+B+" "+Q)}return A.join(`
`)}function Yn(E,A){let B={},Q=E.getProgramParameter(A,E.ACTIVE_ATTRIBUTES);for(let g=0;g<Q;g++){let v=E.getActiveAttrib(A,g),w=v.name,f=1;v.type===E.FLOAT_MAT2&&(f=2),v.type===E.FLOAT_MAT3&&(f=3),v.type===E.FLOAT_MAT4&&(f=4),B[w]={type:v.type,location:E.getAttribLocation(A,w),locationSize:f}}return B}function yE(E){return E!==""}function H7(E,A){let B=A.numSpotLightShadows+A.numSpotLightMaps-A.numSpotLightShadowsWithMaps;return E.replace(/NUM_DIR_LIGHTS/g,A.numDirLights).replace(/NUM_SPOT_LIGHTS/g,A.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,A.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,B).replace(/NUM_RECT_AREA_LIGHTS/g,A.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,A.numPointLights).replace(/NUM_HEMI_LIGHTS/g,A.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,A.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,A.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,A.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,A.numPointLightShadows)}function u7(E,A){return E.replace(/NUM_CLIPPING_PLANES/g,A.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,A.numClippingPlanes-A.numClipIntersection)}var Tn=/^[ \t]*#include +<([\w\d./]+)>/gm;function Bw(E){return E.replace(Tn,yn)}var jn=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function yn(E,A){let B=XA[A];if(B===void 0){let Q=jn.get(A);if(Q!==void 0)B=XA[Q],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',A,Q);else throw new Error("Can not resolve #include <"+A+">")}return Bw(B)}var On=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function d7(E){return E.replace(On,Nn)}function Nn(E,A,B,Q){let g="";for(let v=parseInt(A);v<parseInt(B);v++)g+=Q.replace(/\[\s*i\s*\]/g,"[ "+v+" ]").replace(/UNROLLED_LOOP_INDEX/g,v);return g}function l7(E){let A="precision "+E.precision+` float;
precision `+E.precision+" int;";return E.precision==="highp"?A+=`
#define HIGH_PRECISION`:E.precision==="mediump"?A+=`
#define MEDIUM_PRECISION`:E.precision==="lowp"&&(A+=`
#define LOW_PRECISION`),A}function Rn(E){let A="SHADOWMAP_TYPE_BASIC";return E.shadowMapType===X7?A="SHADOWMAP_TYPE_PCF":E.shadowMapType===DP?A="SHADOWMAP_TYPE_PCF_SOFT":E.shadowMapType===MQ&&(A="SHADOWMAP_TYPE_VSM"),A}function Zn(E){let A="ENVMAP_TYPE_CUBE";if(E.envMap)switch(E.envMapMode){case ZE:case VE:A="ENVMAP_TYPE_CUBE";break;case Lv:A="ENVMAP_TYPE_CUBE_UV";break}return A}function Vn(E){let A="ENVMAP_MODE_REFLECTION";return E.envMap&&E.envMapMode===VE&&(A="ENVMAP_MODE_REFRACTION"),A}function kn(E){let A="ENVMAP_BLENDING_NONE";if(E.envMap)switch(E.combine){case Y7:A="ENVMAP_BLENDING_MULTIPLY";break;case XP:A="ENVMAP_BLENDING_MIX";break;case YP:A="ENVMAP_BLENDING_ADD";break}return A}function qn(E){let A=E.envMapCubeUVHeight;if(A===null)return null;let B=Math.log2(A)-2,Q=1/A;return{texelWidth:1/(3*Math.max(Math.pow(2,B),112)),texelHeight:Q,maxMip:B}}function Jn(E,A,B,Q){let g=E.getContext(),v=B.defines,w=B.vertexShader,f=B.fragmentShader,C=Rn(B),e=Zn(B),P=Vn(B),D=kn(B),t=qn(B),n=B.isWebGL2?"":Ln(B),s=Un(B),i=Xn(v),r=g.createProgram(),I,H,o=B.glslVersion?"#version "+B.glslVersion+`
`:"";B.isRawShaderMaterial?(I=["#define SHADER_TYPE "+B.shaderType,"#define SHADER_NAME "+B.shaderName,i].filter(yE).join(`
`),I.length>0&&(I+=`
`),H=[n,"#define SHADER_TYPE "+B.shaderType,"#define SHADER_NAME "+B.shaderName,i].filter(yE).join(`
`),H.length>0&&(H+=`
`)):(I=[l7(B),"#define SHADER_TYPE "+B.shaderType,"#define SHADER_NAME "+B.shaderName,i,B.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",B.batching?"#define USE_BATCHING":"",B.instancing?"#define USE_INSTANCING":"",B.instancingColor?"#define USE_INSTANCING_COLOR":"",B.useFog&&B.fog?"#define USE_FOG":"",B.useFog&&B.fogExp2?"#define FOG_EXP2":"",B.map?"#define USE_MAP":"",B.envMap?"#define USE_ENVMAP":"",B.envMap?"#define "+P:"",B.lightMap?"#define USE_LIGHTMAP":"",B.aoMap?"#define USE_AOMAP":"",B.bumpMap?"#define USE_BUMPMAP":"",B.normalMap?"#define USE_NORMALMAP":"",B.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",B.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",B.displacementMap?"#define USE_DISPLACEMENTMAP":"",B.emissiveMap?"#define USE_EMISSIVEMAP":"",B.anisotropy?"#define USE_ANISOTROPY":"",B.anisotropyMap?"#define USE_ANISOTROPYMAP":"",B.clearcoatMap?"#define USE_CLEARCOATMAP":"",B.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",B.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",B.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",B.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",B.specularMap?"#define USE_SPECULARMAP":"",B.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",B.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",B.roughnessMap?"#define USE_ROUGHNESSMAP":"",B.metalnessMap?"#define USE_METALNESSMAP":"",B.alphaMap?"#define USE_ALPHAMAP":"",B.alphaHash?"#define USE_ALPHAHASH":"",B.transmission?"#define USE_TRANSMISSION":"",B.transmissionMap?"#define USE_TRANSMISSIONMAP":"",B.thicknessMap?"#define USE_THICKNESSMAP":"",B.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",B.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",B.mapUv?"#define MAP_UV "+B.mapUv:"",B.alphaMapUv?"#define ALPHAMAP_UV "+B.alphaMapUv:"",B.lightMapUv?"#define LIGHTMAP_UV "+B.lightMapUv:"",B.aoMapUv?"#define AOMAP_UV "+B.aoMapUv:"",B.emissiveMapUv?"#define EMISSIVEMAP_UV "+B.emissiveMapUv:"",B.bumpMapUv?"#define BUMPMAP_UV "+B.bumpMapUv:"",B.normalMapUv?"#define NORMALMAP_UV "+B.normalMapUv:"",B.displacementMapUv?"#define DISPLACEMENTMAP_UV "+B.displacementMapUv:"",B.metalnessMapUv?"#define METALNESSMAP_UV "+B.metalnessMapUv:"",B.roughnessMapUv?"#define ROUGHNESSMAP_UV "+B.roughnessMapUv:"",B.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+B.anisotropyMapUv:"",B.clearcoatMapUv?"#define CLEARCOATMAP_UV "+B.clearcoatMapUv:"",B.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+B.clearcoatNormalMapUv:"",B.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+B.clearcoatRoughnessMapUv:"",B.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+B.iridescenceMapUv:"",B.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+B.iridescenceThicknessMapUv:"",B.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+B.sheenColorMapUv:"",B.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+B.sheenRoughnessMapUv:"",B.specularMapUv?"#define SPECULARMAP_UV "+B.specularMapUv:"",B.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+B.specularColorMapUv:"",B.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+B.specularIntensityMapUv:"",B.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+B.transmissionMapUv:"",B.thicknessMapUv?"#define THICKNESSMAP_UV "+B.thicknessMapUv:"",B.vertexTangents&&B.flatShading===!1?"#define USE_TANGENT":"",B.vertexColors?"#define USE_COLOR":"",B.vertexAlphas?"#define USE_COLOR_ALPHA":"",B.vertexUv1s?"#define USE_UV1":"",B.vertexUv2s?"#define USE_UV2":"",B.vertexUv3s?"#define USE_UV3":"",B.pointsUvs?"#define USE_POINTS_UV":"",B.flatShading?"#define FLAT_SHADED":"",B.skinning?"#define USE_SKINNING":"",B.morphTargets?"#define USE_MORPHTARGETS":"",B.morphNormals&&B.flatShading===!1?"#define USE_MORPHNORMALS":"",B.morphColors&&B.isWebGL2?"#define USE_MORPHCOLORS":"",B.morphTargetsCount>0&&B.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",B.morphTargetsCount>0&&B.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+B.morphTextureStride:"",B.morphTargetsCount>0&&B.isWebGL2?"#define MORPHTARGETS_COUNT "+B.morphTargetsCount:"",B.doubleSided?"#define DOUBLE_SIDED":"",B.flipSided?"#define FLIP_SIDED":"",B.shadowMapEnabled?"#define USE_SHADOWMAP":"",B.shadowMapEnabled?"#define "+C:"",B.sizeAttenuation?"#define USE_SIZEATTENUATION":"",B.numLightProbes>0?"#define USE_LIGHT_PROBES":"",B.useLegacyLights?"#define LEGACY_LIGHTS":"",B.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",B.logarithmicDepthBuffer&&B.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(yE).join(`
`),H=[n,l7(B),"#define SHADER_TYPE "+B.shaderType,"#define SHADER_NAME "+B.shaderName,i,B.useFog&&B.fog?"#define USE_FOG":"",B.useFog&&B.fogExp2?"#define FOG_EXP2":"",B.map?"#define USE_MAP":"",B.matcap?"#define USE_MATCAP":"",B.envMap?"#define USE_ENVMAP":"",B.envMap?"#define "+e:"",B.envMap?"#define "+P:"",B.envMap?"#define "+D:"",t?"#define CUBEUV_TEXEL_WIDTH "+t.texelWidth:"",t?"#define CUBEUV_TEXEL_HEIGHT "+t.texelHeight:"",t?"#define CUBEUV_MAX_MIP "+t.maxMip+".0":"",B.lightMap?"#define USE_LIGHTMAP":"",B.aoMap?"#define USE_AOMAP":"",B.bumpMap?"#define USE_BUMPMAP":"",B.normalMap?"#define USE_NORMALMAP":"",B.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",B.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",B.emissiveMap?"#define USE_EMISSIVEMAP":"",B.anisotropy?"#define USE_ANISOTROPY":"",B.anisotropyMap?"#define USE_ANISOTROPYMAP":"",B.clearcoat?"#define USE_CLEARCOAT":"",B.clearcoatMap?"#define USE_CLEARCOATMAP":"",B.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",B.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",B.iridescence?"#define USE_IRIDESCENCE":"",B.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",B.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",B.specularMap?"#define USE_SPECULARMAP":"",B.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",B.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",B.roughnessMap?"#define USE_ROUGHNESSMAP":"",B.metalnessMap?"#define USE_METALNESSMAP":"",B.alphaMap?"#define USE_ALPHAMAP":"",B.alphaTest?"#define USE_ALPHATEST":"",B.alphaHash?"#define USE_ALPHAHASH":"",B.sheen?"#define USE_SHEEN":"",B.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",B.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",B.transmission?"#define USE_TRANSMISSION":"",B.transmissionMap?"#define USE_TRANSMISSIONMAP":"",B.thicknessMap?"#define USE_THICKNESSMAP":"",B.vertexTangents&&B.flatShading===!1?"#define USE_TANGENT":"",B.vertexColors||B.instancingColor?"#define USE_COLOR":"",B.vertexAlphas?"#define USE_COLOR_ALPHA":"",B.vertexUv1s?"#define USE_UV1":"",B.vertexUv2s?"#define USE_UV2":"",B.vertexUv3s?"#define USE_UV3":"",B.pointsUvs?"#define USE_POINTS_UV":"",B.gradientMap?"#define USE_GRADIENTMAP":"",B.flatShading?"#define FLAT_SHADED":"",B.doubleSided?"#define DOUBLE_SIDED":"",B.flipSided?"#define FLIP_SIDED":"",B.shadowMapEnabled?"#define USE_SHADOWMAP":"",B.shadowMapEnabled?"#define "+C:"",B.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",B.numLightProbes>0?"#define USE_LIGHT_PROBES":"",B.useLegacyLights?"#define LEGACY_LIGHTS":"",B.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",B.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",B.logarithmicDepthBuffer&&B.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",B.toneMapping!==UQ?"#define TONE_MAPPING":"",B.toneMapping!==UQ?XA.tonemapping_pars_fragment:"",B.toneMapping!==UQ?Gn("toneMapping",B.toneMapping):"",B.dithering?"#define DITHERING":"",B.opaque?"#define OPAQUE":"",XA.colorspace_pars_fragment,xn("linearToOutputTexel",B.outputColorSpace),B.useDepthPacking?"#define DEPTH_PACKING "+B.depthPacking:"",`
`].filter(yE).join(`
`)),w=Bw(w),w=H7(w,B),w=u7(w,B),f=Bw(f),f=H7(f,B),f=u7(f,B),w=d7(w),f=d7(f),B.isWebGL2&&B.isRawShaderMaterial!==!0&&(o=`#version 300 es
`,I=[s,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+I,H=["precision mediump sampler2DArray;","#define varying in",B.glslVersion===VC?"":"layout(location = 0) out highp vec4 pc_fragColor;",B.glslVersion===VC?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+H);let l=o+I+w,F=o+H+f,b=a7(g,g.VERTEX_SHADER,l),h=a7(g,g.FRAGMENT_SHADER,F);g.attachShader(r,b),g.attachShader(r,h),B.index0AttributeName!==void 0?g.bindAttribLocation(r,0,B.index0AttributeName):B.morphTargets===!0&&g.bindAttribLocation(r,0,"position"),g.linkProgram(r);function Z(q){if(E.debug.checkShaderErrors){let EA=g.getProgramInfoLog(r).trim(),p=g.getShaderInfoLog(b).trim(),L=g.getShaderInfoLog(h).trim(),N=!0,k=!0;if(g.getProgramParameter(r,g.LINK_STATUS)===!1)if(N=!1,typeof E.debug.onShaderError=="function")E.debug.onShaderError(g,r,b,h);else{let V=z7(g,b,"vertex"),R=z7(g,h,"fragment");console.error("THREE.WebGLProgram: Shader Error "+g.getError()+" - VALIDATE_STATUS "+g.getProgramParameter(r,g.VALIDATE_STATUS)+`

Program Info Log: `+EA+`
`+V+`
`+R)}else EA!==""?console.warn("THREE.WebGLProgram: Program Info Log:",EA):(p===""||L==="")&&(k=!1);k&&(q.diagnostics={runnable:N,programLog:EA,vertexShader:{log:p,prefix:I},fragmentShader:{log:L,prefix:H}})}g.deleteShader(b),g.deleteShader(h),a=new RE(g,r),u=Yn(g,r)}let a;this.getUniforms=function(){return a===void 0&&Z(this),a};let u;this.getAttributes=function(){return u===void 0&&Z(this),u};let y=B.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return y===!1&&(y=g.getProgramParameter(r,bn)),y},this.destroy=function(){Q.releaseStatesOfProgram(this),g.deleteProgram(r),this.program=void 0},this.type=B.shaderType,this.name=B.shaderName,this.id=mn++,this.cacheKey=A,this.usedTimes=1,this.program=r,this.vertexShader=b,this.fragmentShader=h,this}var Wn=0,Qw=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(A){let B=A.vertexShader,Q=A.fragmentShader,g=this._getShaderStage(B),v=this._getShaderStage(Q),w=this._getShaderCacheForMaterial(A);return w.has(g)===!1&&(w.add(g),g.usedTimes++),w.has(v)===!1&&(w.add(v),v.usedTimes++),this}remove(A){let B=this.materialCache.get(A);for(let Q of B)Q.usedTimes--,Q.usedTimes===0&&this.shaderCache.delete(Q.code);return this.materialCache.delete(A),this}getVertexShaderID(A){return this._getShaderStage(A.vertexShader).id}getFragmentShaderID(A){return this._getShaderStage(A.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(A){let B=this.materialCache,Q=B.get(A);return Q===void 0&&(Q=new Set,B.set(A,Q)),Q}_getShaderStage(A){let B=this.shaderCache,Q=B.get(A);return Q===void 0&&(Q=new Ew(A),B.set(A,Q)),Q}},Ew=class{constructor(A){this.id=Wn++,this.code=A,this.usedTimes=0}};function Sn(E,A,B,Q,g,v,w){let f=new cg,C=new Qw,e=[],P=g.isWebGL2,D=g.logarithmicDepthBuffer,t=g.vertexTextures,n=g.precision,s={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function i(a){return a===0?"uv":`uv${a}`}function r(a,u,y,q,EA){let p=q.fog,L=EA.geometry,N=a.isMeshStandardMaterial?q.environment:null,k=(a.isMeshStandardMaterial?B:A).get(a.envMap||N),V=k&&k.mapping===Lv?k.image.height:null,R=s[a.type];a.precision!==null&&(n=g.getMaxPrecision(a.precision),n!==a.precision&&console.warn("THREE.WebGLProgram.getParameters:",a.precision,"not supported, using",n,"instead."));let W=L.morphAttributes.position||L.morphAttributes.normal||L.morphAttributes.color,$=W!==void 0?W.length:0,eA=0;L.morphAttributes.position!==void 0&&(eA=1),L.morphAttributes.normal!==void 0&&(eA=2),L.morphAttributes.color!==void 0&&(eA=3);let O,S,tA,MA;if(R){let HB=vQ[R];O=HB.vertexShader,S=HB.fragmentShader}else O=a.vertexShader,S=a.fragmentShader,C.update(a),tA=C.getVertexShaderID(a),MA=C.getFragmentShaderID(a);let sA=E.getRenderTarget(),pA=EA.isInstancedMesh===!0,FA=EA.isBatchedMesh===!0,HA=!!a.map,ZA=!!a.matcap,U=!!k,DB=!!a.aoMap,aA=!!a.lightMap,bA=!!a.bumpMap,nA=!!a.normalMap,BB=!!a.displacementMap,xA=!!a.emissiveMap,z=!!a.metalnessMap,M=!!a.roughnessMap,X=a.anisotropy>0,BA=a.clearcoat>0,_=a.iridescence>0,AA=a.sheen>0,rA=a.transmission>0,PA=X&&!!a.anisotropyMap,IA=BA&&!!a.clearcoatMap,uA=BA&&!!a.clearcoatNormalMap,LA=BA&&!!a.clearcoatRoughnessMap,K=_&&!!a.iridescenceMap,VA=_&&!!a.iridescenceThicknessMap,d=AA&&!!a.sheenColorMap,J=AA&&!!a.sheenRoughnessMap,wA=!!a.specularMap,QA=!!a.specularColorMap,iA=!!a.specularIntensityMap,yA=rA&&!!a.transmissionMap,kA=rA&&!!a.thicknessMap,YA=!!a.gradientMap,fA=!!a.alphaMap,m=a.alphaTest>0,gA=!!a.alphaHash,vA=!!a.extensions,zA=!!L.attributes.uv1,oA=!!L.attributes.uv2,JA=!!L.attributes.uv3,WA=UQ;return a.toneMapped&&(sA===null||sA.isXRRenderTarget===!0)&&(WA=E.toneMapping),{isWebGL2:P,shaderID:R,shaderType:a.type,shaderName:a.name,vertexShader:O,fragmentShader:S,defines:a.defines,customVertexShaderID:tA,customFragmentShaderID:MA,isRawShaderMaterial:a.isRawShaderMaterial===!0,glslVersion:a.glslVersion,precision:n,batching:FA,instancing:pA,instancingColor:pA&&EA.instanceColor!==null,supportsVertexTextures:t,outputColorSpace:sA===null?E.outputColorSpace:sA.isXRRenderTarget===!0?sA.texture.colorSpace:aQ,map:HA,matcap:ZA,envMap:U,envMapMode:U&&k.mapping,envMapCubeUVHeight:V,aoMap:DB,lightMap:aA,bumpMap:bA,normalMap:nA,displacementMap:t&&BB,emissiveMap:xA,normalMapObjectSpace:nA&&a.normalMapType===At,normalMapTangentSpace:nA&&a.normalMapType===q7,metalnessMap:z,roughnessMap:M,anisotropy:X,anisotropyMap:PA,clearcoat:BA,clearcoatMap:IA,clearcoatNormalMap:uA,clearcoatRoughnessMap:LA,iridescence:_,iridescenceMap:K,iridescenceThicknessMap:VA,sheen:AA,sheenColorMap:d,sheenRoughnessMap:J,specularMap:wA,specularColorMap:QA,specularIntensityMap:iA,transmission:rA,transmissionMap:yA,thicknessMap:kA,gradientMap:YA,opaque:a.transparent===!1&&a.blending===OE,alphaMap:fA,alphaTest:m,alphaHash:gA,combine:a.combine,mapUv:HA&&i(a.map.channel),aoMapUv:DB&&i(a.aoMap.channel),lightMapUv:aA&&i(a.lightMap.channel),bumpMapUv:bA&&i(a.bumpMap.channel),normalMapUv:nA&&i(a.normalMap.channel),displacementMapUv:BB&&i(a.displacementMap.channel),emissiveMapUv:xA&&i(a.emissiveMap.channel),metalnessMapUv:z&&i(a.metalnessMap.channel),roughnessMapUv:M&&i(a.roughnessMap.channel),anisotropyMapUv:PA&&i(a.anisotropyMap.channel),clearcoatMapUv:IA&&i(a.clearcoatMap.channel),clearcoatNormalMapUv:uA&&i(a.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:LA&&i(a.clearcoatRoughnessMap.channel),iridescenceMapUv:K&&i(a.iridescenceMap.channel),iridescenceThicknessMapUv:VA&&i(a.iridescenceThicknessMap.channel),sheenColorMapUv:d&&i(a.sheenColorMap.channel),sheenRoughnessMapUv:J&&i(a.sheenRoughnessMap.channel),specularMapUv:wA&&i(a.specularMap.channel),specularColorMapUv:QA&&i(a.specularColorMap.channel),specularIntensityMapUv:iA&&i(a.specularIntensityMap.channel),transmissionMapUv:yA&&i(a.transmissionMap.channel),thicknessMapUv:kA&&i(a.thicknessMap.channel),alphaMapUv:fA&&i(a.alphaMap.channel),vertexTangents:!!L.attributes.tangent&&(nA||X),vertexColors:a.vertexColors,vertexAlphas:a.vertexColors===!0&&!!L.attributes.color&&L.attributes.color.itemSize===4,vertexUv1s:zA,vertexUv2s:oA,vertexUv3s:JA,pointsUvs:EA.isPoints===!0&&!!L.attributes.uv&&(HA||fA),fog:!!p,useFog:a.fog===!0,fogExp2:p&&p.isFogExp2,flatShading:a.flatShading===!0,sizeAttenuation:a.sizeAttenuation===!0,logarithmicDepthBuffer:D,skinning:EA.isSkinnedMesh===!0,morphTargets:L.morphAttributes.position!==void 0,morphNormals:L.morphAttributes.normal!==void 0,morphColors:L.morphAttributes.color!==void 0,morphTargetsCount:$,morphTextureStride:eA,numDirLights:u.directional.length,numPointLights:u.point.length,numSpotLights:u.spot.length,numSpotLightMaps:u.spotLightMap.length,numRectAreaLights:u.rectArea.length,numHemiLights:u.hemi.length,numDirLightShadows:u.directionalShadowMap.length,numPointLightShadows:u.pointShadowMap.length,numSpotLightShadows:u.spotShadowMap.length,numSpotLightShadowsWithMaps:u.numSpotLightShadowsWithMaps,numLightProbes:u.numLightProbes,numClippingPlanes:w.numPlanes,numClipIntersection:w.numIntersection,dithering:a.dithering,shadowMapEnabled:E.shadowMap.enabled&&y.length>0,shadowMapType:E.shadowMap.type,toneMapping:WA,useLegacyLights:E._useLegacyLights,decodeVideoTexture:HA&&a.map.isVideoTexture===!0&&KA.getTransfer(a.map.colorSpace)===QB,premultipliedAlpha:a.premultipliedAlpha,doubleSided:a.side===yB,flipSided:a.side===FB,useDepthPacking:a.depthPacking>=0,depthPacking:a.depthPacking||0,index0AttributeName:a.index0AttributeName,extensionDerivatives:vA&&a.extensions.derivatives===!0,extensionFragDepth:vA&&a.extensions.fragDepth===!0,extensionDrawBuffers:vA&&a.extensions.drawBuffers===!0,extensionShaderTextureLOD:vA&&a.extensions.shaderTextureLOD===!0,extensionClipCullDistance:vA&&a.extensions.clipCullDistance&&Q.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:P||Q.has("EXT_frag_depth"),rendererExtensionDrawBuffers:P||Q.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:P||Q.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:Q.has("KHR_parallel_shader_compile"),customProgramCacheKey:a.customProgramCacheKey()}}function I(a){let u=[];if(a.shaderID?u.push(a.shaderID):(u.push(a.customVertexShaderID),u.push(a.customFragmentShaderID)),a.defines!==void 0)for(let y in a.defines)u.push(y),u.push(a.defines[y]);return a.isRawShaderMaterial===!1&&(H(u,a),o(u,a),u.push(E.outputColorSpace)),u.push(a.customProgramCacheKey),u.join()}function H(a,u){a.push(u.precision),a.push(u.outputColorSpace),a.push(u.envMapMode),a.push(u.envMapCubeUVHeight),a.push(u.mapUv),a.push(u.alphaMapUv),a.push(u.lightMapUv),a.push(u.aoMapUv),a.push(u.bumpMapUv),a.push(u.normalMapUv),a.push(u.displacementMapUv),a.push(u.emissiveMapUv),a.push(u.metalnessMapUv),a.push(u.roughnessMapUv),a.push(u.anisotropyMapUv),a.push(u.clearcoatMapUv),a.push(u.clearcoatNormalMapUv),a.push(u.clearcoatRoughnessMapUv),a.push(u.iridescenceMapUv),a.push(u.iridescenceThicknessMapUv),a.push(u.sheenColorMapUv),a.push(u.sheenRoughnessMapUv),a.push(u.specularMapUv),a.push(u.specularColorMapUv),a.push(u.specularIntensityMapUv),a.push(u.transmissionMapUv),a.push(u.thicknessMapUv),a.push(u.combine),a.push(u.fogExp2),a.push(u.sizeAttenuation),a.push(u.morphTargetsCount),a.push(u.morphAttributeCount),a.push(u.numDirLights),a.push(u.numPointLights),a.push(u.numSpotLights),a.push(u.numSpotLightMaps),a.push(u.numHemiLights),a.push(u.numRectAreaLights),a.push(u.numDirLightShadows),a.push(u.numPointLightShadows),a.push(u.numSpotLightShadows),a.push(u.numSpotLightShadowsWithMaps),a.push(u.numLightProbes),a.push(u.shadowMapType),a.push(u.toneMapping),a.push(u.numClippingPlanes),a.push(u.numClipIntersection),a.push(u.depthPacking)}function o(a,u){f.disableAll(),u.isWebGL2&&f.enable(0),u.supportsVertexTextures&&f.enable(1),u.instancing&&f.enable(2),u.instancingColor&&f.enable(3),u.matcap&&f.enable(4),u.envMap&&f.enable(5),u.normalMapObjectSpace&&f.enable(6),u.normalMapTangentSpace&&f.enable(7),u.clearcoat&&f.enable(8),u.iridescence&&f.enable(9),u.alphaTest&&f.enable(10),u.vertexColors&&f.enable(11),u.vertexAlphas&&f.enable(12),u.vertexUv1s&&f.enable(13),u.vertexUv2s&&f.enable(14),u.vertexUv3s&&f.enable(15),u.vertexTangents&&f.enable(16),u.anisotropy&&f.enable(17),u.alphaHash&&f.enable(18),u.batching&&f.enable(19),a.push(f.mask),f.disableAll(),u.fog&&f.enable(0),u.useFog&&f.enable(1),u.flatShading&&f.enable(2),u.logarithmicDepthBuffer&&f.enable(3),u.skinning&&f.enable(4),u.morphTargets&&f.enable(5),u.morphNormals&&f.enable(6),u.morphColors&&f.enable(7),u.premultipliedAlpha&&f.enable(8),u.shadowMapEnabled&&f.enable(9),u.useLegacyLights&&f.enable(10),u.doubleSided&&f.enable(11),u.flipSided&&f.enable(12),u.useDepthPacking&&f.enable(13),u.dithering&&f.enable(14),u.transmission&&f.enable(15),u.sheen&&f.enable(16),u.opaque&&f.enable(17),u.pointsUvs&&f.enable(18),u.decodeVideoTexture&&f.enable(19),a.push(f.mask)}function l(a){let u=s[a.type],y;if(u){let q=vQ[u];y=Tt.clone(q.uniforms)}else y=a.uniforms;return y}function F(a,u){let y;for(let q=0,EA=e.length;q<EA;q++){let p=e[q];if(p.cacheKey===u){y=p,++y.usedTimes;break}}return y===void 0&&(y=new Jn(E,u,a,v),e.push(y)),y}function b(a){if(--a.usedTimes===0){let u=e.indexOf(a);e[u]=e[e.length-1],e.pop(),a.destroy()}}function h(a){C.remove(a)}function Z(){C.dispose()}return{getParameters:r,getProgramCacheKey:I,getUniforms:l,acquireProgram:F,releaseProgram:b,releaseShaderCache:h,programs:e,dispose:Z}}function Kn(){let E=new WeakMap;function A(v){let w=E.get(v);return w===void 0&&(w={},E.set(v,w)),w}function B(v){E.delete(v)}function Q(v,w,f){E.get(v)[w]=f}function g(){E=new WeakMap}return{get:A,remove:B,update:Q,dispose:g}}function _n(E,A){return E.groupOrder!==A.groupOrder?E.groupOrder-A.groupOrder:E.renderOrder!==A.renderOrder?E.renderOrder-A.renderOrder:E.material.id!==A.material.id?E.material.id-A.material.id:E.z!==A.z?E.z-A.z:E.id-A.id}function h7(E,A){return E.groupOrder!==A.groupOrder?E.groupOrder-A.groupOrder:E.renderOrder!==A.renderOrder?E.renderOrder-A.renderOrder:E.z!==A.z?A.z-E.z:E.id-A.id}function b7(){let E=[],A=0,B=[],Q=[],g=[];function v(){A=0,B.length=0,Q.length=0,g.length=0}function w(D,t,n,s,i,r){let I=E[A];return I===void 0?(I={id:D.id,object:D,geometry:t,material:n,groupOrder:s,renderOrder:D.renderOrder,z:i,group:r},E[A]=I):(I.id=D.id,I.object=D,I.geometry=t,I.material=n,I.groupOrder=s,I.renderOrder=D.renderOrder,I.z=i,I.group=r),A++,I}function f(D,t,n,s,i,r){let I=w(D,t,n,s,i,r);n.transmission>0?Q.push(I):n.transparent===!0?g.push(I):B.push(I)}function C(D,t,n,s,i,r){let I=w(D,t,n,s,i,r);n.transmission>0?Q.unshift(I):n.transparent===!0?g.unshift(I):B.unshift(I)}function e(D,t){B.length>1&&B.sort(D||_n),Q.length>1&&Q.sort(t||h7),g.length>1&&g.sort(t||h7)}function P(){for(let D=A,t=E.length;D<t;D++){let n=E[D];if(n.id===null)break;n.id=null,n.object=null,n.geometry=null,n.material=null,n.group=null}}return{opaque:B,transmissive:Q,transparent:g,init:v,push:f,unshift:C,finish:P,sort:e}}function $n(){let E=new WeakMap;function A(Q,g){let v=E.get(Q),w;return v===void 0?(w=new b7,E.set(Q,[w])):g>=v.length?(w=new b7,v.push(w)):w=v[g],w}function B(){E=new WeakMap}return{get:A,dispose:B}}function A9(){let E={};return{get:function(A){if(E[A.id]!==void 0)return E[A.id];let B;switch(A.type){case"DirectionalLight":B={direction:new x,color:new lA};break;case"SpotLight":B={position:new x,direction:new x,color:new lA,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":B={position:new x,color:new lA,distance:0,decay:0};break;case"HemisphereLight":B={direction:new x,skyColor:new lA,groundColor:new lA};break;case"RectAreaLight":B={color:new lA,position:new x,halfWidth:new x,halfHeight:new x};break}return E[A.id]=B,B}}}function B9(){let E={};return{get:function(A){if(E[A.id]!==void 0)return E[A.id];let B;switch(A.type){case"DirectionalLight":B={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new hA};break;case"SpotLight":B={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new hA};break;case"PointLight":B={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new hA,shadowCameraNear:1,shadowCameraFar:1e3};break}return E[A.id]=B,B}}}var Q9=0;function E9(E,A){return(A.castShadow?2:0)-(E.castShadow?2:0)+(A.map?1:0)-(E.map?1:0)}function g9(E,A){let B=new A9,Q=B9(),g={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let P=0;P<9;P++)g.probe.push(new x);let v=new x,w=new fB,f=new fB;function C(P,D){let t=0,n=0,s=0;for(let q=0;q<9;q++)g.probe[q].set(0,0,0);let i=0,r=0,I=0,H=0,o=0,l=0,F=0,b=0,h=0,Z=0,a=0;P.sort(E9);let u=D===!0?Math.PI:1;for(let q=0,EA=P.length;q<EA;q++){let p=P[q],L=p.color,N=p.intensity,k=p.distance,V=p.shadow&&p.shadow.map?p.shadow.map.texture:null;if(p.isAmbientLight)t+=L.r*N*u,n+=L.g*N*u,s+=L.b*N*u;else if(p.isLightProbe){for(let R=0;R<9;R++)g.probe[R].addScaledVector(p.sh.coefficients[R],N);a++}else if(p.isDirectionalLight){let R=B.get(p);if(R.color.copy(p.color).multiplyScalar(p.intensity*u),p.castShadow){let W=p.shadow,$=Q.get(p);$.shadowBias=W.bias,$.shadowNormalBias=W.normalBias,$.shadowRadius=W.radius,$.shadowMapSize=W.mapSize,g.directionalShadow[i]=$,g.directionalShadowMap[i]=V,g.directionalShadowMatrix[i]=p.shadow.matrix,l++}g.directional[i]=R,i++}else if(p.isSpotLight){let R=B.get(p);R.position.setFromMatrixPosition(p.matrixWorld),R.color.copy(L).multiplyScalar(N*u),R.distance=k,R.coneCos=Math.cos(p.angle),R.penumbraCos=Math.cos(p.angle*(1-p.penumbra)),R.decay=p.decay,g.spot[I]=R;let W=p.shadow;if(p.map&&(g.spotLightMap[h]=p.map,h++,W.updateMatrices(p),p.castShadow&&Z++),g.spotLightMatrix[I]=W.matrix,p.castShadow){let $=Q.get(p);$.shadowBias=W.bias,$.shadowNormalBias=W.normalBias,$.shadowRadius=W.radius,$.shadowMapSize=W.mapSize,g.spotShadow[I]=$,g.spotShadowMap[I]=V,b++}I++}else if(p.isRectAreaLight){let R=B.get(p);R.color.copy(L).multiplyScalar(N),R.halfWidth.set(p.width*.5,0,0),R.halfHeight.set(0,p.height*.5,0),g.rectArea[H]=R,H++}else if(p.isPointLight){let R=B.get(p);if(R.color.copy(p.color).multiplyScalar(p.intensity*u),R.distance=p.distance,R.decay=p.decay,p.castShadow){let W=p.shadow,$=Q.get(p);$.shadowBias=W.bias,$.shadowNormalBias=W.normalBias,$.shadowRadius=W.radius,$.shadowMapSize=W.mapSize,$.shadowCameraNear=W.camera.near,$.shadowCameraFar=W.camera.far,g.pointShadow[r]=$,g.pointShadowMap[r]=V,g.pointShadowMatrix[r]=p.shadow.matrix,F++}g.point[r]=R,r++}else if(p.isHemisphereLight){let R=B.get(p);R.skyColor.copy(p.color).multiplyScalar(N*u),R.groundColor.copy(p.groundColor).multiplyScalar(N*u),g.hemi[o]=R,o++}}H>0&&(A.isWebGL2?E.has("OES_texture_float_linear")===!0?(g.rectAreaLTC1=CA.LTC_FLOAT_1,g.rectAreaLTC2=CA.LTC_FLOAT_2):(g.rectAreaLTC1=CA.LTC_HALF_1,g.rectAreaLTC2=CA.LTC_HALF_2):E.has("OES_texture_float_linear")===!0?(g.rectAreaLTC1=CA.LTC_FLOAT_1,g.rectAreaLTC2=CA.LTC_FLOAT_2):E.has("OES_texture_half_float_linear")===!0?(g.rectAreaLTC1=CA.LTC_HALF_1,g.rectAreaLTC2=CA.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),g.ambient[0]=t,g.ambient[1]=n,g.ambient[2]=s;let y=g.hash;(y.directionalLength!==i||y.pointLength!==r||y.spotLength!==I||y.rectAreaLength!==H||y.hemiLength!==o||y.numDirectionalShadows!==l||y.numPointShadows!==F||y.numSpotShadows!==b||y.numSpotMaps!==h||y.numLightProbes!==a)&&(g.directional.length=i,g.spot.length=I,g.rectArea.length=H,g.point.length=r,g.hemi.length=o,g.directionalShadow.length=l,g.directionalShadowMap.length=l,g.pointShadow.length=F,g.pointShadowMap.length=F,g.spotShadow.length=b,g.spotShadowMap.length=b,g.directionalShadowMatrix.length=l,g.pointShadowMatrix.length=F,g.spotLightMatrix.length=b+h-Z,g.spotLightMap.length=h,g.numSpotLightShadowsWithMaps=Z,g.numLightProbes=a,y.directionalLength=i,y.pointLength=r,y.spotLength=I,y.rectAreaLength=H,y.hemiLength=o,y.numDirectionalShadows=l,y.numPointShadows=F,y.numSpotShadows=b,y.numSpotMaps=h,y.numLightProbes=a,g.version=Q9++)}function e(P,D){let t=0,n=0,s=0,i=0,r=0,I=D.matrixWorldInverse;for(let H=0,o=P.length;H<o;H++){let l=P[H];if(l.isDirectionalLight){let F=g.directional[t];F.direction.setFromMatrixPosition(l.matrixWorld),v.setFromMatrixPosition(l.target.matrixWorld),F.direction.sub(v),F.direction.transformDirection(I),t++}else if(l.isSpotLight){let F=g.spot[s];F.position.setFromMatrixPosition(l.matrixWorld),F.position.applyMatrix4(I),F.direction.setFromMatrixPosition(l.matrixWorld),v.setFromMatrixPosition(l.target.matrixWorld),F.direction.sub(v),F.direction.transformDirection(I),s++}else if(l.isRectAreaLight){let F=g.rectArea[i];F.position.setFromMatrixPosition(l.matrixWorld),F.position.applyMatrix4(I),f.identity(),w.copy(l.matrixWorld),w.premultiply(I),f.extractRotation(w),F.halfWidth.set(l.width*.5,0,0),F.halfHeight.set(0,l.height*.5,0),F.halfWidth.applyMatrix4(f),F.halfHeight.applyMatrix4(f),i++}else if(l.isPointLight){let F=g.point[n];F.position.setFromMatrixPosition(l.matrixWorld),F.position.applyMatrix4(I),n++}else if(l.isHemisphereLight){let F=g.hemi[r];F.direction.setFromMatrixPosition(l.matrixWorld),F.direction.transformDirection(I),r++}}}return{setup:C,setupView:e,state:g}}function m7(E,A){let B=new g9(E,A),Q=[],g=[];function v(){Q.length=0,g.length=0}function w(D){Q.push(D)}function f(D){g.push(D)}function C(D){B.setup(Q,D)}function e(D){B.setupView(Q,D)}return{init:v,state:{lightsArray:Q,shadowsArray:g,lights:B},setupLights:C,setupLightsView:e,pushLight:w,pushShadow:f}}function v9(E,A){let B=new WeakMap;function Q(v,w=0){let f=B.get(v),C;return f===void 0?(C=new m7(E,A),B.set(v,[C])):w>=f.length?(C=new m7(E,A),f.push(C)):C=f[w],C}function g(){B=new WeakMap}return{get:Q,dispose:g}}var gw=class extends jQ{constructor(A){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=_P,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(A)}copy(A){return super.copy(A),this.depthPacking=A.depthPacking,this.map=A.map,this.alphaMap=A.alphaMap,this.displacementMap=A.displacementMap,this.displacementScale=A.displacementScale,this.displacementBias=A.displacementBias,this.wireframe=A.wireframe,this.wireframeLinewidth=A.wireframeLinewidth,this}},vw=class extends jQ{constructor(A){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(A)}copy(A){return super.copy(A),this.map=A.map,this.alphaMap=A.alphaMap,this.displacementMap=A.displacementMap,this.displacementScale=A.displacementScale,this.displacementBias=A.displacementBias,this}},f9=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,w9=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function C9(E,A,B){let Q=new zg,g=new hA,v=new hA,w=new sB,f=new gw({depthPacking:$P}),C=new vw,e={},P=B.maxTextureSize,D={[YQ]:FB,[FB]:YQ,[yB]:yB},t=new HQ({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new hA},radius:{value:4}},vertexShader:f9,fragmentShader:w9}),n=t.clone();n.defines.HORIZONTAL_PASS=1;let s=new YB;s.setAttribute("position",new NB(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let i=new UB(s,t),r=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=X7;let I=this.type;this.render=function(b,h,Z){if(r.enabled===!1||r.autoUpdate===!1&&r.needsUpdate===!1||b.length===0)return;let a=E.getRenderTarget(),u=E.getActiveCubeFace(),y=E.getActiveMipmapLevel(),q=E.state;q.setBlending(LQ),q.buffers.color.setClear(1,1,1,1),q.buffers.depth.setTest(!0),q.setScissorTest(!1);let EA=I!==MQ&&this.type===MQ,p=I===MQ&&this.type!==MQ;for(let L=0,N=b.length;L<N;L++){let k=b[L],V=k.shadow;if(V===void 0){console.warn("THREE.WebGLShadowMap:",k,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;g.copy(V.mapSize);let R=V.getFrameExtents();if(g.multiply(R),v.copy(V.mapSize),(g.x>P||g.y>P)&&(g.x>P&&(v.x=Math.floor(P/R.x),g.x=v.x*R.x,V.mapSize.x=v.x),g.y>P&&(v.y=Math.floor(P/R.y),g.y=v.y*R.y,V.mapSize.y=v.y)),V.map===null||EA===!0||p===!0){let $=this.type!==MQ?{minFilter:hB,magFilter:hB}:{};V.map!==null&&V.map.dispose(),V.map=new zQ(g.x,g.y,$),V.map.texture.name=k.name+".shadowMap",V.camera.updateProjectionMatrix()}E.setRenderTarget(V.map),E.clear();let W=V.getViewportCount();for(let $=0;$<W;$++){let eA=V.getViewport($);w.set(v.x*eA.x,v.y*eA.y,v.x*eA.z,v.y*eA.w),q.viewport(w),V.updateMatrices(k,$),Q=V.getFrustum(),l(h,Z,V.camera,k,this.type)}V.isPointLightShadow!==!0&&this.type===MQ&&H(V,Z),V.needsUpdate=!1}I=this.type,r.needsUpdate=!1,E.setRenderTarget(a,u,y)};function H(b,h){let Z=A.update(i);t.defines.VSM_SAMPLES!==b.blurSamples&&(t.defines.VSM_SAMPLES=b.blurSamples,n.defines.VSM_SAMPLES=b.blurSamples,t.needsUpdate=!0,n.needsUpdate=!0),b.mapPass===null&&(b.mapPass=new zQ(g.x,g.y)),t.uniforms.shadow_pass.value=b.map.texture,t.uniforms.resolution.value=b.mapSize,t.uniforms.radius.value=b.radius,E.setRenderTarget(b.mapPass),E.clear(),E.renderBufferDirect(h,null,Z,t,i,null),n.uniforms.shadow_pass.value=b.mapPass.texture,n.uniforms.resolution.value=b.mapSize,n.uniforms.radius.value=b.radius,E.setRenderTarget(b.map),E.clear(),E.renderBufferDirect(h,null,Z,n,i,null)}function o(b,h,Z,a){let u=null,y=Z.isPointLight===!0?b.customDistanceMaterial:b.customDepthMaterial;if(y!==void 0)u=y;else if(u=Z.isPointLight===!0?C:f,E.localClippingEnabled&&h.clipShadows===!0&&Array.isArray(h.clippingPlanes)&&h.clippingPlanes.length!==0||h.displacementMap&&h.displacementScale!==0||h.alphaMap&&h.alphaTest>0||h.map&&h.alphaTest>0){let q=u.uuid,EA=h.uuid,p=e[q];p===void 0&&(p={},e[q]=p);let L=p[EA];L===void 0&&(L=u.clone(),p[EA]=L,h.addEventListener("dispose",F)),u=L}if(u.visible=h.visible,u.wireframe=h.wireframe,a===MQ?u.side=h.shadowSide!==null?h.shadowSide:h.side:u.side=h.shadowSide!==null?h.shadowSide:D[h.side],u.alphaMap=h.alphaMap,u.alphaTest=h.alphaTest,u.map=h.map,u.clipShadows=h.clipShadows,u.clippingPlanes=h.clippingPlanes,u.clipIntersection=h.clipIntersection,u.displacementMap=h.displacementMap,u.displacementScale=h.displacementScale,u.displacementBias=h.displacementBias,u.wireframeLinewidth=h.wireframeLinewidth,u.linewidth=h.linewidth,Z.isPointLight===!0&&u.isMeshDistanceMaterial===!0){let q=E.properties.get(u);q.light=Z}return u}function l(b,h,Z,a,u){if(b.visible===!1)return;if(b.layers.test(h.layers)&&(b.isMesh||b.isLine||b.isPoints)&&(b.castShadow||b.receiveShadow&&u===MQ)&&(!b.frustumCulled||Q.intersectsObject(b))){b.modelViewMatrix.multiplyMatrices(Z.matrixWorldInverse,b.matrixWorld);let EA=A.update(b),p=b.material;if(Array.isArray(p)){let L=EA.groups;for(let N=0,k=L.length;N<k;N++){let V=L[N],R=p[V.materialIndex];if(R&&R.visible){let W=o(b,R,a,u);b.onBeforeShadow(E,b,h,Z,EA,W,V),E.renderBufferDirect(Z,null,EA,W,b,V),b.onAfterShadow(E,b,h,Z,EA,W,V)}}}else if(p.visible){let L=o(b,p,a,u);b.onBeforeShadow(E,b,h,Z,EA,L,null),E.renderBufferDirect(Z,null,EA,L,b,null),b.onAfterShadow(E,b,h,Z,EA,L,null)}}let q=b.children;for(let EA=0,p=q.length;EA<p;EA++)l(q[EA],h,Z,a,u)}function F(b){b.target.removeEventListener("dispose",F);for(let Z in e){let a=e[Z],u=b.target.uuid;u in a&&(a[u].dispose(),delete a[u])}}}function e9(E,A,B){let Q=B.isWebGL2;function g(){let m=!1,gA=new sB,vA=null,zA=new sB(0,0,0,0);return{setMask:function(oA){vA!==oA&&!m&&(E.colorMask(oA,oA,oA,oA),vA=oA)},setLocked:function(oA){m=oA},setClear:function(oA,JA,WA,IB,HB){HB===!0&&(oA*=IB,JA*=IB,WA*=IB),gA.set(oA,JA,WA,IB),zA.equals(gA)===!1&&(E.clearColor(oA,JA,WA,IB),zA.copy(gA))},reset:function(){m=!1,vA=null,zA.set(-1,0,0,0)}}}function v(){let m=!1,gA=null,vA=null,zA=null;return{setTest:function(oA){oA?FA(E.DEPTH_TEST):HA(E.DEPTH_TEST)},setMask:function(oA){gA!==oA&&!m&&(E.depthMask(oA),gA=oA)},setFunc:function(oA){if(vA!==oA){switch(oA){case mP:E.depthFunc(E.NEVER);break;case pP:E.depthFunc(E.ALWAYS);break;case FP:E.depthFunc(E.LESS);break;case ev:E.depthFunc(E.LEQUAL);break;case xP:E.depthFunc(E.EQUAL);break;case GP:E.depthFunc(E.GEQUAL);break;case LP:E.depthFunc(E.GREATER);break;case UP:E.depthFunc(E.NOTEQUAL);break;default:E.depthFunc(E.LEQUAL)}vA=oA}},setLocked:function(oA){m=oA},setClear:function(oA){zA!==oA&&(E.clearDepth(oA),zA=oA)},reset:function(){m=!1,gA=null,vA=null,zA=null}}}function w(){let m=!1,gA=null,vA=null,zA=null,oA=null,JA=null,WA=null,IB=null,HB=null;return{setTest:function($A){m||($A?FA(E.STENCIL_TEST):HA(E.STENCIL_TEST))},setMask:function($A){gA!==$A&&!m&&(E.stencilMask($A),gA=$A)},setFunc:function($A,uB,gQ){(vA!==$A||zA!==uB||oA!==gQ)&&(E.stencilFunc($A,uB,gQ),vA=$A,zA=uB,oA=gQ)},setOp:function($A,uB,gQ){(JA!==$A||WA!==uB||IB!==gQ)&&(E.stencilOp($A,uB,gQ),JA=$A,WA=uB,IB=gQ)},setLocked:function($A){m=$A},setClear:function($A){HB!==$A&&(E.clearStencil($A),HB=$A)},reset:function(){m=!1,gA=null,vA=null,zA=null,oA=null,JA=null,WA=null,IB=null,HB=null}}}let f=new g,C=new v,e=new w,P=new WeakMap,D=new WeakMap,t={},n={},s=new WeakMap,i=[],r=null,I=!1,H=null,o=null,l=null,F=null,b=null,h=null,Z=null,a=new lA(0,0,0),u=0,y=!1,q=null,EA=null,p=null,L=null,N=null,k=E.getParameter(E.MAX_COMBINED_TEXTURE_IMAGE_UNITS),V=!1,R=0,W=E.getParameter(E.VERSION);W.indexOf("WebGL")!==-1?(R=parseFloat(/^WebGL (\d)/.exec(W)[1]),V=R>=1):W.indexOf("OpenGL ES")!==-1&&(R=parseFloat(/^OpenGL ES (\d)/.exec(W)[1]),V=R>=2);let $=null,eA={},O=E.getParameter(E.SCISSOR_BOX),S=E.getParameter(E.VIEWPORT),tA=new sB().fromArray(O),MA=new sB().fromArray(S);function sA(m,gA,vA,zA){let oA=new Uint8Array(4),JA=E.createTexture();E.bindTexture(m,JA),E.texParameteri(m,E.TEXTURE_MIN_FILTER,E.NEAREST),E.texParameteri(m,E.TEXTURE_MAG_FILTER,E.NEAREST);for(let WA=0;WA<vA;WA++)Q&&(m===E.TEXTURE_3D||m===E.TEXTURE_2D_ARRAY)?E.texImage3D(gA,0,E.RGBA,1,1,zA,0,E.RGBA,E.UNSIGNED_BYTE,oA):E.texImage2D(gA+WA,0,E.RGBA,1,1,0,E.RGBA,E.UNSIGNED_BYTE,oA);return JA}let pA={};pA[E.TEXTURE_2D]=sA(E.TEXTURE_2D,E.TEXTURE_2D,1),pA[E.TEXTURE_CUBE_MAP]=sA(E.TEXTURE_CUBE_MAP,E.TEXTURE_CUBE_MAP_POSITIVE_X,6),Q&&(pA[E.TEXTURE_2D_ARRAY]=sA(E.TEXTURE_2D_ARRAY,E.TEXTURE_2D_ARRAY,1,1),pA[E.TEXTURE_3D]=sA(E.TEXTURE_3D,E.TEXTURE_3D,1,1)),f.setClear(0,0,0,1),C.setClear(1),e.setClear(0),FA(E.DEPTH_TEST),C.setFunc(ev),xA(!1),z(CC),FA(E.CULL_FACE),nA(LQ);function FA(m){t[m]!==!0&&(E.enable(m),t[m]=!0)}function HA(m){t[m]!==!1&&(E.disable(m),t[m]=!1)}function ZA(m,gA){return n[m]!==gA?(E.bindFramebuffer(m,gA),n[m]=gA,Q&&(m===E.DRAW_FRAMEBUFFER&&(n[E.FRAMEBUFFER]=gA),m===E.FRAMEBUFFER&&(n[E.DRAW_FRAMEBUFFER]=gA)),!0):!1}function U(m,gA){let vA=i,zA=!1;if(m)if(vA=s.get(gA),vA===void 0&&(vA=[],s.set(gA,vA)),m.isWebGLMultipleRenderTargets){let oA=m.texture;if(vA.length!==oA.length||vA[0]!==E.COLOR_ATTACHMENT0){for(let JA=0,WA=oA.length;JA<WA;JA++)vA[JA]=E.COLOR_ATTACHMENT0+JA;vA.length=oA.length,zA=!0}}else vA[0]!==E.COLOR_ATTACHMENT0&&(vA[0]=E.COLOR_ATTACHMENT0,zA=!0);else vA[0]!==E.BACK&&(vA[0]=E.BACK,zA=!0);zA&&(B.isWebGL2?E.drawBuffers(vA):A.get("WEBGL_draw_buffers").drawBuffersWEBGL(vA))}function DB(m){return r!==m?(E.useProgram(m),r=m,!0):!1}let aA={[_Q]:E.FUNC_ADD,[nP]:E.FUNC_SUBTRACT,[rP]:E.FUNC_REVERSE_SUBTRACT};if(Q)aA[DC]=E.MIN,aA[IC]=E.MAX;else{let m=A.get("EXT_blend_minmax");m!==null&&(aA[DC]=m.MIN_EXT,aA[IC]=m.MAX_EXT)}let bA={[sP]:E.ZERO,[iP]:E.ONE,[MP]:E.SRC_COLOR,[yf]:E.SRC_ALPHA,[uP]:E.SRC_ALPHA_SATURATE,[zP]:E.DST_COLOR,[cP]:E.DST_ALPHA,[oP]:E.ONE_MINUS_SRC_COLOR,[Of]:E.ONE_MINUS_SRC_ALPHA,[HP]:E.ONE_MINUS_DST_COLOR,[aP]:E.ONE_MINUS_DST_ALPHA,[dP]:E.CONSTANT_COLOR,[lP]:E.ONE_MINUS_CONSTANT_COLOR,[hP]:E.CONSTANT_ALPHA,[bP]:E.ONE_MINUS_CONSTANT_ALPHA};function nA(m,gA,vA,zA,oA,JA,WA,IB,HB,$A){if(m===LQ){I===!0&&(HA(E.BLEND),I=!1);return}if(I===!1&&(FA(E.BLEND),I=!0),m!==IP){if(m!==H||$A!==y){if((o!==_Q||b!==_Q)&&(E.blendEquation(E.FUNC_ADD),o=_Q,b=_Q),$A)switch(m){case OE:E.blendFuncSeparate(E.ONE,E.ONE_MINUS_SRC_ALPHA,E.ONE,E.ONE_MINUS_SRC_ALPHA);break;case eC:E.blendFunc(E.ONE,E.ONE);break;case PC:E.blendFuncSeparate(E.ZERO,E.ONE_MINUS_SRC_COLOR,E.ZERO,E.ONE);break;case tC:E.blendFuncSeparate(E.ZERO,E.SRC_COLOR,E.ZERO,E.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",m);break}else switch(m){case OE:E.blendFuncSeparate(E.SRC_ALPHA,E.ONE_MINUS_SRC_ALPHA,E.ONE,E.ONE_MINUS_SRC_ALPHA);break;case eC:E.blendFunc(E.SRC_ALPHA,E.ONE);break;case PC:E.blendFuncSeparate(E.ZERO,E.ONE_MINUS_SRC_COLOR,E.ZERO,E.ONE);break;case tC:E.blendFunc(E.ZERO,E.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",m);break}l=null,F=null,h=null,Z=null,a.set(0,0,0),u=0,H=m,y=$A}return}oA=oA||gA,JA=JA||vA,WA=WA||zA,(gA!==o||oA!==b)&&(E.blendEquationSeparate(aA[gA],aA[oA]),o=gA,b=oA),(vA!==l||zA!==F||JA!==h||WA!==Z)&&(E.blendFuncSeparate(bA[vA],bA[zA],bA[JA],bA[WA]),l=vA,F=zA,h=JA,Z=WA),(IB.equals(a)===!1||HB!==u)&&(E.blendColor(IB.r,IB.g,IB.b,HB),a.copy(IB),u=HB),H=m,y=!1}function BB(m,gA){m.side===yB?HA(E.CULL_FACE):FA(E.CULL_FACE);let vA=m.side===FB;gA&&(vA=!vA),xA(vA),m.blending===OE&&m.transparent===!1?nA(LQ):nA(m.blending,m.blendEquation,m.blendSrc,m.blendDst,m.blendEquationAlpha,m.blendSrcAlpha,m.blendDstAlpha,m.blendColor,m.blendAlpha,m.premultipliedAlpha),C.setFunc(m.depthFunc),C.setTest(m.depthTest),C.setMask(m.depthWrite),f.setMask(m.colorWrite);let zA=m.stencilWrite;e.setTest(zA),zA&&(e.setMask(m.stencilWriteMask),e.setFunc(m.stencilFunc,m.stencilRef,m.stencilFuncMask),e.setOp(m.stencilFail,m.stencilZFail,m.stencilZPass)),X(m.polygonOffset,m.polygonOffsetFactor,m.polygonOffsetUnits),m.alphaToCoverage===!0?FA(E.SAMPLE_ALPHA_TO_COVERAGE):HA(E.SAMPLE_ALPHA_TO_COVERAGE)}function xA(m){q!==m&&(m?E.frontFace(E.CW):E.frontFace(E.CCW),q=m)}function z(m){m!==PP?(FA(E.CULL_FACE),m!==EA&&(m===CC?E.cullFace(E.BACK):m===tP?E.cullFace(E.FRONT):E.cullFace(E.FRONT_AND_BACK))):HA(E.CULL_FACE),EA=m}function M(m){m!==p&&(V&&E.lineWidth(m),p=m)}function X(m,gA,vA){m?(FA(E.POLYGON_OFFSET_FILL),(L!==gA||N!==vA)&&(E.polygonOffset(gA,vA),L=gA,N=vA)):HA(E.POLYGON_OFFSET_FILL)}function BA(m){m?FA(E.SCISSOR_TEST):HA(E.SCISSOR_TEST)}function _(m){m===void 0&&(m=E.TEXTURE0+k-1),$!==m&&(E.activeTexture(m),$=m)}function AA(m,gA,vA){vA===void 0&&($===null?vA=E.TEXTURE0+k-1:vA=$);let zA=eA[vA];zA===void 0&&(zA={type:void 0,texture:void 0},eA[vA]=zA),(zA.type!==m||zA.texture!==gA)&&($!==vA&&(E.activeTexture(vA),$=vA),E.bindTexture(m,gA||pA[m]),zA.type=m,zA.texture=gA)}function rA(){let m=eA[$];m!==void 0&&m.type!==void 0&&(E.bindTexture(m.type,null),m.type=void 0,m.texture=void 0)}function PA(){try{E.compressedTexImage2D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function IA(){try{E.compressedTexImage3D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function uA(){try{E.texSubImage2D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function LA(){try{E.texSubImage3D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function K(){try{E.compressedTexSubImage2D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function VA(){try{E.compressedTexSubImage3D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function d(){try{E.texStorage2D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function J(){try{E.texStorage3D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function wA(){try{E.texImage2D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function QA(){try{E.texImage3D.apply(E,arguments)}catch(m){console.error("THREE.WebGLState:",m)}}function iA(m){tA.equals(m)===!1&&(E.scissor(m.x,m.y,m.z,m.w),tA.copy(m))}function yA(m){MA.equals(m)===!1&&(E.viewport(m.x,m.y,m.z,m.w),MA.copy(m))}function kA(m,gA){let vA=D.get(gA);vA===void 0&&(vA=new WeakMap,D.set(gA,vA));let zA=vA.get(m);zA===void 0&&(zA=E.getUniformBlockIndex(gA,m.name),vA.set(m,zA))}function YA(m,gA){let zA=D.get(gA).get(m);P.get(gA)!==zA&&(E.uniformBlockBinding(gA,zA,m.__bindingPointIndex),P.set(gA,zA))}function fA(){E.disable(E.BLEND),E.disable(E.CULL_FACE),E.disable(E.DEPTH_TEST),E.disable(E.POLYGON_OFFSET_FILL),E.disable(E.SCISSOR_TEST),E.disable(E.STENCIL_TEST),E.disable(E.SAMPLE_ALPHA_TO_COVERAGE),E.blendEquation(E.FUNC_ADD),E.blendFunc(E.ONE,E.ZERO),E.blendFuncSeparate(E.ONE,E.ZERO,E.ONE,E.ZERO),E.blendColor(0,0,0,0),E.colorMask(!0,!0,!0,!0),E.clearColor(0,0,0,0),E.depthMask(!0),E.depthFunc(E.LESS),E.clearDepth(1),E.stencilMask(4294967295),E.stencilFunc(E.ALWAYS,0,4294967295),E.stencilOp(E.KEEP,E.KEEP,E.KEEP),E.clearStencil(0),E.cullFace(E.BACK),E.frontFace(E.CCW),E.polygonOffset(0,0),E.activeTexture(E.TEXTURE0),E.bindFramebuffer(E.FRAMEBUFFER,null),Q===!0&&(E.bindFramebuffer(E.DRAW_FRAMEBUFFER,null),E.bindFramebuffer(E.READ_FRAMEBUFFER,null)),E.useProgram(null),E.lineWidth(1),E.scissor(0,0,E.canvas.width,E.canvas.height),E.viewport(0,0,E.canvas.width,E.canvas.height),t={},$=null,eA={},n={},s=new WeakMap,i=[],r=null,I=!1,H=null,o=null,l=null,F=null,b=null,h=null,Z=null,a=new lA(0,0,0),u=0,y=!1,q=null,EA=null,p=null,L=null,N=null,tA.set(0,0,E.canvas.width,E.canvas.height),MA.set(0,0,E.canvas.width,E.canvas.height),f.reset(),C.reset(),e.reset()}return{buffers:{color:f,depth:C,stencil:e},enable:FA,disable:HA,bindFramebuffer:ZA,drawBuffers:U,useProgram:DB,setBlending:nA,setMaterial:BB,setFlipSided:xA,setCullFace:z,setLineWidth:M,setPolygonOffset:X,setScissorTest:BA,activeTexture:_,bindTexture:AA,unbindTexture:rA,compressedTexImage2D:PA,compressedTexImage3D:IA,texImage2D:wA,texImage3D:QA,updateUBOMapping:kA,uniformBlockBinding:YA,texStorage2D:d,texStorage3D:J,texSubImage2D:uA,texSubImage3D:LA,compressedTexSubImage2D:K,compressedTexSubImage3D:VA,scissor:iA,viewport:yA,reset:fA}}function P9(E,A,B,Q,g,v,w){let f=g.isWebGL2,C=A.has("WEBGL_multisampled_render_to_texture")?A.get("WEBGL_multisampled_render_to_texture"):null,e=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),P=new WeakMap,D,t=new WeakMap,n=!1;try{n=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function s(z,M){return n?new OffscreenCanvas(z,M):iv("canvas")}function i(z,M,X,BA){let _=1;if((z.width>BA||z.height>BA)&&(_=BA/Math.max(z.width,z.height)),_<1||M===!0)if(typeof HTMLImageElement<"u"&&z instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&z instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&z instanceof ImageBitmap){let AA=M?sv:Math.floor,rA=AA(_*z.width),PA=AA(_*z.height);D===void 0&&(D=s(rA,PA));let IA=X?s(rA,PA):D;return IA.width=rA,IA.height=PA,IA.getContext("2d").drawImage(z,0,0,rA,PA),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+z.width+"x"+z.height+") to ("+rA+"x"+PA+")."),IA}else return"data"in z&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+z.width+"x"+z.height+")."),z;return z}function r(z){return qf(z.width)&&qf(z.height)}function I(z){return f?!1:z.wrapS!==zB||z.wrapT!==zB||z.minFilter!==hB&&z.minFilter!==bB}function H(z,M){return z.generateMipmaps&&M&&z.minFilter!==hB&&z.minFilter!==bB}function o(z){E.generateMipmap(z)}function l(z,M,X,BA,_=!1){if(f===!1)return M;if(z!==null){if(E[z]!==void 0)return E[z];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+z+"'")}let AA=M;if(M===E.RED&&(X===E.FLOAT&&(AA=E.R32F),X===E.HALF_FLOAT&&(AA=E.R16F),X===E.UNSIGNED_BYTE&&(AA=E.R8)),M===E.RED_INTEGER&&(X===E.UNSIGNED_BYTE&&(AA=E.R8UI),X===E.UNSIGNED_SHORT&&(AA=E.R16UI),X===E.UNSIGNED_INT&&(AA=E.R32UI),X===E.BYTE&&(AA=E.R8I),X===E.SHORT&&(AA=E.R16I),X===E.INT&&(AA=E.R32I)),M===E.RG&&(X===E.FLOAT&&(AA=E.RG32F),X===E.HALF_FLOAT&&(AA=E.RG16F),X===E.UNSIGNED_BYTE&&(AA=E.RG8)),M===E.RGBA){let rA=_?Dv:KA.getTransfer(BA);X===E.FLOAT&&(AA=E.RGBA32F),X===E.HALF_FLOAT&&(AA=E.RGBA16F),X===E.UNSIGNED_BYTE&&(AA=rA===QB?E.SRGB8_ALPHA8:E.RGBA8),X===E.UNSIGNED_SHORT_4_4_4_4&&(AA=E.RGBA4),X===E.UNSIGNED_SHORT_5_5_5_1&&(AA=E.RGB5_A1)}return(AA===E.R16F||AA===E.R32F||AA===E.RG16F||AA===E.RG32F||AA===E.RGBA16F||AA===E.RGBA32F)&&A.get("EXT_color_buffer_float"),AA}function F(z,M,X){return H(z,X)===!0||z.isFramebufferTexture&&z.minFilter!==hB&&z.minFilter!==bB?Math.log2(Math.max(M.width,M.height))+1:z.mipmaps!==void 0&&z.mipmaps.length>0?z.mipmaps.length:z.isCompressedTexture&&Array.isArray(z.image)?M.mipmaps.length:1}function b(z){return z===hB||z===nC||z===Cf?E.NEAREST:E.LINEAR}function h(z){let M=z.target;M.removeEventListener("dispose",h),a(M),M.isVideoTexture&&P.delete(M)}function Z(z){let M=z.target;M.removeEventListener("dispose",Z),y(M)}function a(z){let M=Q.get(z);if(M.__webglInit===void 0)return;let X=z.source,BA=t.get(X);if(BA){let _=BA[M.__cacheKey];_.usedTimes--,_.usedTimes===0&&u(z),Object.keys(BA).length===0&&t.delete(X)}Q.remove(z)}function u(z){let M=Q.get(z);E.deleteTexture(M.__webglTexture);let X=z.source,BA=t.get(X);delete BA[M.__cacheKey],w.memory.textures--}function y(z){let M=z.texture,X=Q.get(z),BA=Q.get(M);if(BA.__webglTexture!==void 0&&(E.deleteTexture(BA.__webglTexture),w.memory.textures--),z.depthTexture&&z.depthTexture.dispose(),z.isWebGLCubeRenderTarget)for(let _=0;_<6;_++){if(Array.isArray(X.__webglFramebuffer[_]))for(let AA=0;AA<X.__webglFramebuffer[_].length;AA++)E.deleteFramebuffer(X.__webglFramebuffer[_][AA]);else E.deleteFramebuffer(X.__webglFramebuffer[_]);X.__webglDepthbuffer&&E.deleteRenderbuffer(X.__webglDepthbuffer[_])}else{if(Array.isArray(X.__webglFramebuffer))for(let _=0;_<X.__webglFramebuffer.length;_++)E.deleteFramebuffer(X.__webglFramebuffer[_]);else E.deleteFramebuffer(X.__webglFramebuffer);if(X.__webglDepthbuffer&&E.deleteRenderbuffer(X.__webglDepthbuffer),X.__webglMultisampledFramebuffer&&E.deleteFramebuffer(X.__webglMultisampledFramebuffer),X.__webglColorRenderbuffer)for(let _=0;_<X.__webglColorRenderbuffer.length;_++)X.__webglColorRenderbuffer[_]&&E.deleteRenderbuffer(X.__webglColorRenderbuffer[_]);X.__webglDepthRenderbuffer&&E.deleteRenderbuffer(X.__webglDepthRenderbuffer)}if(z.isWebGLMultipleRenderTargets)for(let _=0,AA=M.length;_<AA;_++){let rA=Q.get(M[_]);rA.__webglTexture&&(E.deleteTexture(rA.__webglTexture),w.memory.textures--),Q.remove(M[_])}Q.remove(M),Q.remove(z)}let q=0;function EA(){q=0}function p(){let z=q;return z>=g.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+z+" texture units while this GPU supports only "+g.maxTextures),q+=1,z}function L(z){let M=[];return M.push(z.wrapS),M.push(z.wrapT),M.push(z.wrapR||0),M.push(z.magFilter),M.push(z.minFilter),M.push(z.anisotropy),M.push(z.internalFormat),M.push(z.format),M.push(z.type),M.push(z.generateMipmaps),M.push(z.premultiplyAlpha),M.push(z.flipY),M.push(z.unpackAlignment),M.push(z.colorSpace),M.join()}function N(z,M){let X=Q.get(z);if(z.isVideoTexture&&BB(z),z.isRenderTargetTexture===!1&&z.version>0&&X.__version!==z.version){let BA=z.image;if(BA===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(BA.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{tA(X,z,M);return}}B.bindTexture(E.TEXTURE_2D,X.__webglTexture,E.TEXTURE0+M)}function k(z,M){let X=Q.get(z);if(z.version>0&&X.__version!==z.version){tA(X,z,M);return}B.bindTexture(E.TEXTURE_2D_ARRAY,X.__webglTexture,E.TEXTURE0+M)}function V(z,M){let X=Q.get(z);if(z.version>0&&X.__version!==z.version){tA(X,z,M);return}B.bindTexture(E.TEXTURE_3D,X.__webglTexture,E.TEXTURE0+M)}function R(z,M){let X=Q.get(z);if(z.version>0&&X.__version!==z.version){MA(X,z,M);return}B.bindTexture(E.TEXTURE_CUBE_MAP,X.__webglTexture,E.TEXTURE0+M)}let W={[Zf]:E.REPEAT,[zB]:E.CLAMP_TO_EDGE,[Vf]:E.MIRRORED_REPEAT},$={[hB]:E.NEAREST,[nC]:E.NEAREST_MIPMAP_NEAREST,[Cf]:E.NEAREST_MIPMAP_LINEAR,[bB]:E.LINEAR,[RP]:E.LINEAR_MIPMAP_NEAREST,[TQ]:E.LINEAR_MIPMAP_LINEAR},eA={[Bt]:E.NEVER,[wt]:E.ALWAYS,[Qt]:E.LESS,[J7]:E.LEQUAL,[Et]:E.EQUAL,[ft]:E.GEQUAL,[gt]:E.GREATER,[vt]:E.NOTEQUAL};function O(z,M,X){if(X?(E.texParameteri(z,E.TEXTURE_WRAP_S,W[M.wrapS]),E.texParameteri(z,E.TEXTURE_WRAP_T,W[M.wrapT]),(z===E.TEXTURE_3D||z===E.TEXTURE_2D_ARRAY)&&E.texParameteri(z,E.TEXTURE_WRAP_R,W[M.wrapR]),E.texParameteri(z,E.TEXTURE_MAG_FILTER,$[M.magFilter]),E.texParameteri(z,E.TEXTURE_MIN_FILTER,$[M.minFilter])):(E.texParameteri(z,E.TEXTURE_WRAP_S,E.CLAMP_TO_EDGE),E.texParameteri(z,E.TEXTURE_WRAP_T,E.CLAMP_TO_EDGE),(z===E.TEXTURE_3D||z===E.TEXTURE_2D_ARRAY)&&E.texParameteri(z,E.TEXTURE_WRAP_R,E.CLAMP_TO_EDGE),(M.wrapS!==zB||M.wrapT!==zB)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),E.texParameteri(z,E.TEXTURE_MAG_FILTER,b(M.magFilter)),E.texParameteri(z,E.TEXTURE_MIN_FILTER,b(M.minFilter)),M.minFilter!==hB&&M.minFilter!==bB&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),M.compareFunction&&(E.texParameteri(z,E.TEXTURE_COMPARE_MODE,E.COMPARE_REF_TO_TEXTURE),E.texParameteri(z,E.TEXTURE_COMPARE_FUNC,eA[M.compareFunction])),A.has("EXT_texture_filter_anisotropic")===!0){let BA=A.get("EXT_texture_filter_anisotropic");if(M.magFilter===hB||M.minFilter!==Cf&&M.minFilter!==TQ||M.type===GQ&&A.has("OES_texture_float_linear")===!1||f===!1&&M.type===Mg&&A.has("OES_texture_half_float_linear")===!1)return;(M.anisotropy>1||Q.get(M).__currentAnisotropy)&&(E.texParameterf(z,BA.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(M.anisotropy,g.getMaxAnisotropy())),Q.get(M).__currentAnisotropy=M.anisotropy)}}function S(z,M){let X=!1;z.__webglInit===void 0&&(z.__webglInit=!0,M.addEventListener("dispose",h));let BA=M.source,_=t.get(BA);_===void 0&&(_={},t.set(BA,_));let AA=L(M);if(AA!==z.__cacheKey){_[AA]===void 0&&(_[AA]={texture:E.createTexture(),usedTimes:0},w.memory.textures++,X=!0),_[AA].usedTimes++;let rA=_[z.__cacheKey];rA!==void 0&&(_[z.__cacheKey].usedTimes--,rA.usedTimes===0&&u(M)),z.__cacheKey=AA,z.__webglTexture=_[AA].texture}return X}function tA(z,M,X){let BA=E.TEXTURE_2D;(M.isDataArrayTexture||M.isCompressedArrayTexture)&&(BA=E.TEXTURE_2D_ARRAY),M.isData3DTexture&&(BA=E.TEXTURE_3D);let _=S(z,M),AA=M.source;B.bindTexture(BA,z.__webglTexture,E.TEXTURE0+X);let rA=Q.get(AA);if(AA.version!==rA.__version||_===!0){B.activeTexture(E.TEXTURE0+X);let PA=KA.getPrimaries(KA.workingColorSpace),IA=M.colorSpace===OB?null:KA.getPrimaries(M.colorSpace),uA=M.colorSpace===OB||PA===IA?E.NONE:E.BROWSER_DEFAULT_WEBGL;E.pixelStorei(E.UNPACK_FLIP_Y_WEBGL,M.flipY),E.pixelStorei(E.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),E.pixelStorei(E.UNPACK_ALIGNMENT,M.unpackAlignment),E.pixelStorei(E.UNPACK_COLORSPACE_CONVERSION_WEBGL,uA);let LA=I(M)&&r(M.image)===!1,K=i(M.image,LA,!1,g.maxTextureSize);K=xA(M,K);let VA=r(K)||f,d=v.convert(M.format,M.colorSpace),J=v.convert(M.type),wA=l(M.internalFormat,d,J,M.colorSpace,M.isVideoTexture);O(BA,M,VA);let QA,iA=M.mipmaps,yA=f&&M.isVideoTexture!==!0&&wA!==V7,kA=rA.__version===void 0||_===!0,YA=F(M,K,VA);if(M.isDepthTexture)wA=E.DEPTH_COMPONENT,f?M.type===GQ?wA=E.DEPTH_COMPONENT32F:M.type===xQ?wA=E.DEPTH_COMPONENT24:M.type===AE?wA=E.DEPTH24_STENCIL8:wA=E.DEPTH_COMPONENT16:M.type===GQ&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),M.format===BE&&wA===E.DEPTH_COMPONENT&&M.type!==Hw&&M.type!==xQ&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),M.type=xQ,J=v.convert(M.type)),M.format===kE&&wA===E.DEPTH_COMPONENT&&(wA=E.DEPTH_STENCIL,M.type!==AE&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),M.type=AE,J=v.convert(M.type))),kA&&(yA?B.texStorage2D(E.TEXTURE_2D,1,wA,K.width,K.height):B.texImage2D(E.TEXTURE_2D,0,wA,K.width,K.height,0,d,J,null));else if(M.isDataTexture)if(iA.length>0&&VA){yA&&kA&&B.texStorage2D(E.TEXTURE_2D,YA,wA,iA[0].width,iA[0].height);for(let fA=0,m=iA.length;fA<m;fA++)QA=iA[fA],yA?B.texSubImage2D(E.TEXTURE_2D,fA,0,0,QA.width,QA.height,d,J,QA.data):B.texImage2D(E.TEXTURE_2D,fA,wA,QA.width,QA.height,0,d,J,QA.data);M.generateMipmaps=!1}else yA?(kA&&B.texStorage2D(E.TEXTURE_2D,YA,wA,K.width,K.height),B.texSubImage2D(E.TEXTURE_2D,0,0,0,K.width,K.height,d,J,K.data)):B.texImage2D(E.TEXTURE_2D,0,wA,K.width,K.height,0,d,J,K.data);else if(M.isCompressedTexture)if(M.isCompressedArrayTexture){yA&&kA&&B.texStorage3D(E.TEXTURE_2D_ARRAY,YA,wA,iA[0].width,iA[0].height,K.depth);for(let fA=0,m=iA.length;fA<m;fA++)QA=iA[fA],M.format!==KB?d!==null?yA?B.compressedTexSubImage3D(E.TEXTURE_2D_ARRAY,fA,0,0,0,QA.width,QA.height,K.depth,d,QA.data,0,0):B.compressedTexImage3D(E.TEXTURE_2D_ARRAY,fA,wA,QA.width,QA.height,K.depth,0,QA.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):yA?B.texSubImage3D(E.TEXTURE_2D_ARRAY,fA,0,0,0,QA.width,QA.height,K.depth,d,J,QA.data):B.texImage3D(E.TEXTURE_2D_ARRAY,fA,wA,QA.width,QA.height,K.depth,0,d,J,QA.data)}else{yA&&kA&&B.texStorage2D(E.TEXTURE_2D,YA,wA,iA[0].width,iA[0].height);for(let fA=0,m=iA.length;fA<m;fA++)QA=iA[fA],M.format!==KB?d!==null?yA?B.compressedTexSubImage2D(E.TEXTURE_2D,fA,0,0,QA.width,QA.height,d,QA.data):B.compressedTexImage2D(E.TEXTURE_2D,fA,wA,QA.width,QA.height,0,QA.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):yA?B.texSubImage2D(E.TEXTURE_2D,fA,0,0,QA.width,QA.height,d,J,QA.data):B.texImage2D(E.TEXTURE_2D,fA,wA,QA.width,QA.height,0,d,J,QA.data)}else if(M.isDataArrayTexture)yA?(kA&&B.texStorage3D(E.TEXTURE_2D_ARRAY,YA,wA,K.width,K.height,K.depth),B.texSubImage3D(E.TEXTURE_2D_ARRAY,0,0,0,0,K.width,K.height,K.depth,d,J,K.data)):B.texImage3D(E.TEXTURE_2D_ARRAY,0,wA,K.width,K.height,K.depth,0,d,J,K.data);else if(M.isData3DTexture)yA?(kA&&B.texStorage3D(E.TEXTURE_3D,YA,wA,K.width,K.height,K.depth),B.texSubImage3D(E.TEXTURE_3D,0,0,0,0,K.width,K.height,K.depth,d,J,K.data)):B.texImage3D(E.TEXTURE_3D,0,wA,K.width,K.height,K.depth,0,d,J,K.data);else if(M.isFramebufferTexture){if(kA)if(yA)B.texStorage2D(E.TEXTURE_2D,YA,wA,K.width,K.height);else{let fA=K.width,m=K.height;for(let gA=0;gA<YA;gA++)B.texImage2D(E.TEXTURE_2D,gA,wA,fA,m,0,d,J,null),fA>>=1,m>>=1}}else if(iA.length>0&&VA){yA&&kA&&B.texStorage2D(E.TEXTURE_2D,YA,wA,iA[0].width,iA[0].height);for(let fA=0,m=iA.length;fA<m;fA++)QA=iA[fA],yA?B.texSubImage2D(E.TEXTURE_2D,fA,0,0,d,J,QA):B.texImage2D(E.TEXTURE_2D,fA,wA,d,J,QA);M.generateMipmaps=!1}else yA?(kA&&B.texStorage2D(E.TEXTURE_2D,YA,wA,K.width,K.height),B.texSubImage2D(E.TEXTURE_2D,0,0,0,d,J,K)):B.texImage2D(E.TEXTURE_2D,0,wA,d,J,K);H(M,VA)&&o(BA),rA.__version=AA.version,M.onUpdate&&M.onUpdate(M)}z.__version=M.version}function MA(z,M,X){if(M.image.length!==6)return;let BA=S(z,M),_=M.source;B.bindTexture(E.TEXTURE_CUBE_MAP,z.__webglTexture,E.TEXTURE0+X);let AA=Q.get(_);if(_.version!==AA.__version||BA===!0){B.activeTexture(E.TEXTURE0+X);let rA=KA.getPrimaries(KA.workingColorSpace),PA=M.colorSpace===OB?null:KA.getPrimaries(M.colorSpace),IA=M.colorSpace===OB||rA===PA?E.NONE:E.BROWSER_DEFAULT_WEBGL;E.pixelStorei(E.UNPACK_FLIP_Y_WEBGL,M.flipY),E.pixelStorei(E.UNPACK_PREMULTIPLY_ALPHA_WEBGL,M.premultiplyAlpha),E.pixelStorei(E.UNPACK_ALIGNMENT,M.unpackAlignment),E.pixelStorei(E.UNPACK_COLORSPACE_CONVERSION_WEBGL,IA);let uA=M.isCompressedTexture||M.image[0].isCompressedTexture,LA=M.image[0]&&M.image[0].isDataTexture,K=[];for(let fA=0;fA<6;fA++)!uA&&!LA?K[fA]=i(M.image[fA],!1,!0,g.maxCubemapSize):K[fA]=LA?M.image[fA].image:M.image[fA],K[fA]=xA(M,K[fA]);let VA=K[0],d=r(VA)||f,J=v.convert(M.format,M.colorSpace),wA=v.convert(M.type),QA=l(M.internalFormat,J,wA,M.colorSpace),iA=f&&M.isVideoTexture!==!0,yA=AA.__version===void 0||BA===!0,kA=F(M,VA,d);O(E.TEXTURE_CUBE_MAP,M,d);let YA;if(uA){iA&&yA&&B.texStorage2D(E.TEXTURE_CUBE_MAP,kA,QA,VA.width,VA.height);for(let fA=0;fA<6;fA++){YA=K[fA].mipmaps;for(let m=0;m<YA.length;m++){let gA=YA[m];M.format!==KB?J!==null?iA?B.compressedTexSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m,0,0,gA.width,gA.height,J,gA.data):B.compressedTexImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m,QA,gA.width,gA.height,0,gA.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):iA?B.texSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m,0,0,gA.width,gA.height,J,wA,gA.data):B.texImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m,QA,gA.width,gA.height,0,J,wA,gA.data)}}}else{YA=M.mipmaps,iA&&yA&&(YA.length>0&&kA++,B.texStorage2D(E.TEXTURE_CUBE_MAP,kA,QA,K[0].width,K[0].height));for(let fA=0;fA<6;fA++)if(LA){iA?B.texSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,0,0,0,K[fA].width,K[fA].height,J,wA,K[fA].data):B.texImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,0,QA,K[fA].width,K[fA].height,0,J,wA,K[fA].data);for(let m=0;m<YA.length;m++){let vA=YA[m].image[fA].image;iA?B.texSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m+1,0,0,vA.width,vA.height,J,wA,vA.data):B.texImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m+1,QA,vA.width,vA.height,0,J,wA,vA.data)}}else{iA?B.texSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,0,0,0,J,wA,K[fA]):B.texImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,0,QA,J,wA,K[fA]);for(let m=0;m<YA.length;m++){let gA=YA[m];iA?B.texSubImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m+1,0,0,J,wA,gA.image[fA]):B.texImage2D(E.TEXTURE_CUBE_MAP_POSITIVE_X+fA,m+1,QA,J,wA,gA.image[fA])}}}H(M,d)&&o(E.TEXTURE_CUBE_MAP),AA.__version=_.version,M.onUpdate&&M.onUpdate(M)}z.__version=M.version}function sA(z,M,X,BA,_,AA){let rA=v.convert(X.format,X.colorSpace),PA=v.convert(X.type),IA=l(X.internalFormat,rA,PA,X.colorSpace);if(!Q.get(M).__hasExternalTextures){let LA=Math.max(1,M.width>>AA),K=Math.max(1,M.height>>AA);_===E.TEXTURE_3D||_===E.TEXTURE_2D_ARRAY?B.texImage3D(_,AA,IA,LA,K,M.depth,0,rA,PA,null):B.texImage2D(_,AA,IA,LA,K,0,rA,PA,null)}B.bindFramebuffer(E.FRAMEBUFFER,z),nA(M)?C.framebufferTexture2DMultisampleEXT(E.FRAMEBUFFER,BA,_,Q.get(X).__webglTexture,0,bA(M)):(_===E.TEXTURE_2D||_>=E.TEXTURE_CUBE_MAP_POSITIVE_X&&_<=E.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&E.framebufferTexture2D(E.FRAMEBUFFER,BA,_,Q.get(X).__webglTexture,AA),B.bindFramebuffer(E.FRAMEBUFFER,null)}function pA(z,M,X){if(E.bindRenderbuffer(E.RENDERBUFFER,z),M.depthBuffer&&!M.stencilBuffer){let BA=f===!0?E.DEPTH_COMPONENT24:E.DEPTH_COMPONENT16;if(X||nA(M)){let _=M.depthTexture;_&&_.isDepthTexture&&(_.type===GQ?BA=E.DEPTH_COMPONENT32F:_.type===xQ&&(BA=E.DEPTH_COMPONENT24));let AA=bA(M);nA(M)?C.renderbufferStorageMultisampleEXT(E.RENDERBUFFER,AA,BA,M.width,M.height):E.renderbufferStorageMultisample(E.RENDERBUFFER,AA,BA,M.width,M.height)}else E.renderbufferStorage(E.RENDERBUFFER,BA,M.width,M.height);E.framebufferRenderbuffer(E.FRAMEBUFFER,E.DEPTH_ATTACHMENT,E.RENDERBUFFER,z)}else if(M.depthBuffer&&M.stencilBuffer){let BA=bA(M);X&&nA(M)===!1?E.renderbufferStorageMultisample(E.RENDERBUFFER,BA,E.DEPTH24_STENCIL8,M.width,M.height):nA(M)?C.renderbufferStorageMultisampleEXT(E.RENDERBUFFER,BA,E.DEPTH24_STENCIL8,M.width,M.height):E.renderbufferStorage(E.RENDERBUFFER,E.DEPTH_STENCIL,M.width,M.height),E.framebufferRenderbuffer(E.FRAMEBUFFER,E.DEPTH_STENCIL_ATTACHMENT,E.RENDERBUFFER,z)}else{let BA=M.isWebGLMultipleRenderTargets===!0?M.texture:[M.texture];for(let _=0;_<BA.length;_++){let AA=BA[_],rA=v.convert(AA.format,AA.colorSpace),PA=v.convert(AA.type),IA=l(AA.internalFormat,rA,PA,AA.colorSpace),uA=bA(M);X&&nA(M)===!1?E.renderbufferStorageMultisample(E.RENDERBUFFER,uA,IA,M.width,M.height):nA(M)?C.renderbufferStorageMultisampleEXT(E.RENDERBUFFER,uA,IA,M.width,M.height):E.renderbufferStorage(E.RENDERBUFFER,IA,M.width,M.height)}}E.bindRenderbuffer(E.RENDERBUFFER,null)}function FA(z,M){if(M&&M.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(B.bindFramebuffer(E.FRAMEBUFFER,z),!(M.depthTexture&&M.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!Q.get(M.depthTexture).__webglTexture||M.depthTexture.image.width!==M.width||M.depthTexture.image.height!==M.height)&&(M.depthTexture.image.width=M.width,M.depthTexture.image.height=M.height,M.depthTexture.needsUpdate=!0),N(M.depthTexture,0);let BA=Q.get(M.depthTexture).__webglTexture,_=bA(M);if(M.depthTexture.format===BE)nA(M)?C.framebufferTexture2DMultisampleEXT(E.FRAMEBUFFER,E.DEPTH_ATTACHMENT,E.TEXTURE_2D,BA,0,_):E.framebufferTexture2D(E.FRAMEBUFFER,E.DEPTH_ATTACHMENT,E.TEXTURE_2D,BA,0);else if(M.depthTexture.format===kE)nA(M)?C.framebufferTexture2DMultisampleEXT(E.FRAMEBUFFER,E.DEPTH_STENCIL_ATTACHMENT,E.TEXTURE_2D,BA,0,_):E.framebufferTexture2D(E.FRAMEBUFFER,E.DEPTH_STENCIL_ATTACHMENT,E.TEXTURE_2D,BA,0);else throw new Error("Unknown depthTexture format")}function HA(z){let M=Q.get(z),X=z.isWebGLCubeRenderTarget===!0;if(z.depthTexture&&!M.__autoAllocateDepthBuffer){if(X)throw new Error("target.depthTexture not supported in Cube render targets");FA(M.__webglFramebuffer,z)}else if(X){M.__webglDepthbuffer=[];for(let BA=0;BA<6;BA++)B.bindFramebuffer(E.FRAMEBUFFER,M.__webglFramebuffer[BA]),M.__webglDepthbuffer[BA]=E.createRenderbuffer(),pA(M.__webglDepthbuffer[BA],z,!1)}else B.bindFramebuffer(E.FRAMEBUFFER,M.__webglFramebuffer),M.__webglDepthbuffer=E.createRenderbuffer(),pA(M.__webglDepthbuffer,z,!1);B.bindFramebuffer(E.FRAMEBUFFER,null)}function ZA(z,M,X){let BA=Q.get(z);M!==void 0&&sA(BA.__webglFramebuffer,z,z.texture,E.COLOR_ATTACHMENT0,E.TEXTURE_2D,0),X!==void 0&&HA(z)}function U(z){let M=z.texture,X=Q.get(z),BA=Q.get(M);z.addEventListener("dispose",Z),z.isWebGLMultipleRenderTargets!==!0&&(BA.__webglTexture===void 0&&(BA.__webglTexture=E.createTexture()),BA.__version=M.version,w.memory.textures++);let _=z.isWebGLCubeRenderTarget===!0,AA=z.isWebGLMultipleRenderTargets===!0,rA=r(z)||f;if(_){X.__webglFramebuffer=[];for(let PA=0;PA<6;PA++)if(f&&M.mipmaps&&M.mipmaps.length>0){X.__webglFramebuffer[PA]=[];for(let IA=0;IA<M.mipmaps.length;IA++)X.__webglFramebuffer[PA][IA]=E.createFramebuffer()}else X.__webglFramebuffer[PA]=E.createFramebuffer()}else{if(f&&M.mipmaps&&M.mipmaps.length>0){X.__webglFramebuffer=[];for(let PA=0;PA<M.mipmaps.length;PA++)X.__webglFramebuffer[PA]=E.createFramebuffer()}else X.__webglFramebuffer=E.createFramebuffer();if(AA)if(g.drawBuffers){let PA=z.texture;for(let IA=0,uA=PA.length;IA<uA;IA++){let LA=Q.get(PA[IA]);LA.__webglTexture===void 0&&(LA.__webglTexture=E.createTexture(),w.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(f&&z.samples>0&&nA(z)===!1){let PA=AA?M:[M];X.__webglMultisampledFramebuffer=E.createFramebuffer(),X.__webglColorRenderbuffer=[],B.bindFramebuffer(E.FRAMEBUFFER,X.__webglMultisampledFramebuffer);for(let IA=0;IA<PA.length;IA++){let uA=PA[IA];X.__webglColorRenderbuffer[IA]=E.createRenderbuffer(),E.bindRenderbuffer(E.RENDERBUFFER,X.__webglColorRenderbuffer[IA]);let LA=v.convert(uA.format,uA.colorSpace),K=v.convert(uA.type),VA=l(uA.internalFormat,LA,K,uA.colorSpace,z.isXRRenderTarget===!0),d=bA(z);E.renderbufferStorageMultisample(E.RENDERBUFFER,d,VA,z.width,z.height),E.framebufferRenderbuffer(E.FRAMEBUFFER,E.COLOR_ATTACHMENT0+IA,E.RENDERBUFFER,X.__webglColorRenderbuffer[IA])}E.bindRenderbuffer(E.RENDERBUFFER,null),z.depthBuffer&&(X.__webglDepthRenderbuffer=E.createRenderbuffer(),pA(X.__webglDepthRenderbuffer,z,!0)),B.bindFramebuffer(E.FRAMEBUFFER,null)}}if(_){B.bindTexture(E.TEXTURE_CUBE_MAP,BA.__webglTexture),O(E.TEXTURE_CUBE_MAP,M,rA);for(let PA=0;PA<6;PA++)if(f&&M.mipmaps&&M.mipmaps.length>0)for(let IA=0;IA<M.mipmaps.length;IA++)sA(X.__webglFramebuffer[PA][IA],z,M,E.COLOR_ATTACHMENT0,E.TEXTURE_CUBE_MAP_POSITIVE_X+PA,IA);else sA(X.__webglFramebuffer[PA],z,M,E.COLOR_ATTACHMENT0,E.TEXTURE_CUBE_MAP_POSITIVE_X+PA,0);H(M,rA)&&o(E.TEXTURE_CUBE_MAP),B.unbindTexture()}else if(AA){let PA=z.texture;for(let IA=0,uA=PA.length;IA<uA;IA++){let LA=PA[IA],K=Q.get(LA);B.bindTexture(E.TEXTURE_2D,K.__webglTexture),O(E.TEXTURE_2D,LA,rA),sA(X.__webglFramebuffer,z,LA,E.COLOR_ATTACHMENT0+IA,E.TEXTURE_2D,0),H(LA,rA)&&o(E.TEXTURE_2D)}B.unbindTexture()}else{let PA=E.TEXTURE_2D;if((z.isWebGL3DRenderTarget||z.isWebGLArrayRenderTarget)&&(f?PA=z.isWebGL3DRenderTarget?E.TEXTURE_3D:E.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),B.bindTexture(PA,BA.__webglTexture),O(PA,M,rA),f&&M.mipmaps&&M.mipmaps.length>0)for(let IA=0;IA<M.mipmaps.length;IA++)sA(X.__webglFramebuffer[IA],z,M,E.COLOR_ATTACHMENT0,PA,IA);else sA(X.__webglFramebuffer,z,M,E.COLOR_ATTACHMENT0,PA,0);H(M,rA)&&o(PA),B.unbindTexture()}z.depthBuffer&&HA(z)}function DB(z){let M=r(z)||f,X=z.isWebGLMultipleRenderTargets===!0?z.texture:[z.texture];for(let BA=0,_=X.length;BA<_;BA++){let AA=X[BA];if(H(AA,M)){let rA=z.isWebGLCubeRenderTarget?E.TEXTURE_CUBE_MAP:E.TEXTURE_2D,PA=Q.get(AA).__webglTexture;B.bindTexture(rA,PA),o(rA),B.unbindTexture()}}}function aA(z){if(f&&z.samples>0&&nA(z)===!1){let M=z.isWebGLMultipleRenderTargets?z.texture:[z.texture],X=z.width,BA=z.height,_=E.COLOR_BUFFER_BIT,AA=[],rA=z.stencilBuffer?E.DEPTH_STENCIL_ATTACHMENT:E.DEPTH_ATTACHMENT,PA=Q.get(z),IA=z.isWebGLMultipleRenderTargets===!0;if(IA)for(let uA=0;uA<M.length;uA++)B.bindFramebuffer(E.FRAMEBUFFER,PA.__webglMultisampledFramebuffer),E.framebufferRenderbuffer(E.FRAMEBUFFER,E.COLOR_ATTACHMENT0+uA,E.RENDERBUFFER,null),B.bindFramebuffer(E.FRAMEBUFFER,PA.__webglFramebuffer),E.framebufferTexture2D(E.DRAW_FRAMEBUFFER,E.COLOR_ATTACHMENT0+uA,E.TEXTURE_2D,null,0);B.bindFramebuffer(E.READ_FRAMEBUFFER,PA.__webglMultisampledFramebuffer),B.bindFramebuffer(E.DRAW_FRAMEBUFFER,PA.__webglFramebuffer);for(let uA=0;uA<M.length;uA++){AA.push(E.COLOR_ATTACHMENT0+uA),z.depthBuffer&&AA.push(rA);let LA=PA.__ignoreDepthValues!==void 0?PA.__ignoreDepthValues:!1;if(LA===!1&&(z.depthBuffer&&(_|=E.DEPTH_BUFFER_BIT),z.stencilBuffer&&(_|=E.STENCIL_BUFFER_BIT)),IA&&E.framebufferRenderbuffer(E.READ_FRAMEBUFFER,E.COLOR_ATTACHMENT0,E.RENDERBUFFER,PA.__webglColorRenderbuffer[uA]),LA===!0&&(E.invalidateFramebuffer(E.READ_FRAMEBUFFER,[rA]),E.invalidateFramebuffer(E.DRAW_FRAMEBUFFER,[rA])),IA){let K=Q.get(M[uA]).__webglTexture;E.framebufferTexture2D(E.DRAW_FRAMEBUFFER,E.COLOR_ATTACHMENT0,E.TEXTURE_2D,K,0)}E.blitFramebuffer(0,0,X,BA,0,0,X,BA,_,E.NEAREST),e&&E.invalidateFramebuffer(E.READ_FRAMEBUFFER,AA)}if(B.bindFramebuffer(E.READ_FRAMEBUFFER,null),B.bindFramebuffer(E.DRAW_FRAMEBUFFER,null),IA)for(let uA=0;uA<M.length;uA++){B.bindFramebuffer(E.FRAMEBUFFER,PA.__webglMultisampledFramebuffer),E.framebufferRenderbuffer(E.FRAMEBUFFER,E.COLOR_ATTACHMENT0+uA,E.RENDERBUFFER,PA.__webglColorRenderbuffer[uA]);let LA=Q.get(M[uA]).__webglTexture;B.bindFramebuffer(E.FRAMEBUFFER,PA.__webglFramebuffer),E.framebufferTexture2D(E.DRAW_FRAMEBUFFER,E.COLOR_ATTACHMENT0+uA,E.TEXTURE_2D,LA,0)}B.bindFramebuffer(E.DRAW_FRAMEBUFFER,PA.__webglMultisampledFramebuffer)}}function bA(z){return Math.min(g.maxSamples,z.samples)}function nA(z){let M=Q.get(z);return f&&z.samples>0&&A.has("WEBGL_multisampled_render_to_texture")===!0&&M.__useRenderToTexture!==!1}function BB(z){let M=w.render.frame;P.get(z)!==M&&(P.set(z,M),z.update())}function xA(z,M){let X=z.colorSpace,BA=z.format,_=z.type;return z.isCompressedTexture===!0||z.isVideoTexture===!0||z.format===kf||X!==aQ&&X!==OB&&(KA.getTransfer(X)===QB?f===!1?A.has("EXT_sRGB")===!0&&BA===KB?(z.format=kf,z.minFilter=bB,z.generateMipmaps=!1):M=Mv.sRGBToLinear(M):(BA!==KB||_!==XQ)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",X)),M}this.allocateTextureUnit=p,this.resetTextureUnits=EA,this.setTexture2D=N,this.setTexture2DArray=k,this.setTexture3D=V,this.setTextureCube=R,this.rebindTextures=ZA,this.setupRenderTarget=U,this.updateRenderTargetMipmap=DB,this.updateMultisampleRenderTarget=aA,this.setupDepthRenderbuffer=HA,this.setupFrameBufferTexture=sA,this.useMultisampledRTT=nA}function t9(E,A,B){let Q=B.isWebGL2;function g(v,w=OB){let f,C=KA.getTransfer(w);if(v===XQ)return E.UNSIGNED_BYTE;if(v===y7)return E.UNSIGNED_SHORT_4_4_4_4;if(v===O7)return E.UNSIGNED_SHORT_5_5_5_1;if(v===ZP)return E.BYTE;if(v===VP)return E.SHORT;if(v===Hw)return E.UNSIGNED_SHORT;if(v===j7)return E.INT;if(v===xQ)return E.UNSIGNED_INT;if(v===GQ)return E.FLOAT;if(v===Mg)return Q?E.HALF_FLOAT:(f=A.get("OES_texture_half_float"),f!==null?f.HALF_FLOAT_OES:null);if(v===kP)return E.ALPHA;if(v===KB)return E.RGBA;if(v===qP)return E.LUMINANCE;if(v===JP)return E.LUMINANCE_ALPHA;if(v===BE)return E.DEPTH_COMPONENT;if(v===kE)return E.DEPTH_STENCIL;if(v===kf)return f=A.get("EXT_sRGB"),f!==null?f.SRGB_ALPHA_EXT:null;if(v===WP)return E.RED;if(v===N7)return E.RED_INTEGER;if(v===SP)return E.RG;if(v===R7)return E.RG_INTEGER;if(v===Z7)return E.RGBA_INTEGER;if(v===ef||v===Pf||v===tf||v===Df)if(C===QB)if(f=A.get("WEBGL_compressed_texture_s3tc_srgb"),f!==null){if(v===ef)return f.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(v===Pf)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(v===tf)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(v===Df)return f.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(f=A.get("WEBGL_compressed_texture_s3tc"),f!==null){if(v===ef)return f.COMPRESSED_RGB_S3TC_DXT1_EXT;if(v===Pf)return f.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(v===tf)return f.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(v===Df)return f.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(v===rC||v===sC||v===iC||v===MC)if(f=A.get("WEBGL_compressed_texture_pvrtc"),f!==null){if(v===rC)return f.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(v===sC)return f.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(v===iC)return f.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(v===MC)return f.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(v===V7)return f=A.get("WEBGL_compressed_texture_etc1"),f!==null?f.COMPRESSED_RGB_ETC1_WEBGL:null;if(v===oC||v===cC)if(f=A.get("WEBGL_compressed_texture_etc"),f!==null){if(v===oC)return C===QB?f.COMPRESSED_SRGB8_ETC2:f.COMPRESSED_RGB8_ETC2;if(v===cC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:f.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(v===aC||v===zC||v===HC||v===uC||v===dC||v===lC||v===hC||v===bC||v===mC||v===pC||v===FC||v===xC||v===GC||v===LC)if(f=A.get("WEBGL_compressed_texture_astc"),f!==null){if(v===aC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:f.COMPRESSED_RGBA_ASTC_4x4_KHR;if(v===zC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:f.COMPRESSED_RGBA_ASTC_5x4_KHR;if(v===HC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:f.COMPRESSED_RGBA_ASTC_5x5_KHR;if(v===uC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:f.COMPRESSED_RGBA_ASTC_6x5_KHR;if(v===dC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:f.COMPRESSED_RGBA_ASTC_6x6_KHR;if(v===lC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:f.COMPRESSED_RGBA_ASTC_8x5_KHR;if(v===hC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:f.COMPRESSED_RGBA_ASTC_8x6_KHR;if(v===bC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:f.COMPRESSED_RGBA_ASTC_8x8_KHR;if(v===mC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:f.COMPRESSED_RGBA_ASTC_10x5_KHR;if(v===pC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:f.COMPRESSED_RGBA_ASTC_10x6_KHR;if(v===FC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:f.COMPRESSED_RGBA_ASTC_10x8_KHR;if(v===xC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:f.COMPRESSED_RGBA_ASTC_10x10_KHR;if(v===GC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:f.COMPRESSED_RGBA_ASTC_12x10_KHR;if(v===LC)return C===QB?f.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:f.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(v===If||v===UC||v===XC)if(f=A.get("EXT_texture_compression_bptc"),f!==null){if(v===If)return C===QB?f.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:f.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(v===UC)return f.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(v===XC)return f.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(v===KP||v===YC||v===TC||v===jC)if(f=A.get("EXT_texture_compression_rgtc"),f!==null){if(v===If)return f.COMPRESSED_RED_RGTC1_EXT;if(v===YC)return f.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(v===TC)return f.COMPRESSED_RED_GREEN_RGTC2_EXT;if(v===jC)return f.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return v===AE?Q?E.UNSIGNED_INT_24_8:(f=A.get("WEBGL_depth_texture"),f!==null?f.UNSIGNED_INT_24_8_WEBGL:null):E[v]!==void 0?E[v]:null}return{convert:g}}var fw=class extends mB{constructor(A=[]){super(),this.isArrayCamera=!0,this.cameras=A}},cQ=class extends iB{constructor(){super(),this.isGroup=!0,this.type="Group"}},D9={type:"move"},ig=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new cQ,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new cQ,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new x,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new x),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new cQ,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new x,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new x),this._grip}dispatchEvent(A){return this._targetRay!==null&&this._targetRay.dispatchEvent(A),this._grip!==null&&this._grip.dispatchEvent(A),this._hand!==null&&this._hand.dispatchEvent(A),this}connect(A){if(A&&A.hand){let B=this._hand;if(B)for(let Q of A.hand.values())this._getHandJoint(B,Q)}return this.dispatchEvent({type:"connected",data:A}),this}disconnect(A){return this.dispatchEvent({type:"disconnected",data:A}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(A,B,Q){let g=null,v=null,w=null,f=this._targetRay,C=this._grip,e=this._hand;if(A&&B.session.visibilityState!=="visible-blurred"){if(e&&A.hand){w=!0;for(let i of A.hand.values()){let r=B.getJointPose(i,Q),I=this._getHandJoint(e,i);r!==null&&(I.matrix.fromArray(r.transform.matrix),I.matrix.decompose(I.position,I.rotation,I.scale),I.matrixWorldNeedsUpdate=!0,I.jointRadius=r.radius),I.visible=r!==null}let P=e.joints["index-finger-tip"],D=e.joints["thumb-tip"],t=P.position.distanceTo(D.position),n=.02,s=.005;e.inputState.pinching&&t>n+s?(e.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:A.handedness,target:this})):!e.inputState.pinching&&t<=n-s&&(e.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:A.handedness,target:this}))}else C!==null&&A.gripSpace&&(v=B.getPose(A.gripSpace,Q),v!==null&&(C.matrix.fromArray(v.transform.matrix),C.matrix.decompose(C.position,C.rotation,C.scale),C.matrixWorldNeedsUpdate=!0,v.linearVelocity?(C.hasLinearVelocity=!0,C.linearVelocity.copy(v.linearVelocity)):C.hasLinearVelocity=!1,v.angularVelocity?(C.hasAngularVelocity=!0,C.angularVelocity.copy(v.angularVelocity)):C.hasAngularVelocity=!1));f!==null&&(g=B.getPose(A.targetRaySpace,Q),g===null&&v!==null&&(g=v),g!==null&&(f.matrix.fromArray(g.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,g.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(g.linearVelocity)):f.hasLinearVelocity=!1,g.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(g.angularVelocity)):f.hasAngularVelocity=!1,this.dispatchEvent(D9)))}return f!==null&&(f.visible=g!==null),C!==null&&(C.visible=v!==null),e!==null&&(e.visible=w!==null),this}_getHandJoint(A,B){if(A.joints[B.jointName]===void 0){let Q=new cQ;Q.matrixAutoUpdate=!1,Q.visible=!1,A.joints[B.jointName]=Q,A.add(Q)}return A.joints[B.jointName]}},ww=class extends fQ{constructor(A,B){super();let Q=this,g=null,v=1,w=null,f="local-floor",C=1,e=null,P=null,D=null,t=null,n=null,s=null,i=B.getContextAttributes(),r=null,I=null,H=[],o=[],l=new hA,F=null,b=new mB;b.layers.enable(1),b.viewport=new sB;let h=new mB;h.layers.enable(2),h.viewport=new sB;let Z=[b,h],a=new fw;a.layers.enable(1),a.layers.enable(2);let u=null,y=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(O){let S=H[O];return S===void 0&&(S=new ig,H[O]=S),S.getTargetRaySpace()},this.getControllerGrip=function(O){let S=H[O];return S===void 0&&(S=new ig,H[O]=S),S.getGripSpace()},this.getHand=function(O){let S=H[O];return S===void 0&&(S=new ig,H[O]=S),S.getHandSpace()};function q(O){let S=o.indexOf(O.inputSource);if(S===-1)return;let tA=H[S];tA!==void 0&&(tA.update(O.inputSource,O.frame,e||w),tA.dispatchEvent({type:O.type,data:O.inputSource}))}function EA(){g.removeEventListener("select",q),g.removeEventListener("selectstart",q),g.removeEventListener("selectend",q),g.removeEventListener("squeeze",q),g.removeEventListener("squeezestart",q),g.removeEventListener("squeezeend",q),g.removeEventListener("end",EA),g.removeEventListener("inputsourceschange",p);for(let O=0;O<H.length;O++){let S=o[O];S!==null&&(o[O]=null,H[O].disconnect(S))}u=null,y=null,A.setRenderTarget(r),n=null,t=null,D=null,g=null,I=null,eA.stop(),Q.isPresenting=!1,A.setPixelRatio(F),A.setSize(l.width,l.height,!1),Q.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(O){v=O,Q.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(O){f=O,Q.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return e||w},this.setReferenceSpace=function(O){e=O},this.getBaseLayer=function(){return t!==null?t:n},this.getBinding=function(){return D},this.getFrame=function(){return s},this.getSession=function(){return g},this.setSession=async function(O){if(g=O,g!==null){if(r=A.getRenderTarget(),g.addEventListener("select",q),g.addEventListener("selectstart",q),g.addEventListener("selectend",q),g.addEventListener("squeeze",q),g.addEventListener("squeezestart",q),g.addEventListener("squeezeend",q),g.addEventListener("end",EA),g.addEventListener("inputsourceschange",p),i.xrCompatible!==!0&&await B.makeXRCompatible(),F=A.getPixelRatio(),A.getSize(l),g.renderState.layers===void 0||A.capabilities.isWebGL2===!1){let S={antialias:g.renderState.layers===void 0?i.antialias:!0,alpha:!0,depth:i.depth,stencil:i.stencil,framebufferScaleFactor:v};n=new XRWebGLLayer(g,B,S),g.updateRenderState({baseLayer:n}),A.setPixelRatio(1),A.setSize(n.framebufferWidth,n.framebufferHeight,!1),I=new zQ(n.framebufferWidth,n.framebufferHeight,{format:KB,type:XQ,colorSpace:A.outputColorSpace,stencilBuffer:i.stencil})}else{let S=null,tA=null,MA=null;i.depth&&(MA=i.stencil?B.DEPTH24_STENCIL8:B.DEPTH_COMPONENT24,S=i.stencil?kE:BE,tA=i.stencil?AE:xQ);let sA={colorFormat:B.RGBA8,depthFormat:MA,scaleFactor:v};D=new XRWebGLBinding(g,B),t=D.createProjectionLayer(sA),g.updateRenderState({layers:[t]}),A.setPixelRatio(1),A.setSize(t.textureWidth,t.textureHeight,!1),I=new zQ(t.textureWidth,t.textureHeight,{format:KB,type:XQ,depthTexture:new bv(t.textureWidth,t.textureHeight,tA,void 0,void 0,void 0,void 0,void 0,void 0,S),stencilBuffer:i.stencil,colorSpace:A.outputColorSpace,samples:i.antialias?4:0});let pA=A.properties.get(I);pA.__ignoreDepthValues=t.ignoreDepthValues}I.isXRRenderTarget=!0,this.setFoveation(C),e=null,w=await g.requestReferenceSpace(f),eA.setContext(g),eA.start(),Q.isPresenting=!0,Q.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(g!==null)return g.environmentBlendMode};function p(O){for(let S=0;S<O.removed.length;S++){let tA=O.removed[S],MA=o.indexOf(tA);MA>=0&&(o[MA]=null,H[MA].disconnect(tA))}for(let S=0;S<O.added.length;S++){let tA=O.added[S],MA=o.indexOf(tA);if(MA===-1){for(let pA=0;pA<H.length;pA++)if(pA>=o.length){o.push(tA),MA=pA;break}else if(o[pA]===null){o[pA]=tA,MA=pA;break}if(MA===-1)break}let sA=H[MA];sA&&sA.connect(tA)}}let L=new x,N=new x;function k(O,S,tA){L.setFromMatrixPosition(S.matrixWorld),N.setFromMatrixPosition(tA.matrixWorld);let MA=L.distanceTo(N),sA=S.projectionMatrix.elements,pA=tA.projectionMatrix.elements,FA=sA[14]/(sA[10]-1),HA=sA[14]/(sA[10]+1),ZA=(sA[9]+1)/sA[5],U=(sA[9]-1)/sA[5],DB=(sA[8]-1)/sA[0],aA=(pA[8]+1)/pA[0],bA=FA*DB,nA=FA*aA,BB=MA/(-DB+aA),xA=BB*-DB;S.matrixWorld.decompose(O.position,O.quaternion,O.scale),O.translateX(xA),O.translateZ(BB),O.matrixWorld.compose(O.position,O.quaternion,O.scale),O.matrixWorldInverse.copy(O.matrixWorld).invert();let z=FA+BB,M=HA+BB,X=bA-xA,BA=nA+(MA-xA),_=ZA*HA/M*z,AA=U*HA/M*z;O.projectionMatrix.makePerspective(X,BA,_,AA,z,M),O.projectionMatrixInverse.copy(O.projectionMatrix).invert()}function V(O,S){S===null?O.matrixWorld.copy(O.matrix):O.matrixWorld.multiplyMatrices(S.matrixWorld,O.matrix),O.matrixWorldInverse.copy(O.matrixWorld).invert()}this.updateCamera=function(O){if(g===null)return;a.near=h.near=b.near=O.near,a.far=h.far=b.far=O.far,(u!==a.near||y!==a.far)&&(g.updateRenderState({depthNear:a.near,depthFar:a.far}),u=a.near,y=a.far);let S=O.parent,tA=a.cameras;V(a,S);for(let MA=0;MA<tA.length;MA++)V(tA[MA],S);tA.length===2?k(a,b,h):a.projectionMatrix.copy(b.projectionMatrix),R(O,a,S)};function R(O,S,tA){tA===null?O.matrix.copy(S.matrixWorld):(O.matrix.copy(tA.matrixWorld),O.matrix.invert(),O.matrix.multiply(S.matrixWorld)),O.matrix.decompose(O.position,O.quaternion,O.scale),O.updateMatrixWorld(!0),O.projectionMatrix.copy(S.projectionMatrix),O.projectionMatrixInverse.copy(S.projectionMatrixInverse),O.isPerspectiveCamera&&(O.fov=og*2*Math.atan(1/O.projectionMatrix.elements[5]),O.zoom=1)}this.getCamera=function(){return a},this.getFoveation=function(){if(!(t===null&&n===null))return C},this.setFoveation=function(O){C=O,t!==null&&(t.fixedFoveation=O),n!==null&&n.fixedFoveation!==void 0&&(n.fixedFoveation=O)};let W=null;function $(O,S){if(P=S.getViewerPose(e||w),s=S,P!==null){let tA=P.views;n!==null&&(A.setRenderTargetFramebuffer(I,n.framebuffer),A.setRenderTarget(I));let MA=!1;tA.length!==a.cameras.length&&(a.cameras.length=0,MA=!0);for(let sA=0;sA<tA.length;sA++){let pA=tA[sA],FA=null;if(n!==null)FA=n.getViewport(pA);else{let ZA=D.getViewSubImage(t,pA);FA=ZA.viewport,sA===0&&(A.setRenderTargetTextures(I,ZA.colorTexture,t.ignoreDepthValues?void 0:ZA.depthStencilTexture),A.setRenderTarget(I))}let HA=Z[sA];HA===void 0&&(HA=new mB,HA.layers.enable(sA),HA.viewport=new sB,Z[sA]=HA),HA.matrix.fromArray(pA.transform.matrix),HA.matrix.decompose(HA.position,HA.quaternion,HA.scale),HA.projectionMatrix.fromArray(pA.projectionMatrix),HA.projectionMatrixInverse.copy(HA.projectionMatrix).invert(),HA.viewport.set(FA.x,FA.y,FA.width,FA.height),sA===0&&(a.matrix.copy(HA.matrix),a.matrix.decompose(a.position,a.quaternion,a.scale)),MA===!0&&a.cameras.push(HA)}}for(let tA=0;tA<H.length;tA++){let MA=o[tA],sA=H[tA];MA!==null&&sA!==void 0&&sA.update(MA,S,e||w)}W&&W(O,S),S.detectedPlanes&&Q.dispatchEvent({type:"planesdetected",data:S}),s=null}let eA=new $7;eA.setAnimationLoop($),this.setAnimationLoop=function(O){W=O},this.dispose=function(){}}};function I9(E,A){function B(r,I){r.matrixAutoUpdate===!0&&r.updateMatrix(),I.value.copy(r.matrix)}function Q(r,I){I.color.getRGB(r.fogColor.value,_7(E)),I.isFog?(r.fogNear.value=I.near,r.fogFar.value=I.far):I.isFogExp2&&(r.fogDensity.value=I.density)}function g(r,I,H,o,l){I.isMeshBasicMaterial||I.isMeshLambertMaterial?v(r,I):I.isMeshToonMaterial?(v(r,I),D(r,I)):I.isMeshPhongMaterial?(v(r,I),P(r,I)):I.isMeshStandardMaterial?(v(r,I),t(r,I),I.isMeshPhysicalMaterial&&n(r,I,l)):I.isMeshMatcapMaterial?(v(r,I),s(r,I)):I.isMeshDepthMaterial?v(r,I):I.isMeshDistanceMaterial?(v(r,I),i(r,I)):I.isMeshNormalMaterial?v(r,I):I.isLineBasicMaterial?(w(r,I),I.isLineDashedMaterial&&f(r,I)):I.isPointsMaterial?C(r,I,H,o):I.isSpriteMaterial?e(r,I):I.isShadowMaterial?(r.color.value.copy(I.color),r.opacity.value=I.opacity):I.isShaderMaterial&&(I.uniformsNeedUpdate=!1)}function v(r,I){r.opacity.value=I.opacity,I.color&&r.diffuse.value.copy(I.color),I.emissive&&r.emissive.value.copy(I.emissive).multiplyScalar(I.emissiveIntensity),I.map&&(r.map.value=I.map,B(I.map,r.mapTransform)),I.alphaMap&&(r.alphaMap.value=I.alphaMap,B(I.alphaMap,r.alphaMapTransform)),I.bumpMap&&(r.bumpMap.value=I.bumpMap,B(I.bumpMap,r.bumpMapTransform),r.bumpScale.value=I.bumpScale,I.side===FB&&(r.bumpScale.value*=-1)),I.normalMap&&(r.normalMap.value=I.normalMap,B(I.normalMap,r.normalMapTransform),r.normalScale.value.copy(I.normalScale),I.side===FB&&r.normalScale.value.negate()),I.displacementMap&&(r.displacementMap.value=I.displacementMap,B(I.displacementMap,r.displacementMapTransform),r.displacementScale.value=I.displacementScale,r.displacementBias.value=I.displacementBias),I.emissiveMap&&(r.emissiveMap.value=I.emissiveMap,B(I.emissiveMap,r.emissiveMapTransform)),I.specularMap&&(r.specularMap.value=I.specularMap,B(I.specularMap,r.specularMapTransform)),I.alphaTest>0&&(r.alphaTest.value=I.alphaTest);let H=A.get(I).envMap;if(H&&(r.envMap.value=H,r.flipEnvMap.value=H.isCubeTexture&&H.isRenderTargetTexture===!1?-1:1,r.reflectivity.value=I.reflectivity,r.ior.value=I.ior,r.refractionRatio.value=I.refractionRatio),I.lightMap){r.lightMap.value=I.lightMap;let o=E._useLegacyLights===!0?Math.PI:1;r.lightMapIntensity.value=I.lightMapIntensity*o,B(I.lightMap,r.lightMapTransform)}I.aoMap&&(r.aoMap.value=I.aoMap,r.aoMapIntensity.value=I.aoMapIntensity,B(I.aoMap,r.aoMapTransform))}function w(r,I){r.diffuse.value.copy(I.color),r.opacity.value=I.opacity,I.map&&(r.map.value=I.map,B(I.map,r.mapTransform))}function f(r,I){r.dashSize.value=I.dashSize,r.totalSize.value=I.dashSize+I.gapSize,r.scale.value=I.scale}function C(r,I,H,o){r.diffuse.value.copy(I.color),r.opacity.value=I.opacity,r.size.value=I.size*H,r.scale.value=o*.5,I.map&&(r.map.value=I.map,B(I.map,r.uvTransform)),I.alphaMap&&(r.alphaMap.value=I.alphaMap,B(I.alphaMap,r.alphaMapTransform)),I.alphaTest>0&&(r.alphaTest.value=I.alphaTest)}function e(r,I){r.diffuse.value.copy(I.color),r.opacity.value=I.opacity,r.rotation.value=I.rotation,I.map&&(r.map.value=I.map,B(I.map,r.mapTransform)),I.alphaMap&&(r.alphaMap.value=I.alphaMap,B(I.alphaMap,r.alphaMapTransform)),I.alphaTest>0&&(r.alphaTest.value=I.alphaTest)}function P(r,I){r.specular.value.copy(I.specular),r.shininess.value=Math.max(I.shininess,1e-4)}function D(r,I){I.gradientMap&&(r.gradientMap.value=I.gradientMap)}function t(r,I){r.metalness.value=I.metalness,I.metalnessMap&&(r.metalnessMap.value=I.metalnessMap,B(I.metalnessMap,r.metalnessMapTransform)),r.roughness.value=I.roughness,I.roughnessMap&&(r.roughnessMap.value=I.roughnessMap,B(I.roughnessMap,r.roughnessMapTransform)),A.get(I).envMap&&(r.envMapIntensity.value=I.envMapIntensity)}function n(r,I,H){r.ior.value=I.ior,I.sheen>0&&(r.sheenColor.value.copy(I.sheenColor).multiplyScalar(I.sheen),r.sheenRoughness.value=I.sheenRoughness,I.sheenColorMap&&(r.sheenColorMap.value=I.sheenColorMap,B(I.sheenColorMap,r.sheenColorMapTransform)),I.sheenRoughnessMap&&(r.sheenRoughnessMap.value=I.sheenRoughnessMap,B(I.sheenRoughnessMap,r.sheenRoughnessMapTransform))),I.clearcoat>0&&(r.clearcoat.value=I.clearcoat,r.clearcoatRoughness.value=I.clearcoatRoughness,I.clearcoatMap&&(r.clearcoatMap.value=I.clearcoatMap,B(I.clearcoatMap,r.clearcoatMapTransform)),I.clearcoatRoughnessMap&&(r.clearcoatRoughnessMap.value=I.clearcoatRoughnessMap,B(I.clearcoatRoughnessMap,r.clearcoatRoughnessMapTransform)),I.clearcoatNormalMap&&(r.clearcoatNormalMap.value=I.clearcoatNormalMap,B(I.clearcoatNormalMap,r.clearcoatNormalMapTransform),r.clearcoatNormalScale.value.copy(I.clearcoatNormalScale),I.side===FB&&r.clearcoatNormalScale.value.negate())),I.iridescence>0&&(r.iridescence.value=I.iridescence,r.iridescenceIOR.value=I.iridescenceIOR,r.iridescenceThicknessMinimum.value=I.iridescenceThicknessRange[0],r.iridescenceThicknessMaximum.value=I.iridescenceThicknessRange[1],I.iridescenceMap&&(r.iridescenceMap.value=I.iridescenceMap,B(I.iridescenceMap,r.iridescenceMapTransform)),I.iridescenceThicknessMap&&(r.iridescenceThicknessMap.value=I.iridescenceThicknessMap,B(I.iridescenceThicknessMap,r.iridescenceThicknessMapTransform))),I.transmission>0&&(r.transmission.value=I.transmission,r.transmissionSamplerMap.value=H.texture,r.transmissionSamplerSize.value.set(H.width,H.height),I.transmissionMap&&(r.transmissionMap.value=I.transmissionMap,B(I.transmissionMap,r.transmissionMapTransform)),r.thickness.value=I.thickness,I.thicknessMap&&(r.thicknessMap.value=I.thicknessMap,B(I.thicknessMap,r.thicknessMapTransform)),r.attenuationDistance.value=I.attenuationDistance,r.attenuationColor.value.copy(I.attenuationColor)),I.anisotropy>0&&(r.anisotropyVector.value.set(I.anisotropy*Math.cos(I.anisotropyRotation),I.anisotropy*Math.sin(I.anisotropyRotation)),I.anisotropyMap&&(r.anisotropyMap.value=I.anisotropyMap,B(I.anisotropyMap,r.anisotropyMapTransform))),r.specularIntensity.value=I.specularIntensity,r.specularColor.value.copy(I.specularColor),I.specularColorMap&&(r.specularColorMap.value=I.specularColorMap,B(I.specularColorMap,r.specularColorMapTransform)),I.specularIntensityMap&&(r.specularIntensityMap.value=I.specularIntensityMap,B(I.specularIntensityMap,r.specularIntensityMapTransform))}function s(r,I){I.matcap&&(r.matcap.value=I.matcap)}function i(r,I){let H=A.get(I).light;r.referencePosition.value.setFromMatrixPosition(H.matrixWorld),r.nearDistance.value=H.shadow.camera.near,r.farDistance.value=H.shadow.camera.far}return{refreshFogUniforms:Q,refreshMaterialUniforms:g}}function n9(E,A,B,Q){let g={},v={},w=[],f=B.isWebGL2?E.getParameter(E.MAX_UNIFORM_BUFFER_BINDINGS):0;function C(H,o){let l=o.program;Q.uniformBlockBinding(H,l)}function e(H,o){let l=g[H.id];l===void 0&&(s(H),l=P(H),g[H.id]=l,H.addEventListener("dispose",r));let F=o.program;Q.updateUBOMapping(H,F);let b=A.render.frame;v[H.id]!==b&&(t(H),v[H.id]=b)}function P(H){let o=D();H.__bindingPointIndex=o;let l=E.createBuffer(),F=H.__size,b=H.usage;return E.bindBuffer(E.UNIFORM_BUFFER,l),E.bufferData(E.UNIFORM_BUFFER,F,b),E.bindBuffer(E.UNIFORM_BUFFER,null),E.bindBufferBase(E.UNIFORM_BUFFER,o,l),l}function D(){for(let H=0;H<f;H++)if(w.indexOf(H)===-1)return w.push(H),H;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function t(H){let o=g[H.id],l=H.uniforms,F=H.__cache;E.bindBuffer(E.UNIFORM_BUFFER,o);for(let b=0,h=l.length;b<h;b++){let Z=Array.isArray(l[b])?l[b]:[l[b]];for(let a=0,u=Z.length;a<u;a++){let y=Z[a];if(n(y,b,a,F)===!0){let q=y.__offset,EA=Array.isArray(y.value)?y.value:[y.value],p=0;for(let L=0;L<EA.length;L++){let N=EA[L],k=i(N);typeof N=="number"||typeof N=="boolean"?(y.__data[0]=N,E.bufferSubData(E.UNIFORM_BUFFER,q+p,y.__data)):N.isMatrix3?(y.__data[0]=N.elements[0],y.__data[1]=N.elements[1],y.__data[2]=N.elements[2],y.__data[3]=0,y.__data[4]=N.elements[3],y.__data[5]=N.elements[4],y.__data[6]=N.elements[5],y.__data[7]=0,y.__data[8]=N.elements[6],y.__data[9]=N.elements[7],y.__data[10]=N.elements[8],y.__data[11]=0):(N.toArray(y.__data,p),p+=k.storage/Float32Array.BYTES_PER_ELEMENT)}E.bufferSubData(E.UNIFORM_BUFFER,q,y.__data)}}}E.bindBuffer(E.UNIFORM_BUFFER,null)}function n(H,o,l,F){let b=H.value,h=o+"_"+l;if(F[h]===void 0)return typeof b=="number"||typeof b=="boolean"?F[h]=b:F[h]=b.clone(),!0;{let Z=F[h];if(typeof b=="number"||typeof b=="boolean"){if(Z!==b)return F[h]=b,!0}else if(Z.equals(b)===!1)return Z.copy(b),!0}return!1}function s(H){let o=H.uniforms,l=0,F=16;for(let h=0,Z=o.length;h<Z;h++){let a=Array.isArray(o[h])?o[h]:[o[h]];for(let u=0,y=a.length;u<y;u++){let q=a[u],EA=Array.isArray(q.value)?q.value:[q.value];for(let p=0,L=EA.length;p<L;p++){let N=EA[p],k=i(N),V=l%F;V!==0&&F-V<k.boundary&&(l+=F-V),q.__data=new Float32Array(k.storage/Float32Array.BYTES_PER_ELEMENT),q.__offset=l,l+=k.storage}}}let b=l%F;return b>0&&(l+=F-b),H.__size=l,H.__cache={},this}function i(H){let o={boundary:0,storage:0};return typeof H=="number"||typeof H=="boolean"?(o.boundary=4,o.storage=4):H.isVector2?(o.boundary=8,o.storage=8):H.isVector3||H.isColor?(o.boundary=16,o.storage=12):H.isVector4?(o.boundary=16,o.storage=16):H.isMatrix3?(o.boundary=48,o.storage=48):H.isMatrix4?(o.boundary=64,o.storage=64):H.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",H),o}function r(H){let o=H.target;o.removeEventListener("dispose",r);let l=w.indexOf(o.__bindingPointIndex);w.splice(l,1),E.deleteBuffer(g[o.id]),delete g[o.id],delete v[o.id]}function I(){for(let H in g)E.deleteBuffer(g[H]);w=[],g={},v={}}return{bind:C,update:e,dispose:I}}var ug=class{constructor(A={}){let{canvas:B=zt(),context:Q=null,depth:g=!0,stencil:v=!0,alpha:w=!1,antialias:f=!1,premultipliedAlpha:C=!0,preserveDrawingBuffer:e=!1,powerPreference:P="default",failIfMajorPerformanceCaveat:D=!1}=A;this.isWebGLRenderer=!0;let t;Q!==null?t=Q.getContextAttributes().alpha:t=w;let n=new Uint32Array(4),s=new Int32Array(4),i=null,r=null,I=[],H=[];this.domElement=B,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=eB,this._useLegacyLights=!1,this.toneMapping=UQ,this.toneMappingExposure=1;let o=this,l=!1,F=0,b=0,h=null,Z=-1,a=null,u=new sB,y=new sB,q=null,EA=new lA(0),p=0,L=B.width,N=B.height,k=1,V=null,R=null,W=new sB(0,0,L,N),$=new sB(0,0,L,N),eA=!1,O=new zg,S=!1,tA=!1,MA=null,sA=new fB,pA=new hA,FA=new x,HA={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function ZA(){return h===null?k:1}let U=Q;function DB(c,G){for(let T=0;T<c.length;T++){let j=c[T],Y=B.getContext(j,G);if(Y!==null)return Y}return null}try{let c={alpha:!0,depth:g,stencil:v,antialias:f,premultipliedAlpha:C,preserveDrawingBuffer:e,powerPreference:P,failIfMajorPerformanceCaveat:D};if("setAttribute"in B&&B.setAttribute("data-engine","three.js r160"),B.addEventListener("webglcontextlost",fA,!1),B.addEventListener("webglcontextrestored",m,!1),B.addEventListener("webglcontextcreationerror",gA,!1),U===null){let G=["webgl2","webgl","experimental-webgl"];if(o.isWebGL1Renderer===!0&&G.shift(),U=DB(G,c),U===null)throw DB(G)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&U instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),U.getShaderPrecisionFormat===void 0&&(U.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(c){throw console.error("THREE.WebGLRenderer: "+c.message),c}let aA,bA,nA,BB,xA,z,M,X,BA,_,AA,rA,PA,IA,uA,LA,K,VA,d,J,wA,QA,iA,yA;function kA(){aA=new x8(U),bA=new l8(U,aA,A),aA.init(bA),QA=new t9(U,aA,bA),nA=new e9(U,aA,bA),BB=new U8(U),xA=new Kn,z=new P9(U,aA,nA,xA,bA,QA,BB),M=new b8(o),X=new F8(o),BA=new Rt(U,bA),iA=new u8(U,aA,BA,bA),_=new G8(U,BA,BB,iA),AA=new j8(U,_,BA,BB),d=new T8(U,bA,z),LA=new h8(xA),rA=new Sn(o,M,X,aA,bA,iA,LA),PA=new I9(o,xA),IA=new $n,uA=new v9(aA,bA),VA=new H8(o,M,X,nA,AA,t,C),K=new C9(o,AA,bA),yA=new n9(U,BB,bA,nA),J=new d8(U,aA,BB,bA),wA=new L8(U,aA,BB,bA),BB.programs=rA.programs,o.capabilities=bA,o.extensions=aA,o.properties=xA,o.renderLists=IA,o.shadowMap=K,o.state=nA,o.info=BB}kA();let YA=new ww(o,U);this.xr=YA,this.getContext=function(){return U},this.getContextAttributes=function(){return U.getContextAttributes()},this.forceContextLoss=function(){let c=aA.get("WEBGL_lose_context");c&&c.loseContext()},this.forceContextRestore=function(){let c=aA.get("WEBGL_lose_context");c&&c.restoreContext()},this.getPixelRatio=function(){return k},this.setPixelRatio=function(c){c!==void 0&&(k=c,this.setSize(L,N,!1))},this.getSize=function(c){return c.set(L,N)},this.setSize=function(c,G,T=!0){if(YA.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}L=c,N=G,B.width=Math.floor(c*k),B.height=Math.floor(G*k),T===!0&&(B.style.width=c+"px",B.style.height=G+"px"),this.setViewport(0,0,c,G)},this.getDrawingBufferSize=function(c){return c.set(L*k,N*k).floor()},this.setDrawingBufferSize=function(c,G,T){L=c,N=G,k=T,B.width=Math.floor(c*T),B.height=Math.floor(G*T),this.setViewport(0,0,c,G)},this.getCurrentViewport=function(c){return c.copy(u)},this.getViewport=function(c){return c.copy(W)},this.setViewport=function(c,G,T,j){c.isVector4?W.set(c.x,c.y,c.z,c.w):W.set(c,G,T,j),nA.viewport(u.copy(W).multiplyScalar(k).floor())},this.getScissor=function(c){return c.copy($)},this.setScissor=function(c,G,T,j){c.isVector4?$.set(c.x,c.y,c.z,c.w):$.set(c,G,T,j),nA.scissor(y.copy($).multiplyScalar(k).floor())},this.getScissorTest=function(){return eA},this.setScissorTest=function(c){nA.setScissorTest(eA=c)},this.setOpaqueSort=function(c){V=c},this.setTransparentSort=function(c){R=c},this.getClearColor=function(c){return c.copy(VA.getClearColor())},this.setClearColor=function(){VA.setClearColor.apply(VA,arguments)},this.getClearAlpha=function(){return VA.getClearAlpha()},this.setClearAlpha=function(){VA.setClearAlpha.apply(VA,arguments)},this.clear=function(c=!0,G=!0,T=!0){let j=0;if(c){let Y=!1;if(h!==null){let DA=h.texture.format;Y=DA===Z7||DA===R7||DA===N7}if(Y){let DA=h.texture.type,cA=DA===XQ||DA===xQ||DA===Hw||DA===AE||DA===y7||DA===O7,dA=VA.getClearColor(),mA=VA.getClearAlpha(),TA=dA.r,GA=dA.g,UA=dA.b;cA?(n[0]=TA,n[1]=GA,n[2]=UA,n[3]=mA,U.clearBufferuiv(U.COLOR,0,n)):(s[0]=TA,s[1]=GA,s[2]=UA,s[3]=mA,U.clearBufferiv(U.COLOR,0,s))}else j|=U.COLOR_BUFFER_BIT}G&&(j|=U.DEPTH_BUFFER_BIT),T&&(j|=U.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),U.clear(j)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){B.removeEventListener("webglcontextlost",fA,!1),B.removeEventListener("webglcontextrestored",m,!1),B.removeEventListener("webglcontextcreationerror",gA,!1),IA.dispose(),uA.dispose(),xA.dispose(),M.dispose(),X.dispose(),AA.dispose(),iA.dispose(),yA.dispose(),rA.dispose(),YA.dispose(),YA.removeEventListener("sessionstart",HB),YA.removeEventListener("sessionend",$A),MA&&(MA.dispose(),MA=null),uB.stop()};function fA(c){c.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),l=!0}function m(){console.log("THREE.WebGLRenderer: Context Restored."),l=!1;let c=BB.autoReset,G=K.enabled,T=K.autoUpdate,j=K.needsUpdate,Y=K.type;kA(),BB.autoReset=c,K.enabled=G,K.autoUpdate=T,K.needsUpdate=j,K.type=Y}function gA(c){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",c.statusMessage)}function vA(c){let G=c.target;G.removeEventListener("dispose",vA),zA(G)}function zA(c){oA(c),xA.remove(c)}function oA(c){let G=xA.get(c).programs;G!==void 0&&(G.forEach(function(T){rA.releaseProgram(T)}),c.isShaderMaterial&&rA.releaseShaderCache(c))}this.renderBufferDirect=function(c,G,T,j,Y,DA){G===null&&(G=HA);let cA=Y.isMesh&&Y.matrixWorld.determinant()<0,dA=fP(c,G,T,j,Y);nA.setMaterial(j,cA);let mA=T.index,TA=1;if(j.wireframe===!0){if(mA=_.getWireframeAttribute(T),mA===void 0)return;TA=2}let GA=T.drawRange,UA=T.attributes.position,wB=GA.start*TA,xB=(GA.start+GA.count)*TA;DA!==null&&(wB=Math.max(wB,DA.start*TA),xB=Math.min(xB,(DA.start+DA.count)*TA)),mA!==null?(wB=Math.max(wB,0),xB=Math.min(xB,mA.count)):UA!=null&&(wB=Math.max(wB,0),xB=Math.min(xB,UA.count));let nB=xB-wB;if(nB<0||nB===1/0)return;iA.setup(Y,j,dA,T,mA);let DQ,gB=J;if(mA!==null&&(DQ=BA.get(mA),gB=wA,gB.setIndex(DQ)),Y.isMesh)j.wireframe===!0?(nA.setLineWidth(j.wireframeLinewidth*ZA()),gB.setMode(U.LINES)):gB.setMode(U.TRIANGLES);else if(Y.isLine){let OA=j.linewidth;OA===void 0&&(OA=1),nA.setLineWidth(OA*ZA()),Y.isLineSegments?gB.setMode(U.LINES):Y.isLineLoop?gB.setMode(U.LINE_LOOP):gB.setMode(U.LINE_STRIP)}else Y.isPoints?gB.setMode(U.POINTS):Y.isSprite&&gB.setMode(U.TRIANGLES);if(Y.isBatchedMesh)gB.renderMultiDraw(Y._multiDrawStarts,Y._multiDrawCounts,Y._multiDrawCount);else if(Y.isInstancedMesh)gB.renderInstances(wB,nB,Y.count);else if(T.isInstancedBufferGeometry){let OA=T._maxInstanceCount!==void 0?T._maxInstanceCount:1/0,gf=Math.min(T.instanceCount,OA);gB.renderInstances(wB,nB,gf)}else gB.render(wB,nB)};function JA(c,G,T){c.transparent===!0&&c.side===yB&&c.forceSinglePass===!1?(c.side=FB,c.needsUpdate=!0,Tg(c,G,T),c.side=YQ,c.needsUpdate=!0,Tg(c,G,T),c.side=yB):Tg(c,G,T)}this.compile=function(c,G,T=null){T===null&&(T=c),r=uA.get(T),r.init(),H.push(r),T.traverseVisible(function(Y){Y.isLight&&Y.layers.test(G.layers)&&(r.pushLight(Y),Y.castShadow&&r.pushShadow(Y))}),c!==T&&c.traverseVisible(function(Y){Y.isLight&&Y.layers.test(G.layers)&&(r.pushLight(Y),Y.castShadow&&r.pushShadow(Y))}),r.setupLights(o._useLegacyLights);let j=new Set;return c.traverse(function(Y){let DA=Y.material;if(DA)if(Array.isArray(DA))for(let cA=0;cA<DA.length;cA++){let dA=DA[cA];JA(dA,T,Y),j.add(dA)}else JA(DA,T,Y),j.add(DA)}),H.pop(),r=null,j},this.compileAsync=function(c,G,T=null){let j=this.compile(c,G,T);return new Promise(Y=>{function DA(){if(j.forEach(function(cA){xA.get(cA).currentProgram.isReady()&&j.delete(cA)}),j.size===0){Y(c);return}setTimeout(DA,10)}aA.get("KHR_parallel_shader_compile")!==null?DA():setTimeout(DA,10)})};let WA=null;function IB(c){WA&&WA(c)}function HB(){uB.stop()}function $A(){uB.start()}let uB=new $7;uB.setAnimationLoop(IB),typeof self<"u"&&uB.setContext(self),this.setAnimationLoop=function(c){WA=c,YA.setAnimationLoop(c),c===null?uB.stop():uB.start()},YA.addEventListener("sessionstart",HB),YA.addEventListener("sessionend",$A),this.render=function(c,G){if(G!==void 0&&G.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(l===!0)return;c.matrixWorldAutoUpdate===!0&&c.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),YA.enabled===!0&&YA.isPresenting===!0&&(YA.cameraAutoUpdate===!0&&YA.updateCamera(G),G=YA.getCamera()),c.isScene===!0&&c.onBeforeRender(o,c,G,h),r=uA.get(c,H.length),r.init(),H.push(r),sA.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),O.setFromProjectionMatrix(sA),tA=this.localClippingEnabled,S=LA.init(this.clippingPlanes,tA),i=IA.get(c,I.length),i.init(),I.push(i),gQ(c,G,0,o.sortObjects),i.finish(),o.sortObjects===!0&&i.sort(V,R),this.info.render.frame++,S===!0&&LA.beginShadows();let T=r.state.shadowsArray;if(K.render(T,c,G),S===!0&&LA.endShadows(),this.info.autoReset===!0&&this.info.reset(),VA.render(i,c),r.setupLights(o._useLegacyLights),G.isArrayCamera){let j=G.cameras;for(let Y=0,DA=j.length;Y<DA;Y++){let cA=j[Y];QC(i,c,cA,cA.viewport)}}else QC(i,c,G);h!==null&&(z.updateMultisampleRenderTarget(h),z.updateRenderTargetMipmap(h)),c.isScene===!0&&c.onAfterRender(o,c,G),iA.resetDefaultState(),Z=-1,a=null,H.pop(),H.length>0?r=H[H.length-1]:r=null,I.pop(),I.length>0?i=I[I.length-1]:i=null};function gQ(c,G,T,j){if(c.visible===!1)return;if(c.layers.test(G.layers)){if(c.isGroup)T=c.renderOrder;else if(c.isLOD)c.autoUpdate===!0&&c.update(G);else if(c.isLight)r.pushLight(c),c.castShadow&&r.pushShadow(c);else if(c.isSprite){if(!c.frustumCulled||O.intersectsSprite(c)){j&&FA.setFromMatrixPosition(c.matrixWorld).applyMatrix4(sA);let cA=AA.update(c),dA=c.material;dA.visible&&i.push(c,cA,dA,T,FA.z,null)}}else if((c.isMesh||c.isLine||c.isPoints)&&(!c.frustumCulled||O.intersectsObject(c))){let cA=AA.update(c),dA=c.material;if(j&&(c.boundingSphere!==void 0?(c.boundingSphere===null&&c.computeBoundingSphere(),FA.copy(c.boundingSphere.center)):(cA.boundingSphere===null&&cA.computeBoundingSphere(),FA.copy(cA.boundingSphere.center)),FA.applyMatrix4(c.matrixWorld).applyMatrix4(sA)),Array.isArray(dA)){let mA=cA.groups;for(let TA=0,GA=mA.length;TA<GA;TA++){let UA=mA[TA],wB=dA[UA.materialIndex];wB&&wB.visible&&i.push(c,cA,wB,T,FA.z,UA)}}else dA.visible&&i.push(c,cA,dA,T,FA.z,null)}}let DA=c.children;for(let cA=0,dA=DA.length;cA<dA;cA++)gQ(DA[cA],G,T,j)}function QC(c,G,T,j){let Y=c.opaque,DA=c.transmissive,cA=c.transparent;r.setupLightsView(T),S===!0&&LA.setGlobalState(o.clippingPlanes,T),DA.length>0&&vP(Y,DA,G,T),j&&nA.viewport(u.copy(j)),Y.length>0&&Yg(Y,G,T),DA.length>0&&Yg(DA,G,T),cA.length>0&&Yg(cA,G,T),nA.buffers.depth.setTest(!0),nA.buffers.depth.setMask(!0),nA.buffers.color.setMask(!0),nA.setPolygonOffset(!1)}function vP(c,G,T,j){if((T.isScene===!0?T.overrideMaterial:null)!==null)return;let DA=bA.isWebGL2;MA===null&&(MA=new zQ(1,1,{generateMipmaps:!0,type:aA.has("EXT_color_buffer_half_float")?Mg:XQ,minFilter:TQ,samples:DA?4:0})),o.getDrawingBufferSize(pA),DA?MA.setSize(pA.x,pA.y):MA.setSize(sv(pA.x),sv(pA.y));let cA=o.getRenderTarget();o.setRenderTarget(MA),o.getClearColor(EA),p=o.getClearAlpha(),p<1&&o.setClearColor(16777215,.5),o.clear();let dA=o.toneMapping;o.toneMapping=UQ,Yg(c,T,j),z.updateMultisampleRenderTarget(MA),z.updateRenderTargetMipmap(MA);let mA=!1;for(let TA=0,GA=G.length;TA<GA;TA++){let UA=G[TA],wB=UA.object,xB=UA.geometry,nB=UA.material,DQ=UA.group;if(nB.side===yB&&wB.layers.test(j.layers)){let gB=nB.side;nB.side=FB,nB.needsUpdate=!0,EC(wB,T,j,xB,nB,DQ),nB.side=gB,nB.needsUpdate=!0,mA=!0}}mA===!0&&(z.updateMultisampleRenderTarget(MA),z.updateRenderTargetMipmap(MA)),o.setRenderTarget(cA),o.setClearColor(EA,p),o.toneMapping=dA}function Yg(c,G,T){let j=G.isScene===!0?G.overrideMaterial:null;for(let Y=0,DA=c.length;Y<DA;Y++){let cA=c[Y],dA=cA.object,mA=cA.geometry,TA=j===null?cA.material:j,GA=cA.group;dA.layers.test(T.layers)&&EC(dA,G,T,mA,TA,GA)}}function EC(c,G,T,j,Y,DA){c.onBeforeRender(o,G,T,j,Y,DA),c.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,c.matrixWorld),c.normalMatrix.getNormalMatrix(c.modelViewMatrix),Y.onBeforeRender(o,G,T,j,c,DA),Y.transparent===!0&&Y.side===yB&&Y.forceSinglePass===!1?(Y.side=FB,Y.needsUpdate=!0,o.renderBufferDirect(T,G,j,Y,c,DA),Y.side=YQ,Y.needsUpdate=!0,o.renderBufferDirect(T,G,j,Y,c,DA),Y.side=yB):o.renderBufferDirect(T,G,j,Y,c,DA),c.onAfterRender(o,G,T,j,Y,DA)}function Tg(c,G,T){G.isScene!==!0&&(G=HA);let j=xA.get(c),Y=r.state.lights,DA=r.state.shadowsArray,cA=Y.state.version,dA=rA.getParameters(c,Y.state,DA,G,T),mA=rA.getProgramCacheKey(dA),TA=j.programs;j.environment=c.isMeshStandardMaterial?G.environment:null,j.fog=G.fog,j.envMap=(c.isMeshStandardMaterial?X:M).get(c.envMap||j.environment),TA===void 0&&(c.addEventListener("dispose",vA),TA=new Map,j.programs=TA);let GA=TA.get(mA);if(GA!==void 0){if(j.currentProgram===GA&&j.lightsStateVersion===cA)return vC(c,dA),GA}else dA.uniforms=rA.getUniforms(c),c.onBuild(T,dA,o),c.onBeforeCompile(dA,o),GA=rA.acquireProgram(dA,mA),TA.set(mA,GA),j.uniforms=dA.uniforms;let UA=j.uniforms;return(!c.isShaderMaterial&&!c.isRawShaderMaterial||c.clipping===!0)&&(UA.clippingPlanes=LA.uniform),vC(c,dA),j.needsLights=CP(c),j.lightsStateVersion=cA,j.needsLights&&(UA.ambientLightColor.value=Y.state.ambient,UA.lightProbe.value=Y.state.probe,UA.directionalLights.value=Y.state.directional,UA.directionalLightShadows.value=Y.state.directionalShadow,UA.spotLights.value=Y.state.spot,UA.spotLightShadows.value=Y.state.spotShadow,UA.rectAreaLights.value=Y.state.rectArea,UA.ltc_1.value=Y.state.rectAreaLTC1,UA.ltc_2.value=Y.state.rectAreaLTC2,UA.pointLights.value=Y.state.point,UA.pointLightShadows.value=Y.state.pointShadow,UA.hemisphereLights.value=Y.state.hemi,UA.directionalShadowMap.value=Y.state.directionalShadowMap,UA.directionalShadowMatrix.value=Y.state.directionalShadowMatrix,UA.spotShadowMap.value=Y.state.spotShadowMap,UA.spotLightMatrix.value=Y.state.spotLightMatrix,UA.spotLightMap.value=Y.state.spotLightMap,UA.pointShadowMap.value=Y.state.pointShadowMap,UA.pointShadowMatrix.value=Y.state.pointShadowMatrix),j.currentProgram=GA,j.uniformsList=null,GA}function gC(c){if(c.uniformsList===null){let G=c.currentProgram.getUniforms();c.uniformsList=RE.seqWithValue(G.seq,c.uniforms)}return c.uniformsList}function vC(c,G){let T=xA.get(c);T.outputColorSpace=G.outputColorSpace,T.batching=G.batching,T.instancing=G.instancing,T.instancingColor=G.instancingColor,T.skinning=G.skinning,T.morphTargets=G.morphTargets,T.morphNormals=G.morphNormals,T.morphColors=G.morphColors,T.morphTargetsCount=G.morphTargetsCount,T.numClippingPlanes=G.numClippingPlanes,T.numIntersection=G.numClipIntersection,T.vertexAlphas=G.vertexAlphas,T.vertexTangents=G.vertexTangents,T.toneMapping=G.toneMapping}function fP(c,G,T,j,Y){G.isScene!==!0&&(G=HA),z.resetTextureUnits();let DA=G.fog,cA=j.isMeshStandardMaterial?G.environment:null,dA=h===null?o.outputColorSpace:h.isXRRenderTarget===!0?h.texture.colorSpace:aQ,mA=(j.isMeshStandardMaterial?X:M).get(j.envMap||cA),TA=j.vertexColors===!0&&!!T.attributes.color&&T.attributes.color.itemSize===4,GA=!!T.attributes.tangent&&(!!j.normalMap||j.anisotropy>0),UA=!!T.morphAttributes.position,wB=!!T.morphAttributes.normal,xB=!!T.morphAttributes.color,nB=UQ;j.toneMapped&&(h===null||h.isXRRenderTarget===!0)&&(nB=o.toneMapping);let DQ=T.morphAttributes.position||T.morphAttributes.normal||T.morphAttributes.color,gB=DQ!==void 0?DQ.length:0,OA=xA.get(j),gf=r.state.lights;if(S===!0&&(tA===!0||c!==a)){let TB=c===a&&j.id===Z;LA.setState(j,c,TB)}let vB=!1;j.version===OA.__version?(OA.needsLights&&OA.lightsStateVersion!==gf.state.version||OA.outputColorSpace!==dA||Y.isBatchedMesh&&OA.batching===!1||!Y.isBatchedMesh&&OA.batching===!0||Y.isInstancedMesh&&OA.instancing===!1||!Y.isInstancedMesh&&OA.instancing===!0||Y.isSkinnedMesh&&OA.skinning===!1||!Y.isSkinnedMesh&&OA.skinning===!0||Y.isInstancedMesh&&OA.instancingColor===!0&&Y.instanceColor===null||Y.isInstancedMesh&&OA.instancingColor===!1&&Y.instanceColor!==null||OA.envMap!==mA||j.fog===!0&&OA.fog!==DA||OA.numClippingPlanes!==void 0&&(OA.numClippingPlanes!==LA.numPlanes||OA.numIntersection!==LA.numIntersection)||OA.vertexAlphas!==TA||OA.vertexTangents!==GA||OA.morphTargets!==UA||OA.morphNormals!==wB||OA.morphColors!==xB||OA.toneMapping!==nB||bA.isWebGL2===!0&&OA.morphTargetsCount!==gB)&&(vB=!0):(vB=!0,OA.__version=j.version);let VQ=OA.currentProgram;vB===!0&&(VQ=Tg(j,G,Y));let fC=!1,eg=!1,vf=!1,MB=VQ.getUniforms(),kQ=OA.uniforms;if(nA.useProgram(VQ.program)&&(fC=!0,eg=!0,vf=!0),j.id!==Z&&(Z=j.id,eg=!0),fC||a!==c){MB.setValue(U,"projectionMatrix",c.projectionMatrix),MB.setValue(U,"viewMatrix",c.matrixWorldInverse);let TB=MB.map.cameraPosition;TB!==void 0&&TB.setValue(U,FA.setFromMatrixPosition(c.matrixWorld)),bA.logarithmicDepthBuffer&&MB.setValue(U,"logDepthBufFC",2/(Math.log(c.far+1)/Math.LN2)),(j.isMeshPhongMaterial||j.isMeshToonMaterial||j.isMeshLambertMaterial||j.isMeshBasicMaterial||j.isMeshStandardMaterial||j.isShaderMaterial)&&MB.setValue(U,"isOrthographic",c.isOrthographicCamera===!0),a!==c&&(a=c,eg=!0,vf=!0)}if(Y.isSkinnedMesh){MB.setOptional(U,Y,"bindMatrix"),MB.setOptional(U,Y,"bindMatrixInverse");let TB=Y.skeleton;TB&&(bA.floatVertexTextures?(TB.boneTexture===null&&TB.computeBoneTexture(),MB.setValue(U,"boneTexture",TB.boneTexture,z)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}Y.isBatchedMesh&&(MB.setOptional(U,Y,"batchingTexture"),MB.setValue(U,"batchingTexture",Y._matricesTexture,z));let ff=T.morphAttributes;if((ff.position!==void 0||ff.normal!==void 0||ff.color!==void 0&&bA.isWebGL2===!0)&&d.update(Y,T,VQ),(eg||OA.receiveShadow!==Y.receiveShadow)&&(OA.receiveShadow=Y.receiveShadow,MB.setValue(U,"receiveShadow",Y.receiveShadow)),j.isMeshGouraudMaterial&&j.envMap!==null&&(kQ.envMap.value=mA,kQ.flipEnvMap.value=mA.isCubeTexture&&mA.isRenderTargetTexture===!1?-1:1),eg&&(MB.setValue(U,"toneMappingExposure",o.toneMappingExposure),OA.needsLights&&wP(kQ,vf),DA&&j.fog===!0&&PA.refreshFogUniforms(kQ,DA),PA.refreshMaterialUniforms(kQ,j,k,N,MA),RE.upload(U,gC(OA),kQ,z)),j.isShaderMaterial&&j.uniformsNeedUpdate===!0&&(RE.upload(U,gC(OA),kQ,z),j.uniformsNeedUpdate=!1),j.isSpriteMaterial&&MB.setValue(U,"center",Y.center),MB.setValue(U,"modelViewMatrix",Y.modelViewMatrix),MB.setValue(U,"normalMatrix",Y.normalMatrix),MB.setValue(U,"modelMatrix",Y.matrixWorld),j.isShaderMaterial||j.isRawShaderMaterial){let TB=j.uniformsGroups;for(let wf=0,eP=TB.length;wf<eP;wf++)if(bA.isWebGL2){let wC=TB[wf];yA.update(wC,VQ),yA.bind(wC,VQ)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return VQ}function wP(c,G){c.ambientLightColor.needsUpdate=G,c.lightProbe.needsUpdate=G,c.directionalLights.needsUpdate=G,c.directionalLightShadows.needsUpdate=G,c.pointLights.needsUpdate=G,c.pointLightShadows.needsUpdate=G,c.spotLights.needsUpdate=G,c.spotLightShadows.needsUpdate=G,c.rectAreaLights.needsUpdate=G,c.hemisphereLights.needsUpdate=G}function CP(c){return c.isMeshLambertMaterial||c.isMeshToonMaterial||c.isMeshPhongMaterial||c.isMeshStandardMaterial||c.isShadowMaterial||c.isShaderMaterial&&c.lights===!0}this.getActiveCubeFace=function(){return F},this.getActiveMipmapLevel=function(){return b},this.getRenderTarget=function(){return h},this.setRenderTargetTextures=function(c,G,T){xA.get(c.texture).__webglTexture=G,xA.get(c.depthTexture).__webglTexture=T;let j=xA.get(c);j.__hasExternalTextures=!0,j.__hasExternalTextures&&(j.__autoAllocateDepthBuffer=T===void 0,j.__autoAllocateDepthBuffer||aA.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),j.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(c,G){let T=xA.get(c);T.__webglFramebuffer=G,T.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(c,G=0,T=0){h=c,F=G,b=T;let j=!0,Y=null,DA=!1,cA=!1;if(c){let mA=xA.get(c);mA.__useDefaultFramebuffer!==void 0?(nA.bindFramebuffer(U.FRAMEBUFFER,null),j=!1):mA.__webglFramebuffer===void 0?z.setupRenderTarget(c):mA.__hasExternalTextures&&z.rebindTextures(c,xA.get(c.texture).__webglTexture,xA.get(c.depthTexture).__webglTexture);let TA=c.texture;(TA.isData3DTexture||TA.isDataArrayTexture||TA.isCompressedArrayTexture)&&(cA=!0);let GA=xA.get(c).__webglFramebuffer;c.isWebGLCubeRenderTarget?(Array.isArray(GA[G])?Y=GA[G][T]:Y=GA[G],DA=!0):bA.isWebGL2&&c.samples>0&&z.useMultisampledRTT(c)===!1?Y=xA.get(c).__webglMultisampledFramebuffer:Array.isArray(GA)?Y=GA[T]:Y=GA,u.copy(c.viewport),y.copy(c.scissor),q=c.scissorTest}else u.copy(W).multiplyScalar(k).floor(),y.copy($).multiplyScalar(k).floor(),q=eA;if(nA.bindFramebuffer(U.FRAMEBUFFER,Y)&&bA.drawBuffers&&j&&nA.drawBuffers(c,Y),nA.viewport(u),nA.scissor(y),nA.setScissorTest(q),DA){let mA=xA.get(c.texture);U.framebufferTexture2D(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,U.TEXTURE_CUBE_MAP_POSITIVE_X+G,mA.__webglTexture,T)}else if(cA){let mA=xA.get(c.texture),TA=G||0;U.framebufferTextureLayer(U.FRAMEBUFFER,U.COLOR_ATTACHMENT0,mA.__webglTexture,T||0,TA)}Z=-1},this.readRenderTargetPixels=function(c,G,T,j,Y,DA,cA){if(!(c&&c.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let dA=xA.get(c).__webglFramebuffer;if(c.isWebGLCubeRenderTarget&&cA!==void 0&&(dA=dA[cA]),dA){nA.bindFramebuffer(U.FRAMEBUFFER,dA);try{let mA=c.texture,TA=mA.format,GA=mA.type;if(TA!==KB&&QA.convert(TA)!==U.getParameter(U.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}let UA=GA===Mg&&(aA.has("EXT_color_buffer_half_float")||bA.isWebGL2&&aA.has("EXT_color_buffer_float"));if(GA!==XQ&&QA.convert(GA)!==U.getParameter(U.IMPLEMENTATION_COLOR_READ_TYPE)&&!(GA===GQ&&(bA.isWebGL2||aA.has("OES_texture_float")||aA.has("WEBGL_color_buffer_float")))&&!UA){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=c.width-j&&T>=0&&T<=c.height-Y&&U.readPixels(G,T,j,Y,QA.convert(TA),QA.convert(GA),DA)}finally{let mA=h!==null?xA.get(h).__webglFramebuffer:null;nA.bindFramebuffer(U.FRAMEBUFFER,mA)}}},this.copyFramebufferToTexture=function(c,G,T=0){let j=Math.pow(2,-T),Y=Math.floor(G.image.width*j),DA=Math.floor(G.image.height*j);z.setTexture2D(G,0),U.copyTexSubImage2D(U.TEXTURE_2D,T,0,0,c.x,c.y,Y,DA),nA.unbindTexture()},this.copyTextureToTexture=function(c,G,T,j=0){let Y=G.image.width,DA=G.image.height,cA=QA.convert(T.format),dA=QA.convert(T.type);z.setTexture2D(T,0),U.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,T.flipY),U.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),U.pixelStorei(U.UNPACK_ALIGNMENT,T.unpackAlignment),G.isDataTexture?U.texSubImage2D(U.TEXTURE_2D,j,c.x,c.y,Y,DA,cA,dA,G.image.data):G.isCompressedTexture?U.compressedTexSubImage2D(U.TEXTURE_2D,j,c.x,c.y,G.mipmaps[0].width,G.mipmaps[0].height,cA,G.mipmaps[0].data):U.texSubImage2D(U.TEXTURE_2D,j,c.x,c.y,cA,dA,G.image),j===0&&T.generateMipmaps&&U.generateMipmap(U.TEXTURE_2D),nA.unbindTexture()},this.copyTextureToTexture3D=function(c,G,T,j,Y=0){if(o.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}let DA=c.max.x-c.min.x+1,cA=c.max.y-c.min.y+1,dA=c.max.z-c.min.z+1,mA=QA.convert(j.format),TA=QA.convert(j.type),GA;if(j.isData3DTexture)z.setTexture3D(j,0),GA=U.TEXTURE_3D;else if(j.isDataArrayTexture||j.isCompressedArrayTexture)z.setTexture2DArray(j,0),GA=U.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}U.pixelStorei(U.UNPACK_FLIP_Y_WEBGL,j.flipY),U.pixelStorei(U.UNPACK_PREMULTIPLY_ALPHA_WEBGL,j.premultiplyAlpha),U.pixelStorei(U.UNPACK_ALIGNMENT,j.unpackAlignment);let UA=U.getParameter(U.UNPACK_ROW_LENGTH),wB=U.getParameter(U.UNPACK_IMAGE_HEIGHT),xB=U.getParameter(U.UNPACK_SKIP_PIXELS),nB=U.getParameter(U.UNPACK_SKIP_ROWS),DQ=U.getParameter(U.UNPACK_SKIP_IMAGES),gB=T.isCompressedTexture?T.mipmaps[Y]:T.image;U.pixelStorei(U.UNPACK_ROW_LENGTH,gB.width),U.pixelStorei(U.UNPACK_IMAGE_HEIGHT,gB.height),U.pixelStorei(U.UNPACK_SKIP_PIXELS,c.min.x),U.pixelStorei(U.UNPACK_SKIP_ROWS,c.min.y),U.pixelStorei(U.UNPACK_SKIP_IMAGES,c.min.z),T.isDataTexture||T.isData3DTexture?U.texSubImage3D(GA,Y,G.x,G.y,G.z,DA,cA,dA,mA,TA,gB.data):T.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),U.compressedTexSubImage3D(GA,Y,G.x,G.y,G.z,DA,cA,dA,mA,gB.data)):U.texSubImage3D(GA,Y,G.x,G.y,G.z,DA,cA,dA,mA,TA,gB),U.pixelStorei(U.UNPACK_ROW_LENGTH,UA),U.pixelStorei(U.UNPACK_IMAGE_HEIGHT,wB),U.pixelStorei(U.UNPACK_SKIP_PIXELS,xB),U.pixelStorei(U.UNPACK_SKIP_ROWS,nB),U.pixelStorei(U.UNPACK_SKIP_IMAGES,DQ),Y===0&&j.generateMipmaps&&U.generateMipmap(GA),nA.unbindTexture()},this.initTexture=function(c){c.isCubeTexture?z.setTextureCube(c,0):c.isData3DTexture?z.setTexture3D(c,0):c.isDataArrayTexture||c.isCompressedArrayTexture?z.setTexture2DArray(c,0):z.setTexture2D(c,0),nA.unbindTexture()},this.resetState=function(){F=0,b=0,h=null,nA.reset(),iA.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return oQ}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(A){this._outputColorSpace=A;let B=this.getContext();B.drawingBufferColorSpace=A===uw?"display-p3":"srgb",B.unpackColorSpace=KA.workingColorSpace===Uv?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===eB?QE:k7}set outputEncoding(A){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=A===QE?eB:aQ}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(A){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=A}},Cw=class extends ug{};Cw.prototype.isWebGL1Renderer=!0;var mv=class extends iB{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(A,B){return super.copy(A,B),A.background!==null&&(this.background=A.background.clone()),A.environment!==null&&(this.environment=A.environment.clone()),A.fog!==null&&(this.fog=A.fog.clone()),this.backgroundBlurriness=A.backgroundBlurriness,this.backgroundIntensity=A.backgroundIntensity,A.overrideMaterial!==null&&(this.overrideMaterial=A.overrideMaterial.clone()),this.matrixAutoUpdate=A.matrixAutoUpdate,this}toJSON(A){let B=super.toJSON(A);return this.fog!==null&&(B.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(B.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(B.object.backgroundIntensity=this.backgroundIntensity),B}};var vE=class extends jQ{constructor(A){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new lA(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(A)}copy(A){return super.copy(A),this.color.copy(A.color),this.map=A.map,this.linewidth=A.linewidth,this.linecap=A.linecap,this.linejoin=A.linejoin,this.fog=A.fog,this}},p7=new x,F7=new x,x7=new fB,Tf=new gE,wv=new qE,SE=class extends iB{constructor(A=new YB,B=new vE){super(),this.isLine=!0,this.type="Line",this.geometry=A,this.material=B,this.updateMorphTargets()}copy(A,B){return super.copy(A,B),this.material=Array.isArray(A.material)?A.material.slice():A.material,this.geometry=A.geometry,this}computeLineDistances(){let A=this.geometry;if(A.index===null){let B=A.attributes.position,Q=[0];for(let g=1,v=B.count;g<v;g++)p7.fromBufferAttribute(B,g-1),F7.fromBufferAttribute(B,g),Q[g]=Q[g-1],Q[g]+=p7.distanceTo(F7);A.setAttribute("lineDistance",new XB(Q,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(A,B){let Q=this.geometry,g=this.matrixWorld,v=A.params.Line.threshold,w=Q.drawRange;if(Q.boundingSphere===null&&Q.computeBoundingSphere(),wv.copy(Q.boundingSphere),wv.applyMatrix4(g),wv.radius+=v,A.ray.intersectsSphere(wv)===!1)return;x7.copy(g).invert(),Tf.copy(A.ray).applyMatrix4(x7);let f=v/((this.scale.x+this.scale.y+this.scale.z)/3),C=f*f,e=new x,P=new x,D=new x,t=new x,n=this.isLineSegments?2:1,s=Q.index,r=Q.attributes.position;if(s!==null){let I=Math.max(0,w.start),H=Math.min(s.count,w.start+w.count);for(let o=I,l=H-1;o<l;o+=n){let F=s.getX(o),b=s.getX(o+1);if(e.fromBufferAttribute(r,F),P.fromBufferAttribute(r,b),Tf.distanceSqToSegment(e,P,t,D)>C)continue;t.applyMatrix4(this.matrixWorld);let Z=A.ray.origin.distanceTo(t);Z<A.near||Z>A.far||B.push({distance:Z,point:D.clone().applyMatrix4(this.matrixWorld),index:o,face:null,faceIndex:null,object:this})}}else{let I=Math.max(0,w.start),H=Math.min(r.count,w.start+w.count);for(let o=I,l=H-1;o<l;o+=n){if(e.fromBufferAttribute(r,o),P.fromBufferAttribute(r,o+1),Tf.distanceSqToSegment(e,P,t,D)>C)continue;t.applyMatrix4(this.matrixWorld);let b=A.ray.origin.distanceTo(t);b<A.near||b>A.far||B.push({distance:b,point:D.clone().applyMatrix4(this.matrixWorld),index:o,face:null,faceIndex:null,object:this})}}}updateMorphTargets(){let B=this.geometry.morphAttributes,Q=Object.keys(B);if(Q.length>0){let g=B[Q[0]];if(g!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let v=0,w=g.length;v<w;v++){let f=g[v].name||String(v);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=v}}}}};var dg=class extends RB{constructor(A,B,Q,g,v,w,f,C,e){super(A,B,Q,g,v,w,f,C,e),this.isCanvasTexture=!0,this.needsUpdate=!0}};var pv=class extends jQ{constructor(A){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.type="MeshStandardMaterial",this.color=new lA(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new lA(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=q7,this.normalScale=new hA(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(A)}copy(A){return super.copy(A),this.defines={STANDARD:""},this.color.copy(A.color),this.roughness=A.roughness,this.metalness=A.metalness,this.map=A.map,this.lightMap=A.lightMap,this.lightMapIntensity=A.lightMapIntensity,this.aoMap=A.aoMap,this.aoMapIntensity=A.aoMapIntensity,this.emissive.copy(A.emissive),this.emissiveMap=A.emissiveMap,this.emissiveIntensity=A.emissiveIntensity,this.bumpMap=A.bumpMap,this.bumpScale=A.bumpScale,this.normalMap=A.normalMap,this.normalMapType=A.normalMapType,this.normalScale.copy(A.normalScale),this.displacementMap=A.displacementMap,this.displacementScale=A.displacementScale,this.displacementBias=A.displacementBias,this.roughnessMap=A.roughnessMap,this.metalnessMap=A.metalnessMap,this.alphaMap=A.alphaMap,this.envMap=A.envMap,this.envMapIntensity=A.envMapIntensity,this.wireframe=A.wireframe,this.wireframeLinewidth=A.wireframeLinewidth,this.wireframeLinecap=A.wireframeLinecap,this.wireframeLinejoin=A.wireframeLinejoin,this.flatShading=A.flatShading,this.fog=A.fog,this}};function Cv(E,A,B){return!E||!B&&E.constructor===A?E:typeof A.BYTES_PER_ELEMENT=="number"?new A(E):Array.prototype.slice.call(E)}function r9(E){return ArrayBuffer.isView(E)&&!(E instanceof DataView)}var KE=class{constructor(A,B,Q,g){this.parameterPositions=A,this._cachedIndex=0,this.resultBuffer=g!==void 0?g:new B.constructor(Q),this.sampleValues=B,this.valueSize=Q,this.settings=null,this.DefaultSettings_={}}evaluate(A){let B=this.parameterPositions,Q=this._cachedIndex,g=B[Q],v=B[Q-1];Q:{A:{let w;B:{E:if(!(A<g)){for(let f=Q+2;;){if(g===void 0){if(A<v)break E;return Q=B.length,this._cachedIndex=Q,this.copySampleValue_(Q-1)}if(Q===f)break;if(v=g,g=B[++Q],A<g)break A}w=B.length;break B}if(!(A>=v)){let f=B[1];A<f&&(Q=2,v=f);for(let C=Q-2;;){if(v===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(Q===C)break;if(g=v,v=B[--Q-1],A>=v)break A}w=Q,Q=0;break B}break Q}for(;Q<w;){let f=Q+w>>>1;A<B[f]?w=f:Q=f+1}if(g=B[Q],v=B[Q-1],v===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(g===void 0)return Q=B.length,this._cachedIndex=Q,this.copySampleValue_(Q-1)}this._cachedIndex=Q,this.intervalChanged_(Q,v,g)}return this.interpolate_(Q,v,A,g)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(A){let B=this.resultBuffer,Q=this.sampleValues,g=this.valueSize,v=A*g;for(let w=0;w!==g;++w)B[w]=Q[v+w];return B}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},ew=class extends KE{constructor(A,B,Q,g){super(A,B,Q,g),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:yC,endingEnd:yC}}intervalChanged_(A,B,Q){let g=this.parameterPositions,v=A-2,w=A+1,f=g[v],C=g[w];if(f===void 0)switch(this.getSettings_().endingStart){case OC:v=A,f=2*B-Q;break;case NC:v=g.length-2,f=B+g[v]-g[v+1];break;default:v=A,f=Q}if(C===void 0)switch(this.getSettings_().endingEnd){case OC:w=A,C=2*Q-B;break;case NC:w=1,C=Q+g[1]-g[0];break;default:w=A-1,C=B}let e=(Q-B)*.5,P=this.valueSize;this._weightPrev=e/(B-f),this._weightNext=e/(C-Q),this._offsetPrev=v*P,this._offsetNext=w*P}interpolate_(A,B,Q,g){let v=this.resultBuffer,w=this.sampleValues,f=this.valueSize,C=A*f,e=C-f,P=this._offsetPrev,D=this._offsetNext,t=this._weightPrev,n=this._weightNext,s=(Q-B)/(g-B),i=s*s,r=i*s,I=-t*r+2*t*i-t*s,H=(1+t)*r+(-1.5-2*t)*i+(-.5+t)*s+1,o=(-1-n)*r+(1.5+n)*i+.5*s,l=n*r-n*i;for(let F=0;F!==f;++F)v[F]=I*w[P+F]+H*w[e+F]+o*w[C+F]+l*w[D+F];return v}},Pw=class extends KE{constructor(A,B,Q,g){super(A,B,Q,g)}interpolate_(A,B,Q,g){let v=this.resultBuffer,w=this.sampleValues,f=this.valueSize,C=A*f,e=C-f,P=(Q-B)/(g-B),D=1-P;for(let t=0;t!==f;++t)v[t]=w[e+t]*D+w[C+t]*P;return v}},tw=class extends KE{constructor(A,B,Q,g){super(A,B,Q,g)}interpolate_(A){return this.copySampleValue_(A-1)}},$B=class{constructor(A,B,Q,g){if(A===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(B===void 0||B.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+A);this.name=A,this.times=Cv(B,this.TimeBufferType),this.values=Cv(Q,this.ValueBufferType),this.setInterpolation(g||this.DefaultInterpolation)}static toJSON(A){let B=A.constructor,Q;if(B.toJSON!==this.toJSON)Q=B.toJSON(A);else{Q={name:A.name,times:Cv(A.times,Array),values:Cv(A.values,Array)};let g=A.getInterpolation();g!==A.DefaultInterpolation&&(Q.interpolation=g)}return Q.type=A.ValueTypeName,Q}InterpolantFactoryMethodDiscrete(A){return new tw(this.times,this.values,this.getValueSize(),A)}InterpolantFactoryMethodLinear(A){return new Pw(this.times,this.values,this.getValueSize(),A)}InterpolantFactoryMethodSmooth(A){return new ew(this.times,this.values,this.getValueSize(),A)}setInterpolation(A){let B;switch(A){case Pv:B=this.InterpolantFactoryMethodDiscrete;break;case tv:B=this.InterpolantFactoryMethodLinear;break;case nf:B=this.InterpolantFactoryMethodSmooth;break}if(B===void 0){let Q="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(A!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(Q);return console.warn("THREE.KeyframeTrack:",Q),this}return this.createInterpolant=B,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Pv;case this.InterpolantFactoryMethodLinear:return tv;case this.InterpolantFactoryMethodSmooth:return nf}}getValueSize(){return this.values.length/this.times.length}shift(A){if(A!==0){let B=this.times;for(let Q=0,g=B.length;Q!==g;++Q)B[Q]+=A}return this}scale(A){if(A!==1){let B=this.times;for(let Q=0,g=B.length;Q!==g;++Q)B[Q]*=A}return this}trim(A,B){let Q=this.times,g=Q.length,v=0,w=g-1;for(;v!==g&&Q[v]<A;)++v;for(;w!==-1&&Q[w]>B;)--w;if(++w,v!==0||w!==g){v>=w&&(w=Math.max(w,1),v=w-1);let f=this.getValueSize();this.times=Q.slice(v,w),this.values=this.values.slice(v*f,w*f)}return this}validate(){let A=!0,B=this.getValueSize();B-Math.floor(B)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),A=!1);let Q=this.times,g=this.values,v=Q.length;v===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),A=!1);let w=null;for(let f=0;f!==v;f++){let C=Q[f];if(typeof C=="number"&&isNaN(C)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,f,C),A=!1;break}if(w!==null&&w>C){console.error("THREE.KeyframeTrack: Out of order keys.",this,f,C,w),A=!1;break}w=C}if(g!==void 0&&r9(g))for(let f=0,C=g.length;f!==C;++f){let e=g[f];if(isNaN(e)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,f,e),A=!1;break}}return A}optimize(){let A=this.times.slice(),B=this.values.slice(),Q=this.getValueSize(),g=this.getInterpolation()===nf,v=A.length-1,w=1;for(let f=1;f<v;++f){let C=!1,e=A[f],P=A[f+1];if(e!==P&&(f!==1||e!==A[0]))if(g)C=!0;else{let D=f*Q,t=D-Q,n=D+Q;for(let s=0;s!==Q;++s){let i=B[D+s];if(i!==B[t+s]||i!==B[n+s]){C=!0;break}}}if(C){if(f!==w){A[w]=A[f];let D=f*Q,t=w*Q;for(let n=0;n!==Q;++n)B[t+n]=B[D+n]}++w}}if(v>0){A[w]=A[v];for(let f=v*Q,C=w*Q,e=0;e!==Q;++e)B[C+e]=B[f+e];++w}return w!==A.length?(this.times=A.slice(0,w),this.values=B.slice(0,w*Q)):(this.times=A,this.values=B),this}clone(){let A=this.times.slice(),B=this.values.slice(),Q=this.constructor,g=new Q(this.name,A,B);return g.createInterpolant=this.createInterpolant,g}};$B.prototype.TimeBufferType=Float32Array;$B.prototype.ValueBufferType=Float32Array;$B.prototype.DefaultInterpolation=tv;var fE=class extends $B{};fE.prototype.ValueTypeName="bool";fE.prototype.ValueBufferType=Array;fE.prototype.DefaultInterpolation=Pv;fE.prototype.InterpolantFactoryMethodLinear=void 0;fE.prototype.InterpolantFactoryMethodSmooth=void 0;var Dw=class extends $B{};Dw.prototype.ValueTypeName="color";var Iw=class extends $B{};Iw.prototype.ValueTypeName="number";var nw=class extends KE{constructor(A,B,Q,g){super(A,B,Q,g)}interpolate_(A,B,Q,g){let v=this.resultBuffer,w=this.sampleValues,f=this.valueSize,C=(Q-B)/(g-B),e=A*f;for(let P=e+f;e!==P;e+=4)_B.slerpFlat(v,0,w,e-f,w,e,C);return v}},lg=class extends $B{InterpolantFactoryMethodLinear(A){return new nw(this.times,this.values,this.getValueSize(),A)}};lg.prototype.ValueTypeName="quaternion";lg.prototype.DefaultInterpolation=tv;lg.prototype.InterpolantFactoryMethodSmooth=void 0;var wE=class extends $B{};wE.prototype.ValueTypeName="string";wE.prototype.ValueBufferType=Array;wE.prototype.DefaultInterpolation=Pv;wE.prototype.InterpolantFactoryMethodLinear=void 0;wE.prototype.InterpolantFactoryMethodSmooth=void 0;var rw=class extends $B{};rw.prototype.ValueTypeName="vector";var sw=class{constructor(A,B,Q){let g=this,v=!1,w=0,f=0,C,e=[];this.onStart=void 0,this.onLoad=A,this.onProgress=B,this.onError=Q,this.itemStart=function(P){f++,v===!1&&g.onStart!==void 0&&g.onStart(P,w,f),v=!0},this.itemEnd=function(P){w++,g.onProgress!==void 0&&g.onProgress(P,w,f),w===f&&(v=!1,g.onLoad!==void 0&&g.onLoad())},this.itemError=function(P){g.onError!==void 0&&g.onError(P)},this.resolveURL=function(P){return C?C(P):P},this.setURLModifier=function(P){return C=P,this},this.addHandler=function(P,D){return e.push(P,D),this},this.removeHandler=function(P){let D=e.indexOf(P);return D!==-1&&e.splice(D,2),this},this.getHandler=function(P){for(let D=0,t=e.length;D<t;D+=2){let n=e[D],s=e[D+1];if(n.global&&(n.lastIndex=0),n.test(P))return s}return null}}},s9=new sw,iw=class{constructor(A){this.manager=A!==void 0?A:s9,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(A,B){let Q=this;return new Promise(function(g,v){Q.load(A,g,B,v)})}parse(){}setCrossOrigin(A){return this.crossOrigin=A,this}setWithCredentials(A){return this.withCredentials=A,this}setPath(A){return this.path=A,this}setResourcePath(A){return this.resourcePath=A,this}setRequestHeader(A){return this.requestHeader=A,this}};iw.DEFAULT_MATERIAL_NAME="__DEFAULT";var Fv=class extends iB{constructor(A,B=1){super(),this.isLight=!0,this.type="Light",this.color=new lA(A),this.intensity=B}dispose(){}copy(A,B){return super.copy(A,B),this.color.copy(A.color),this.intensity=A.intensity,this}toJSON(A){let B=super.toJSON(A);return B.object.color=this.color.getHex(),B.object.intensity=this.intensity,this.groundColor!==void 0&&(B.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(B.object.distance=this.distance),this.angle!==void 0&&(B.object.angle=this.angle),this.decay!==void 0&&(B.object.decay=this.decay),this.penumbra!==void 0&&(B.object.penumbra=this.penumbra),this.shadow!==void 0&&(B.object.shadow=this.shadow.toJSON()),B}};var jf=new fB,G7=new x,L7=new x,Mw=class{constructor(A){this.camera=A,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new hA(512,512),this.map=null,this.mapPass=null,this.matrix=new fB,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new zg,this._frameExtents=new hA(1,1),this._viewportCount=1,this._viewports=[new sB(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(A){let B=this.camera,Q=this.matrix;G7.setFromMatrixPosition(A.matrixWorld),B.position.copy(G7),L7.setFromMatrixPosition(A.target.matrixWorld),B.lookAt(L7),B.updateMatrixWorld(),jf.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),this._frustum.setFromProjectionMatrix(jf),Q.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),Q.multiply(jf)}getViewport(A){return this._viewports[A]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(A){return this.camera=A.camera.clone(),this.bias=A.bias,this.radius=A.radius,this.mapSize.copy(A.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let A={};return this.bias!==0&&(A.bias=this.bias),this.normalBias!==0&&(A.normalBias=this.normalBias),this.radius!==1&&(A.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(A.mapSize=this.mapSize.toArray()),A.camera=this.camera.toJSON(!1).object,delete A.camera.matrix,A}};var ow=class extends Mw{constructor(){super(new lv(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},CE=class extends Fv{constructor(A,B){super(A,B),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(iB.DEFAULT_UP),this.updateMatrix(),this.target=new iB,this.shadow=new ow}dispose(){this.shadow.dispose()}copy(A){return super.copy(A),this.target=A.target.clone(),this.shadow=A.shadow.clone(),this}},xv=class extends Fv{constructor(A,B){super(A,B),this.isAmbientLight=!0,this.type="AmbientLight"}};var hw="\\[\\]\\.:\\/",i9=new RegExp("["+hw+"]","g"),bw="[^"+hw+"]",M9="[^"+hw.replace("\\.","")+"]",o9=/((?:WC+[\/:])*)/.source.replace("WC",bw),c9=/(WCOD+)?/.source.replace("WCOD",M9),a9=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",bw),z9=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",bw),H9=new RegExp("^"+o9+c9+a9+z9+"$"),u9=["material","materials","bones","map"],cw=class{constructor(A,B,Q){let g=Q||EB.parseTrackName(B);this._targetGroup=A,this._bindings=A.subscribe_(B,g)}getValue(A,B){this.bind();let Q=this._targetGroup.nCachedObjects_,g=this._bindings[Q];g!==void 0&&g.getValue(A,B)}setValue(A,B){let Q=this._bindings;for(let g=this._targetGroup.nCachedObjects_,v=Q.length;g!==v;++g)Q[g].setValue(A,B)}bind(){let A=this._bindings;for(let B=this._targetGroup.nCachedObjects_,Q=A.length;B!==Q;++B)A[B].bind()}unbind(){let A=this._bindings;for(let B=this._targetGroup.nCachedObjects_,Q=A.length;B!==Q;++B)A[B].unbind()}},EB=class E{constructor(A,B,Q){this.path=B,this.parsedPath=Q||E.parseTrackName(B),this.node=E.findNode(A,this.parsedPath.nodeName),this.rootNode=A,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(A,B,Q){return A&&A.isAnimationObjectGroup?new E.Composite(A,B,Q):new E(A,B,Q)}static sanitizeNodeName(A){return A.replace(/\s/g,"_").replace(i9,"")}static parseTrackName(A){let B=H9.exec(A);if(B===null)throw new Error("PropertyBinding: Cannot parse trackName: "+A);let Q={nodeName:B[2],objectName:B[3],objectIndex:B[4],propertyName:B[5],propertyIndex:B[6]},g=Q.nodeName&&Q.nodeName.lastIndexOf(".");if(g!==void 0&&g!==-1){let v=Q.nodeName.substring(g+1);u9.indexOf(v)!==-1&&(Q.nodeName=Q.nodeName.substring(0,g),Q.objectName=v)}if(Q.propertyName===null||Q.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+A);return Q}static findNode(A,B){if(B===void 0||B===""||B==="."||B===-1||B===A.name||B===A.uuid)return A;if(A.skeleton){let Q=A.skeleton.getBoneByName(B);if(Q!==void 0)return Q}if(A.children){let Q=function(v){for(let w=0;w<v.length;w++){let f=v[w];if(f.name===B||f.uuid===B)return f;let C=Q(f.children);if(C)return C}return null},g=Q(A.children);if(g)return g}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(A,B){A[B]=this.targetObject[this.propertyName]}_getValue_array(A,B){let Q=this.resolvedProperty;for(let g=0,v=Q.length;g!==v;++g)A[B++]=Q[g]}_getValue_arrayElement(A,B){A[B]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(A,B){this.resolvedProperty.toArray(A,B)}_setValue_direct(A,B){this.targetObject[this.propertyName]=A[B]}_setValue_direct_setNeedsUpdate(A,B){this.targetObject[this.propertyName]=A[B],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(A,B){this.targetObject[this.propertyName]=A[B],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(A,B){let Q=this.resolvedProperty;for(let g=0,v=Q.length;g!==v;++g)Q[g]=A[B++]}_setValue_array_setNeedsUpdate(A,B){let Q=this.resolvedProperty;for(let g=0,v=Q.length;g!==v;++g)Q[g]=A[B++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(A,B){let Q=this.resolvedProperty;for(let g=0,v=Q.length;g!==v;++g)Q[g]=A[B++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(A,B){this.resolvedProperty[this.propertyIndex]=A[B]}_setValue_arrayElement_setNeedsUpdate(A,B){this.resolvedProperty[this.propertyIndex]=A[B],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(A,B){this.resolvedProperty[this.propertyIndex]=A[B],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(A,B){this.resolvedProperty.fromArray(A,B)}_setValue_fromArray_setNeedsUpdate(A,B){this.resolvedProperty.fromArray(A,B),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(A,B){this.resolvedProperty.fromArray(A,B),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(A,B){this.bind(),this.getValue(A,B)}_setValue_unbound(A,B){this.bind(),this.setValue(A,B)}bind(){let A=this.node,B=this.parsedPath,Q=B.objectName,g=B.propertyName,v=B.propertyIndex;if(A||(A=E.findNode(this.rootNode,B.nodeName),this.node=A),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!A){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(Q){let e=B.objectIndex;switch(Q){case"materials":if(!A.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!A.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}A=A.material.materials;break;case"bones":if(!A.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}A=A.skeleton.bones;for(let P=0;P<A.length;P++)if(A[P].name===e){e=P;break}break;case"map":if("map"in A){A=A.map;break}if(!A.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!A.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}A=A.material.map;break;default:if(A[Q]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}A=A[Q]}if(e!==void 0){if(A[e]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,A);return}A=A[e]}}let w=A[g];if(w===void 0){let e=B.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+e+"."+g+" but it wasn't found.",A);return}let f=this.Versioning.None;this.targetObject=A,A.needsUpdate!==void 0?f=this.Versioning.NeedsUpdate:A.matrixWorldNeedsUpdate!==void 0&&(f=this.Versioning.MatrixWorldNeedsUpdate);let C=this.BindingType.Direct;if(v!==void 0){if(g==="morphTargetInfluences"){if(!A.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!A.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}A.morphTargetDictionary[v]!==void 0&&(v=A.morphTargetDictionary[v])}C=this.BindingType.ArrayElement,this.resolvedProperty=w,this.propertyIndex=v}else w.fromArray!==void 0&&w.toArray!==void 0?(C=this.BindingType.HasFromToArray,this.resolvedProperty=w):Array.isArray(w)?(C=this.BindingType.EntireArray,this.resolvedProperty=w):this.propertyName=g;this.getValue=this.GetterByBindingType[C],this.setValue=this.SetterByBindingTypeAndVersioning[C][f]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};EB.Composite=cw;EB.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};EB.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};EB.prototype.GetterByBindingType=[EB.prototype._getValue_direct,EB.prototype._getValue_array,EB.prototype._getValue_arrayElement,EB.prototype._getValue_toArray];EB.prototype.SetterByBindingTypeAndVersioning=[[EB.prototype._setValue_direct,EB.prototype._setValue_direct_setNeedsUpdate,EB.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[EB.prototype._setValue_array,EB.prototype._setValue_array_setNeedsUpdate,EB.prototype._setValue_array_setMatrixWorldNeedsUpdate],[EB.prototype._setValue_arrayElement,EB.prototype._setValue_arrayElement_setNeedsUpdate,EB.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[EB.prototype._setValue_fromArray,EB.prototype._setValue_fromArray_setNeedsUpdate,EB.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var pr=new Float32Array(1);var Gv=class{constructor(A,B,Q=0,g=1/0){this.ray=new gE(A,B),this.near=Q,this.far=g,this.camera=null,this.layers=new cg,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(A,B){this.ray.set(A,B)}setFromCamera(A,B){B.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(B.matrixWorld),this.ray.direction.set(A.x,A.y,.5).unproject(B).sub(this.ray.origin).normalize(),this.camera=B):B.isOrthographicCamera?(this.ray.origin.set(A.x,A.y,(B.near+B.far)/(B.near-B.far)).unproject(B),this.ray.direction.set(0,0,-1).transformDirection(B.matrixWorld),this.camera=B):console.error("THREE.Raycaster: Unsupported camera type: "+B.type)}intersectObject(A,B=!0,Q=[]){return aw(A,this,Q,B),Q.sort(U7),Q}intersectObjects(A,B=!0,Q=[]){for(let g=0,v=A.length;g<v;g++)aw(A[g],this,Q,B);return Q.sort(U7),Q}};function U7(E,A){return E.distance-A.distance}function aw(E,A,B,Q){if(E.layers.test(A.layers)&&E.raycast(A,B),Q===!0){let g=E.children;for(let v=0,w=g.length;v<w;v++)aw(g[v],A,B,!0)}}var hg=class{constructor(A=1,B=0,Q=0){return this.radius=A,this.phi=B,this.theta=Q,this}set(A,B,Q){return this.radius=A,this.phi=B,this.theta=Q,this}copy(A){return this.radius=A.radius,this.phi=A.phi,this.theta=A.theta,this}makeSafe(){return this.phi=Math.max(1e-6,Math.min(Math.PI-1e-6,this.phi)),this}setFromVector3(A){return this.setFromCartesianCoords(A.x,A.y,A.z)}setFromCartesianCoords(A,B,Q){return this.radius=Math.sqrt(A*A+B*B+Q*Q),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(A,Q),this.phi=Math.acos(aB(B/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"160"}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="160");var ve={type:"change"},mw={type:"start"},fe={type:"end"},Yv=new gE,we=new pB,l9=Math.cos(70*W7.DEG2RAD),Tv=class extends fQ{constructor(A,B){super(),this.object=A,this.domElement=B,this.domElement.style.touchAction="none",this.enabled=!0,this.target=new x,this.cursor=new x,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:eE.ROTATE,MIDDLE:eE.DOLLY,RIGHT:eE.PAN},this.touches={ONE:PE.ROTATE,TWO:PE.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this.getPolarAngle=function(){return f.phi},this.getAzimuthalAngle=function(){return f.theta},this.getDistance=function(){return this.object.position.distanceTo(this.target)},this.listenToKeyEvents=function(d){d.addEventListener("keydown",AA),this._domElementKeyEvents=d},this.stopListenToKeyEvents=function(){this._domElementKeyEvents.removeEventListener("keydown",AA),this._domElementKeyEvents=null},this.saveState=function(){Q.target0.copy(Q.target),Q.position0.copy(Q.object.position),Q.zoom0=Q.object.zoom},this.reset=function(){Q.target.copy(Q.target0),Q.object.position.copy(Q.position0),Q.object.zoom=Q.zoom0,Q.object.updateProjectionMatrix(),Q.dispatchEvent(ve),Q.update(),v=g.NONE},this.update=(function(){let d=new x,J=new _B().setFromUnitVectors(A.up,new x(0,1,0)),wA=J.clone().invert(),QA=new x,iA=new _B,yA=new x,kA=2*Math.PI;return function(fA=null){let m=Q.object.position;d.copy(m).sub(Q.target),d.applyQuaternion(J),f.setFromVector3(d),Q.autoRotate&&v===g.NONE&&y(a(fA)),Q.enableDamping?(f.theta+=C.theta*Q.dampingFactor,f.phi+=C.phi*Q.dampingFactor):(f.theta+=C.theta,f.phi+=C.phi);let gA=Q.minAzimuthAngle,vA=Q.maxAzimuthAngle;isFinite(gA)&&isFinite(vA)&&(gA<-Math.PI?gA+=kA:gA>Math.PI&&(gA-=kA),vA<-Math.PI?vA+=kA:vA>Math.PI&&(vA-=kA),gA<=vA?f.theta=Math.max(gA,Math.min(vA,f.theta)):f.theta=f.theta>(gA+vA)/2?Math.max(gA,f.theta):Math.min(vA,f.theta)),f.phi=Math.max(Q.minPolarAngle,Math.min(Q.maxPolarAngle,f.phi)),f.makeSafe(),Q.enableDamping===!0?Q.target.addScaledVector(P,Q.dampingFactor):Q.target.add(P),Q.target.sub(Q.cursor),Q.target.clampLength(Q.minTargetRadius,Q.maxTargetRadius),Q.target.add(Q.cursor),Q.zoomToCursor&&b||Q.object.isOrthographicCamera?f.radius=R(f.radius):f.radius=R(f.radius*e),d.setFromSpherical(f),d.applyQuaternion(wA),m.copy(Q.target).add(d),Q.object.lookAt(Q.target),Q.enableDamping===!0?(C.theta*=1-Q.dampingFactor,C.phi*=1-Q.dampingFactor,P.multiplyScalar(1-Q.dampingFactor)):(C.set(0,0,0),P.set(0,0,0));let zA=!1;if(Q.zoomToCursor&&b){let oA=null;if(Q.object.isPerspectiveCamera){let JA=d.length();oA=R(JA*e);let WA=JA-oA;Q.object.position.addScaledVector(l,WA),Q.object.updateMatrixWorld()}else if(Q.object.isOrthographicCamera){let JA=new x(F.x,F.y,0);JA.unproject(Q.object),Q.object.zoom=Math.max(Q.minZoom,Math.min(Q.maxZoom,Q.object.zoom/e)),Q.object.updateProjectionMatrix(),zA=!0;let WA=new x(F.x,F.y,0);WA.unproject(Q.object),Q.object.position.sub(WA).add(JA),Q.object.updateMatrixWorld(),oA=d.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),Q.zoomToCursor=!1;oA!==null&&(this.screenSpacePanning?Q.target.set(0,0,-1).transformDirection(Q.object.matrix).multiplyScalar(oA).add(Q.object.position):(Yv.origin.copy(Q.object.position),Yv.direction.set(0,0,-1).transformDirection(Q.object.matrix),Math.abs(Q.object.up.dot(Yv.direction))<l9?A.lookAt(Q.target):(we.setFromNormalAndCoplanarPoint(Q.object.up,Q.target),Yv.intersectPlane(we,Q.target))))}else Q.object.isOrthographicCamera&&(Q.object.zoom=Math.max(Q.minZoom,Math.min(Q.maxZoom,Q.object.zoom/e)),Q.object.updateProjectionMatrix(),zA=!0);return e=1,b=!1,zA||QA.distanceToSquared(Q.object.position)>w||8*(1-iA.dot(Q.object.quaternion))>w||yA.distanceToSquared(Q.target)>0?(Q.dispatchEvent(ve),QA.copy(Q.object.position),iA.copy(Q.object.quaternion),yA.copy(Q.target),!0):!1}})(),this.dispose=function(){Q.domElement.removeEventListener("contextmenu",IA),Q.domElement.removeEventListener("pointerdown",xA),Q.domElement.removeEventListener("pointercancel",M),Q.domElement.removeEventListener("wheel",_),Q.domElement.removeEventListener("pointermove",z),Q.domElement.removeEventListener("pointerup",M),Q._domElementKeyEvents!==null&&(Q._domElementKeyEvents.removeEventListener("keydown",AA),Q._domElementKeyEvents=null)};let Q=this,g={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},v=g.NONE,w=1e-6,f=new hg,C=new hg,e=1,P=new x,D=new hA,t=new hA,n=new hA,s=new hA,i=new hA,r=new hA,I=new hA,H=new hA,o=new hA,l=new x,F=new hA,b=!1,h=[],Z={};function a(d){return d!==null?2*Math.PI/60*Q.autoRotateSpeed*d:2*Math.PI/60/60*Q.autoRotateSpeed}function u(d){let J=Math.abs(d)/(100*(window.devicePixelRatio|0));return Math.pow(.95,Q.zoomSpeed*J)}function y(d){C.theta-=d}function q(d){C.phi-=d}let EA=(function(){let d=new x;return function(wA,QA){d.setFromMatrixColumn(QA,0),d.multiplyScalar(-wA),P.add(d)}})(),p=(function(){let d=new x;return function(wA,QA){Q.screenSpacePanning===!0?d.setFromMatrixColumn(QA,1):(d.setFromMatrixColumn(QA,0),d.crossVectors(Q.object.up,d)),d.multiplyScalar(wA),P.add(d)}})(),L=(function(){let d=new x;return function(wA,QA){let iA=Q.domElement;if(Q.object.isPerspectiveCamera){let yA=Q.object.position;d.copy(yA).sub(Q.target);let kA=d.length();kA*=Math.tan(Q.object.fov/2*Math.PI/180),EA(2*wA*kA/iA.clientHeight,Q.object.matrix),p(2*QA*kA/iA.clientHeight,Q.object.matrix)}else Q.object.isOrthographicCamera?(EA(wA*(Q.object.right-Q.object.left)/Q.object.zoom/iA.clientWidth,Q.object.matrix),p(QA*(Q.object.top-Q.object.bottom)/Q.object.zoom/iA.clientHeight,Q.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),Q.enablePan=!1)}})();function N(d){Q.object.isPerspectiveCamera||Q.object.isOrthographicCamera?e/=d:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),Q.enableZoom=!1)}function k(d){Q.object.isPerspectiveCamera||Q.object.isOrthographicCamera?e*=d:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),Q.enableZoom=!1)}function V(d,J){if(!Q.zoomToCursor)return;b=!0;let wA=Q.domElement.getBoundingClientRect(),QA=d-wA.left,iA=J-wA.top,yA=wA.width,kA=wA.height;F.x=QA/yA*2-1,F.y=-(iA/kA)*2+1,l.set(F.x,F.y,1).unproject(Q.object).sub(Q.object.position).normalize()}function R(d){return Math.max(Q.minDistance,Math.min(Q.maxDistance,d))}function W(d){D.set(d.clientX,d.clientY)}function $(d){V(d.clientX,d.clientX),I.set(d.clientX,d.clientY)}function eA(d){s.set(d.clientX,d.clientY)}function O(d){t.set(d.clientX,d.clientY),n.subVectors(t,D).multiplyScalar(Q.rotateSpeed);let J=Q.domElement;y(2*Math.PI*n.x/J.clientHeight),q(2*Math.PI*n.y/J.clientHeight),D.copy(t),Q.update()}function S(d){H.set(d.clientX,d.clientY),o.subVectors(H,I),o.y>0?N(u(o.y)):o.y<0&&k(u(o.y)),I.copy(H),Q.update()}function tA(d){i.set(d.clientX,d.clientY),r.subVectors(i,s).multiplyScalar(Q.panSpeed),L(r.x,r.y),s.copy(i),Q.update()}function MA(d){V(d.clientX,d.clientY),d.deltaY<0?k(u(d.deltaY)):d.deltaY>0&&N(u(d.deltaY)),Q.update()}function sA(d){let J=!1;switch(d.code){case Q.keys.UP:d.ctrlKey||d.metaKey||d.shiftKey?q(2*Math.PI*Q.rotateSpeed/Q.domElement.clientHeight):L(0,Q.keyPanSpeed),J=!0;break;case Q.keys.BOTTOM:d.ctrlKey||d.metaKey||d.shiftKey?q(-2*Math.PI*Q.rotateSpeed/Q.domElement.clientHeight):L(0,-Q.keyPanSpeed),J=!0;break;case Q.keys.LEFT:d.ctrlKey||d.metaKey||d.shiftKey?y(2*Math.PI*Q.rotateSpeed/Q.domElement.clientHeight):L(Q.keyPanSpeed,0),J=!0;break;case Q.keys.RIGHT:d.ctrlKey||d.metaKey||d.shiftKey?y(-2*Math.PI*Q.rotateSpeed/Q.domElement.clientHeight):L(-Q.keyPanSpeed,0),J=!0;break}J&&(d.preventDefault(),Q.update())}function pA(d){if(h.length===1)D.set(d.pageX,d.pageY);else{let J=VA(d),wA=.5*(d.pageX+J.x),QA=.5*(d.pageY+J.y);D.set(wA,QA)}}function FA(d){if(h.length===1)s.set(d.pageX,d.pageY);else{let J=VA(d),wA=.5*(d.pageX+J.x),QA=.5*(d.pageY+J.y);s.set(wA,QA)}}function HA(d){let J=VA(d),wA=d.pageX-J.x,QA=d.pageY-J.y,iA=Math.sqrt(wA*wA+QA*QA);I.set(0,iA)}function ZA(d){Q.enableZoom&&HA(d),Q.enablePan&&FA(d)}function U(d){Q.enableZoom&&HA(d),Q.enableRotate&&pA(d)}function DB(d){if(h.length==1)t.set(d.pageX,d.pageY);else{let wA=VA(d),QA=.5*(d.pageX+wA.x),iA=.5*(d.pageY+wA.y);t.set(QA,iA)}n.subVectors(t,D).multiplyScalar(Q.rotateSpeed);let J=Q.domElement;y(2*Math.PI*n.x/J.clientHeight),q(2*Math.PI*n.y/J.clientHeight),D.copy(t)}function aA(d){if(h.length===1)i.set(d.pageX,d.pageY);else{let J=VA(d),wA=.5*(d.pageX+J.x),QA=.5*(d.pageY+J.y);i.set(wA,QA)}r.subVectors(i,s).multiplyScalar(Q.panSpeed),L(r.x,r.y),s.copy(i)}function bA(d){let J=VA(d),wA=d.pageX-J.x,QA=d.pageY-J.y,iA=Math.sqrt(wA*wA+QA*QA);H.set(0,iA),o.set(0,Math.pow(H.y/I.y,Q.zoomSpeed)),N(o.y),I.copy(H);let yA=(d.pageX+J.x)*.5,kA=(d.pageY+J.y)*.5;V(yA,kA)}function nA(d){Q.enableZoom&&bA(d),Q.enablePan&&aA(d)}function BB(d){Q.enableZoom&&bA(d),Q.enableRotate&&DB(d)}function xA(d){Q.enabled!==!1&&(h.length===0&&(Q.domElement.setPointerCapture(d.pointerId),Q.domElement.addEventListener("pointermove",z),Q.domElement.addEventListener("pointerup",M)),uA(d),d.pointerType==="touch"?rA(d):X(d))}function z(d){Q.enabled!==!1&&(d.pointerType==="touch"?PA(d):BA(d))}function M(d){LA(d),h.length===0&&(Q.domElement.releasePointerCapture(d.pointerId),Q.domElement.removeEventListener("pointermove",z),Q.domElement.removeEventListener("pointerup",M)),Q.dispatchEvent(fe),v=g.NONE}function X(d){let J;switch(d.button){case 0:J=Q.mouseButtons.LEFT;break;case 1:J=Q.mouseButtons.MIDDLE;break;case 2:J=Q.mouseButtons.RIGHT;break;default:J=-1}switch(J){case eE.DOLLY:if(Q.enableZoom===!1)return;$(d),v=g.DOLLY;break;case eE.ROTATE:if(d.ctrlKey||d.metaKey||d.shiftKey){if(Q.enablePan===!1)return;eA(d),v=g.PAN}else{if(Q.enableRotate===!1)return;W(d),v=g.ROTATE}break;case eE.PAN:if(d.ctrlKey||d.metaKey||d.shiftKey){if(Q.enableRotate===!1)return;W(d),v=g.ROTATE}else{if(Q.enablePan===!1)return;eA(d),v=g.PAN}break;default:v=g.NONE}v!==g.NONE&&Q.dispatchEvent(mw)}function BA(d){switch(v){case g.ROTATE:if(Q.enableRotate===!1)return;O(d);break;case g.DOLLY:if(Q.enableZoom===!1)return;S(d);break;case g.PAN:if(Q.enablePan===!1)return;tA(d);break}}function _(d){Q.enabled===!1||Q.enableZoom===!1||v!==g.NONE||(d.preventDefault(),Q.dispatchEvent(mw),MA(d),Q.dispatchEvent(fe))}function AA(d){Q.enabled===!1||Q.enablePan===!1||sA(d)}function rA(d){switch(K(d),h.length){case 1:switch(Q.touches.ONE){case PE.ROTATE:if(Q.enableRotate===!1)return;pA(d),v=g.TOUCH_ROTATE;break;case PE.PAN:if(Q.enablePan===!1)return;FA(d),v=g.TOUCH_PAN;break;default:v=g.NONE}break;case 2:switch(Q.touches.TWO){case PE.DOLLY_PAN:if(Q.enableZoom===!1&&Q.enablePan===!1)return;ZA(d),v=g.TOUCH_DOLLY_PAN;break;case PE.DOLLY_ROTATE:if(Q.enableZoom===!1&&Q.enableRotate===!1)return;U(d),v=g.TOUCH_DOLLY_ROTATE;break;default:v=g.NONE}break;default:v=g.NONE}v!==g.NONE&&Q.dispatchEvent(mw)}function PA(d){switch(K(d),v){case g.TOUCH_ROTATE:if(Q.enableRotate===!1)return;DB(d),Q.update();break;case g.TOUCH_PAN:if(Q.enablePan===!1)return;aA(d),Q.update();break;case g.TOUCH_DOLLY_PAN:if(Q.enableZoom===!1&&Q.enablePan===!1)return;nA(d),Q.update();break;case g.TOUCH_DOLLY_ROTATE:if(Q.enableZoom===!1&&Q.enableRotate===!1)return;BB(d),Q.update();break;default:v=g.NONE}}function IA(d){Q.enabled!==!1&&d.preventDefault()}function uA(d){h.push(d.pointerId)}function LA(d){delete Z[d.pointerId];for(let J=0;J<h.length;J++)if(h[J]==d.pointerId){h.splice(J,1);return}}function K(d){let J=Z[d.pointerId];J===void 0&&(J=new hA,Z[d.pointerId]=J),J.set(d.pageX,d.pageY)}function VA(d){let J=d.pointerId===h[0]?h[1]:h[0];return Z[J]}Q.domElement.addEventListener("contextmenu",IA),Q.domElement.addEventListener("pointerdown",xA),Q.domElement.addEventListener("pointercancel",M),Q.domElement.addEventListener("wheel",_,{passive:!1}),this.update()}};var Bg=class extends iB{constructor(A=document.createElement("div")){super(),this.isCSS2DObject=!0,this.element=A,this.element.style.position="absolute",this.element.style.userSelect="none",this.element.setAttribute("draggable",!1),this.center=new hA(.5,.5),this.addEventListener("removed",function(){this.traverse(function(B){B.element instanceof Element&&B.element.parentNode!==null&&B.element.parentNode.removeChild(B.element)})})}copy(A,B){return super.copy(A,B),this.element=A.element.cloneNode(!0),this.center=A.center,this}},Ag=new x,Ce=new fB,ee=new fB,Pe=new x,te=new x,jv=class{constructor(A={}){let B=this,Q,g,v,w,f={objects:new WeakMap},C=A.element!==void 0?A.element:document.createElement("div");C.style.overflow="hidden",this.domElement=C,this.getSize=function(){return{width:Q,height:g}},this.render=function(n,s){n.matrixWorldAutoUpdate===!0&&n.updateMatrixWorld(),s.parent===null&&s.matrixWorldAutoUpdate===!0&&s.updateMatrixWorld(),Ce.copy(s.matrixWorldInverse),ee.multiplyMatrices(s.projectionMatrix,Ce),e(n,n,s),t(n)},this.setSize=function(n,s){Q=n,g=s,v=Q/2,w=g/2,C.style.width=n+"px",C.style.height=s+"px"};function e(n,s,i){if(n.isCSS2DObject){Ag.setFromMatrixPosition(n.matrixWorld),Ag.applyMatrix4(ee);let r=n.visible===!0&&Ag.z>=-1&&Ag.z<=1&&n.layers.test(i.layers)===!0;if(n.element.style.display=r===!0?"":"none",r===!0){n.onBeforeRender(B,s,i);let H=n.element;H.style.transform="translate("+-100*n.center.x+"%,"+-100*n.center.y+"%)translate("+(Ag.x*v+v)+"px,"+(-Ag.y*w+w)+"px)",H.parentNode!==C&&C.appendChild(H),n.onAfterRender(B,s,i)}let I={distanceToCameraSquared:P(i,n)};f.objects.set(n,I)}for(let r=0,I=n.children.length;r<I;r++)e(n.children[r],s,i)}function P(n,s){return Pe.setFromMatrixPosition(n.matrixWorld),te.setFromMatrixPosition(s.matrixWorld),Pe.distanceToSquared(te)}function D(n){let s=[];return n.traverse(function(i){i.isCSS2DObject&&s.push(i)}),s}function t(n){let s=D(n).sort(function(r,I){if(r.renderOrder!==I.renderOrder)return I.renderOrder-r.renderOrder;let H=f.objects.get(r).distanceToCameraSquared,o=f.objects.get(I).distanceToCameraSquared;return H-o}),i=s.length;for(let r=0,I=s.length;r<I;r++)s[r].element.style.zIndex=i-r}}};var ue="2.0 \u6559\u5B66\u7248",h9="2026-09-14 16:20";document.querySelector("#version-info .version-num").textContent="V"+ue;document.getElementById("version-time").textContent=h9;var b9=document.getElementById("copyright-info"),Rw=document.getElementById("copyright-modal"),m9=document.getElementById("modal-overlay"),p9=document.getElementById("modal-close"),F9=document.getElementById("modal-btn-close");function x9(){Rw.classList.add("show"),document.body.style.overflow="hidden"}function $v(){Rw.classList.remove("show"),document.body.style.overflow=""}b9.addEventListener("click",x9);m9.addEventListener("click",$v);p9.addEventListener("click",$v);F9.addEventListener("click",$v);document.addEventListener("keydown",E=>{E.key==="Escape"&&Rw.classList.contains("show")&&$v()});var Af={classic:{name:"\u7ECF\u5178\u5730\u5F62",stops:[{pos:0,color:[45,138,78]},{pos:.25,color:[140,179,105]},{pos:.5,color:[212,167,106]},{pos:.75,color:[181,119,74]},{pos:1,color:[138,110,90]}]},terrace:{name:"\u4E09\u7EA7\u9636\u68AF",stepped:!0,stops:[{pos:0,color:[63,148,96]},{pos:.451,color:[63,148,96]},{pos:.451,color:[200,190,110]},{pos:.725,color:[200,190,110]},{pos:.725,color:[178,120,90]},{pos:1,color:[178,120,90]}]}};function G9(E,A,B=2){let Q=(E+180)/360,g=(90-A)/180,v=(Q-.5)*2*B,w=(g-.5)*2;return{x:v,z:w}}var L9=[{name:"\u4E9A\u6D32",lon:100,lat:35},{name:"\u975E\u6D32",lon:20,lat:5},{name:"\u5317\u7F8E\u6D32",lon:-100,lat:45},{name:"\u5357\u7F8E\u6D32",lon:-60,lat:-15},{name:"\u5357\u6781\u6D32",lon:0,lat:-80},{name:"\u6B27\u6D32",lon:15,lat:50},{name:"\u5927\u6D0B\u6D32",lon:135,lat:-25}],U9=[{name:"\u592A\u5E73\u6D0B",lon:-160,lat:0},{name:"\u5927\u897F\u6D0B",lon:-30,lat:0},{name:"\u5370\u5EA6\u6D0B",lon:80,lat:-10},{name:"\u5317\u51B0\u6D0B",lon:0,lat:85}],oE=[{name:"\u5317\u4EAC\u5E02",pinyin:"beijing",centerLon:116.4,centerLat:39.9,minLon:115.7,maxLon:117.4,minLat:39.4,maxLat:41},{name:"\u5929\u6D25\u5E02",pinyin:"tianjin",centerLon:117.2,centerLat:39.1,minLon:116.7,maxLon:118.1,minLat:38.5,maxLat:40.2},{name:"\u4E0A\u6D77\u5E02",pinyin:"shanghai",centerLon:121.5,centerLat:31.2,minLon:120.8,maxLon:122,minLat:30.7,maxLat:31.9},{name:"\u91CD\u5E86\u5E02",pinyin:"chongqing",centerLon:106.5,centerLat:29.5,minLon:105.3,maxLon:110.2,minLat:28.1,maxLat:32.2},{name:"\u5E7F\u4E1C\u7701",pinyin:"guangdong",centerLon:113.3,centerLat:23.1,minLon:109.5,maxLon:117.2,minLat:20.2,maxLat:25.5},{name:"\u5E7F\u897F\u58EE\u65CF\u81EA\u6CBB\u533A",pinyin:"guangxi",centerLon:108.4,centerLat:22.8,minLon:104.5,maxLon:112,minLat:20.9,maxLat:26.4},{name:"\u6D77\u5357\u7701",pinyin:"hainan",centerLon:110,centerLat:19.2,minLon:108.6,maxLon:110,minLat:18.2,maxLat:20.2},{name:"\u798F\u5EFA\u7701",pinyin:"fujian",centerLon:119.3,centerLat:26.1,minLon:115.8,maxLon:120.4,minLat:23.6,maxLat:28.3},{name:"\u6C5F\u897F\u7701",pinyin:"jiangxi",centerLon:115.9,centerLat:27.6,minLon:113.6,maxLon:118.4,minLat:24.4,maxLat:30.1},{name:"\u6E56\u5357\u7701",pinyin:"hunan",centerLon:112,centerLat:27.1,minLon:108.9,maxLon:114.2,minLat:24.6,maxLat:30.1},{name:"\u6E56\u5317\u7701",pinyin:"hubei",centerLon:112.4,centerLat:30.6,minLon:108.4,maxLon:116.1,minLat:29,maxLat:33.3},{name:"\u6CB3\u5357\u7701",pinyin:"henan",centerLon:113.7,centerLat:33.8,minLon:110.3,maxLon:116.6,minLat:31.3,maxLat:36.3},{name:"\u6CB3\u5317\u7701",pinyin:"hebei",centerLon:114.5,centerLat:38,minLon:113.6,maxLon:119.5,minLat:36,maxLat:42.6},{name:"\u5C71\u897F\u7701",pinyin:"shanxi",centerLon:112.5,centerLat:37.8,minLon:110.2,maxLon:114.5,minLat:34.6,maxLat:40.7},{name:"\u5C71\u4E1C\u7701",pinyin:"shandong",centerLon:120.3,centerLat:36.1,minLon:114.8,maxLon:122.7,minLat:34.3,maxLat:38.4},{name:"\u6C5F\u82CF\u7701",pinyin:"jiangsu",centerLon:119.8,centerLat:33,minLon:116.3,maxLon:121.8,minLat:30.6,maxLat:35.1},{name:"\u6D59\u6C5F\u7701",pinyin:"zhejiang",centerLon:120.2,centerLat:29.2,minLon:118,maxLon:123,minLat:27,maxLat:31},{name:"\u5B89\u5FBD\u7701",pinyin:"anhui",centerLon:117.3,centerLat:31.8,minLon:114.9,maxLon:119.6,minLat:29.4,maxLat:34.6},{name:"\u8FBD\u5B81\u7701",pinyin:"liaoning",centerLon:123.4,centerLat:41.8,minLon:118.8,maxLon:125.8,minLat:38.7,maxLat:43.3},{name:"\u5409\u6797\u7701",pinyin:"jilin",centerLon:125.3,centerLat:43.9,minLon:121.6,maxLon:131.3,minLat:40.9,maxLat:46.3},{name:"\u9ED1\u9F99\u6C5F\u7701",pinyin:"heilongjiang",centerLon:126.6,centerLat:47.8,minLon:121.5,maxLon:135.1,minLat:43.3,maxLat:53.5},{name:"\u5185\u8499\u53E4\u81EA\u6CBB\u533A",pinyin:"neimenggu",centerLon:111.8,centerLat:44.7,minLon:97.2,maxLon:126,minLat:37.4,maxLat:53.4},{name:"\u65B0\u7586\u7EF4\u543E\u5C14\u81EA\u6CBB\u533A",pinyin:"xinjiang",centerLon:85.6,centerLat:42.5,minLon:73.4,maxLon:96.4,minLat:34.2,maxLat:49.1},{name:"\u897F\u85CF\u81EA\u6CBB\u533A",pinyin:"xizang",centerLon:89.1,centerLat:31.5,minLon:78.2,maxLon:99.1,minLat:26.8,maxLat:36.5},{name:"\u9752\u6D77\u7701",pinyin:"qinghai",centerLon:96,centerLat:35.5,minLon:89.3,maxLon:103,minLat:31.4,maxLat:39.2},{name:"\u7518\u8083\u7701",pinyin:"gansu",centerLon:103.8,centerLat:37.5,minLon:92.2,maxLon:108.7,minLat:32.6,maxLat:42.9},{name:"\u5B81\u590F\u56DE\u65CF\u81EA\u6CBB\u533A",pinyin:"ningxia",centerLon:106.3,centerLat:37.5,minLon:104.3,maxLon:107.4,minLat:35.2,maxLat:39.2},{name:"\u9655\u897F\u7701",pinyin:"shaanxi",centerLon:109,centerLat:35.5,minLon:105.5,maxLon:111,minLat:31.7,maxLat:39.6},{name:"\u56DB\u5DDD\u7701",pinyin:"sichuan",centerLon:102.2,centerLat:30.6,minLon:97.3,maxLon:108.5,minLat:26,maxLat:34.3},{name:"\u8D35\u5DDE\u7701",pinyin:"guizhou",centerLon:106.7,centerLat:26.6,minLon:103.6,maxLon:109.6,minLat:24.3,maxLat:29.1},{name:"\u4E91\u5357\u7701",pinyin:"yunnan",centerLon:101.8,centerLat:24.8,minLon:97.3,maxLon:106.2,minLat:21.1,maxLat:29.1},{name:"\u53F0\u6E7E\u7701",pinyin:"taiwan",centerLon:121,centerLat:24,minLon:119.3,maxLon:122,minLat:21.9,maxLat:25.3},{name:"\u9999\u6E2F\u7279\u522B\u884C\u653F\u533A",pinyin:"xianggang",centerLon:114.2,centerLat:22.3,minLon:113.8,maxLon:114.4,minLat:22.2,maxLat:22.6},{name:"\u6FB3\u95E8\u7279\u522B\u884C\u653F\u533A",pinyin:"aomen",centerLon:113.5,centerLat:22.2,minLon:113.5,maxLon:113.6,minLat:22.1,maxLat:22.2}],NQ=document.getElementById("upload-panel"),De=document.getElementById("file-input"),Ie=document.getElementById("geojson-input"),pw=document.getElementById("status-msg"),nE=document.getElementById("controls-panel"),rE=document.getElementById("toggle-panel-btn"),X9=document.getElementById("collapse-panel-btn"),Yr=document.getElementById("panel-body"),Y9=document.getElementById("stats-display"),Fw=document.getElementById("zoom-indicator"),de=document.getElementById("interact-hint"),Yw=document.getElementById("lod-status"),Ov=document.getElementById("lod-text"),le=document.getElementById("label-mode-indicator"),Ug=document.getElementById("bias-slider"),Xg=document.getElementById("scale-slider"),Eg=document.getElementById("threshold-slider"),Vv=document.getElementById("speed-slider"),eQ=document.getElementById("seg-slider"),mg=document.getElementById("lod-threshold-slider"),T9=document.getElementById("bias-value"),j9=document.getElementById("scale-value"),he=document.getElementById("threshold-value"),y9=document.getElementById("speed-value"),be=document.getElementById("seg-value"),me=document.getElementById("lod-threshold-value"),gg=document.getElementById("invert-toggle"),pe=document.getElementById("invert-status"),Fe=document.getElementById("scheme-display"),xw=document.querySelectorAll(".scheme-btn"),xe=document.querySelectorAll(".bg-btn"),IE=document.querySelectorAll('#custom-colors input[type="color"]'),O9=document.getElementById("custom-preview"),Tw=document.getElementById("rotate-left"),jw=document.getElementById("rotate-stop"),yw=document.getElementById("rotate-right"),N9=document.getElementById("btn-reset-view"),R9=document.getElementById("btn-top-view"),Z9=document.getElementById("btn-fit-view"),Zw=document.getElementById("toggle-label-btn"),Ge=document.getElementById("label-status-text"),ne=document.getElementById("world-label-size-slider"),V9=document.getElementById("world-label-size-value"),k9=document.getElementById("btn-world"),q9=document.getElementById("btn-china"),wQ=!1;function Le(){wQ=!wQ,Zw.classList.toggle("active",wQ),Ge.textContent=wQ?"\u5F00\u542F":"\u5173\u95ED",le.classList.toggle("show",wQ);let E=de.querySelector(".label-hint");E&&(E.style.opacity=wQ?"1":"0.3",E.style.color=wQ?"#e67e22":""),RA(wQ?"\u{1F3F7}\uFE0F \u6807\u6CE8\u6A21\u5F0F\u5DF2\u5F00\u542F\uFF0C\u53CC\u51FB\u5730\u5F62\u6DFB\u52A0\u6807\u6CE8":"\u{1F3F7}\uFE0F \u6807\u6CE8\u6A21\u5F0F\u5DF2\u5173\u95ED")}Zw.addEventListener("click",Le);document.addEventListener("keydown",E=>{if(E.key==="l"||E.key==="L"){if(E.target.tagName==="INPUT"||E.target.tagName==="TEXTAREA")return;E.preventDefault(),Le()}});var SA=new mv;SA.background=new lA(16119285);var VB=new mB(40,window.innerWidth/window.innerHeight,.01,100);VB.position.set(0,1.2,2.8);var kB=new ug({antialias:!0,alpha:!1});kB.setSize(window.innerWidth,window.innerHeight);kB.setPixelRatio(Math.min(window.devicePixelRatio,2));kB.toneMapping=zw;kB.toneMappingExposure=1;document.body.appendChild(kB.domElement);var ZQ=new jv;ZQ.setSize(window.innerWidth,window.innerHeight);ZQ.domElement.style.position="absolute";ZQ.domElement.style.top="0px";ZQ.domElement.style.left="0px";ZQ.domElement.style.pointerEvents="none";document.body.appendChild(ZQ.domElement);var qA=new Tv(VB,kB.domElement);qA.enableDamping=!0;qA.dampingFactor=.1;qA.autoRotate=!1;qA.autoRotateSpeed=.5;qA.enablePan=!0;qA.panSpeed=.8;qA.zoomToCursor=!0;qA.minDistance=.05;qA.maxDistance=30;qA.maxPolarAngle=Math.PI/2;qA.minPolarAngle=0;qA.target.set(0,0,0);qA.update();var pg=[],J9=0,kv=[],Gw={fontSize:"14px",color:"#ffffff",bgColor:"rgba(0,0,0,0.7)",bgOpacity:.7};function W9(E,A){let B=document.createElement("div");B.className="user-label",B.textContent=A,B.style.color=Gw.color,B.style.fontSize=Gw.fontSize,B.style.background=Gw.bgColor,B.addEventListener("mouseenter",()=>{B.style.transform="scale(1.05)",B.style.boxShadow="0 4px 20px rgba(0,0,0,0.4)"}),B.addEventListener("mouseleave",()=>{B.style.transform="scale(1)",B.style.boxShadow="0 2px 12px rgba(0,0,0,0.3)"}),B.addEventListener("dblclick",g=>{g.stopPropagation();let v=Q.userData.id;S9(v),RA(`\u{1F5D1}\uFE0F \u5DF2\u5220\u9664\u6807\u6CE8: "${A}"`)});let Q=new Bg(B);return Q.position.copy(E),Q.userData.id=J9++,Q.userData.text=A,Q.userData.type="user",SA.add(Q),pg.push(Q),Q}function S9(E){let A=pg.findIndex(B=>B.userData.id===E);return A!==-1?(SA.remove(pg[A]),pg.splice(A,1),!0):!1}var Ue=16;function re(E,A,B,Q,g=2){let v=G9(A,B,g),w=new x(v.x,0,v.z),f=document.createElement("div");f.className=`world-label ${Q}`,f.textContent=E,f.style.fontSize=Ue+"px";let C=new Bg(f);return C.position.copy(w),C.userData.type="world",C.userData.name=E,SA.add(C),kv.push(C),C}function K9(E){Ue=E,kv.forEach(A=>{A.element.style.fontSize=E+"px"})}function Xe(){kv.forEach(E=>{SA.remove(E),E.element&&E.element.parentNode&&E.element.parentNode.removeChild(E.element)}),kv=[]}function _9(E){Xe(),L9.forEach(A=>{re(A.name,A.lon,A.lat,"continent",E)}),U9.forEach(A=>{re(A.name,A.lon,A.lat,"ocean",E)})}var se=new Gv,Lw=new hA;kB.domElement.addEventListener("dblclick",E=>{if(!wQ){RA('\u{1F4A1} \u8BF7\u5148\u5F00\u542F\u6807\u6CE8\u6A21\u5F0F\uFF08\u63A7\u5236\u9762\u677F\u4E2D\u7684"\u6807\u6CE8\u6A21\u5F0F"\u6309\u94AE\u6216\u6309 L \u952E\uFF09');return}if(!jA){RA("\u{1F4A1} \u8BF7\u5148\u52A0\u8F7D\u5730\u5F62");return}let A=kB.domElement.getBoundingClientRect();Lw.x=(E.clientX-A.left)/A.width*2-1,Lw.y=-((E.clientY-A.top)/A.height)*2+1,se.setFromCamera(Lw,VB);let B=se.intersectObject(jA);if(B.length>0){let Q=B[0].point,g=prompt("\u8BF7\u8F93\u5165\u6807\u6CE8\u6587\u5B57\uFF1A",`\u6807\u6CE8\u70B9 ${pg.length+1}`);g&&g.trim()?(W9(Q,g.trim()),RA(`\u2705 \u5DF2\u6DFB\u52A0\u6807\u6CE8: "${g.trim()}"`)):g!==null&&RA("\u{1F4A1} \u6807\u6CE8\u6587\u5B57\u4E0D\u80FD\u4E3A\u7A7A")}else RA("\u{1F4A1} \u8BF7\u53CC\u51FB\u5730\u5F62\u8868\u9762\u6DFB\u52A0\u6807\u6CE8")});function $9(E){return new Promise((A,B)=>{let Q=new FileReader;Q.onload=g=>{try{let v=JSON.parse(g.target.result);A(v)}catch(v){B(new Error("GeoJSON\u89E3\u6790\u5931\u8D25: "+v.message))}},Q.onerror=()=>B(new Error("\u8BFB\u53D6\u6587\u4EF6\u5931\u8D25")),Q.readAsText(E)})}function Ar(E){let A=[],B=E.features||[];if(B.length===0)throw new Error("GeoJSON\u4E2D\u6CA1\u6709\u627E\u5230features");let Q=null,g=["elevation","height","altitude","z","ele","Elevation","HEIGHT"];for(let w of B)if(w.properties){for(let f of g)if(w.properties[f]!==void 0&&w.properties[f]!==null){Q=f;break}if(Q)break}let v=!!Q;for(let w of B){let f=w.geometry;if(!f)continue;let C=w.properties||{},e=Q?parseFloat(C[Q]):null,P=Ye(f);for(let[D,t]of P){if(isNaN(D)||isNaN(t)||D<-180||D>180||t<-90||t>90)continue;let n=e!==null&&!isNaN(e)?e:0;A.push({lon:D,lat:t,elevation:n})}}if(A.length===0)throw new Error("\u672A\u80FD\u4ECEGeoJSON\u4E2D\u63D0\u53D6\u5230\u6709\u6548\u5750\u6807\u70B9");if(!v){console.warn("\u26A0\uFE0F GeoJSON\u4E2D\u672A\u627E\u5230\u9AD8\u7A0B\u5B57\u6BB5\uFF0C\u5C06\u4F7F\u7528\u6A21\u62DF\u9AD8\u7A0B");for(let w of A){let f=(w.lon+180)/360,C=(w.lat+90)/180;w.elevation=Math.sin(f*Math.PI*3)*Math.cos(C*Math.PI*2)*50+Math.sin(f*Math.PI*7)*.3*30+20,w.elevation=Math.max(0,w.elevation)}}return A}function Ye(E){let A=[];if(E.type==="Point")A.push(E.coordinates);else if(E.type==="MultiPoint")for(let B of E.coordinates)A.push(B);else if(E.type==="LineString")for(let B of E.coordinates)A.push(B);else if(E.type==="MultiLineString")for(let B of E.coordinates)for(let Q of B)A.push(Q);else if(E.type==="Polygon")for(let B of E.coordinates)for(let Q of B)A.push(Q);else if(E.type==="MultiPolygon")for(let B of E.coordinates)for(let Q of B)for(let g of Q)A.push(g);else if(E.type==="GeometryCollection")for(let B of E.geometries)A.push(...Ye(B));return A}function Br(E){let A=1/0,B=-1/0,Q=1/0,g=-1/0;for(let f of E)f.lon<A&&(A=f.lon),f.lon>B&&(B=f.lon),f.lat<Q&&(Q=f.lat),f.lat>g&&(g=f.lat);let v=(B-A)*.05||1,w=(g-Q)*.05||1;return{minLon:A-v,maxLon:B+v,minLat:Q-w,maxLat:g+w}}function Qr(E,A,B,Q=2){let g=0,v=0;if(E.length<3){let w=0;for(let f of E)w+=f.elevation;return E.length>0?w/E.length:0}for(let w of E){let f=w.lon-A,C=w.lat-B,e=Math.sqrt(f*f+C*C);if(e<1e-5)return w.elevation;let P=1/Math.pow(e,Q);g+=P*w.elevation,v+=P}return v>0?g/v:0}function Er(E,A,B,Q,g=2){let{minLon:v,maxLon:w,minLat:f,maxLat:C}=Q,e=[],P=E;if(E.length>5e3){let n=Math.ceil(E.length/5e3);P=E.filter((s,i)=>i%n===0),console.log(`\u{1F4CA} \u964D\u91C7\u6837: ${E.length} \u2192 ${P.length} \u4E2A\u70B9`)}let D=(w-v)/A,t=(C-f)/B;for(let n=0;n<B;n++){let s=[],i=f+(n+.5)*t;for(let r=0;r<A;r++){let I=v+(r+.5)*D,H=Qr(P,I,i,g);H=Math.max(-1e3,Math.min(8e3,H)),s.push(H)}e.push(s),n%20===0&&vr((n+1)/B)}return e}function gr(E,A,B){let Q=document.createElement("canvas");Q.width=A,Q.height=B;let g=Q.getContext("2d"),v=g.createImageData(A,B),w=v.data,f=1/0,C=-1/0;for(let P=0;P<B;P++)for(let D=0;D<A;D++){let t=E[P][D];t<f&&(f=t),t>C&&(C=t)}let e=C-f||1;for(let P=0;P<B;P++)for(let D=0;D<A;D++){let t=(P*A+D)*4,n=(E[P][D]-f)/e,s=Math.round(Math.max(0,Math.min(1,n))*255);w[t]=s,w[t+1]=s,w[t+2]=s,w[t+3]=255}return g.putImageData(v,0,0),Q}function vr(E){let A=document.getElementById("load-text"),B=Math.round(E*100);A.textContent=`\u23F3 \u751F\u6210\u5730\u5F62... ${B}%`}async function fr(E,A={}){let{gridWidth:B=600,gridHeight:Q=400,power:g=2}=A,v=document.getElementById("loading-overlay"),w=document.getElementById("load-text");v.classList.add("show"),w.textContent="\u{1F4CA} \u89E3\u6790GeoJSON\u6570\u636E...";try{let f=await $9(E);w.textContent="\u{1F4CA} \u63D0\u53D6\u9AD8\u7A0B\u70B9...";let C=Ar(f);if(C.length===0)throw new Error("\u672A\u63D0\u53D6\u5230\u6709\u6548\u6570\u636E\u70B9");console.log(`\u{1F4CA} \u63D0\u53D6\u5230 ${C.length} \u4E2A\u6570\u636E\u70B9`);let e=Br(C);console.log(`\u{1F4CA} \u8FB9\u754C: ${e.minLon}~${e.maxLon}, ${e.minLat}~${e.maxLat}`),w.textContent=`\u23F3 \u63D2\u503C\u751F\u6210\u7F51\u683C (${B}\xD7${Q})...`;let P=Er(C,B,Q,e,g);w.textContent="\u{1F5BC}\uFE0F \u751F\u6210\u7070\u5EA6\u56FE...";let D=gr(P,B,Q),t=new Image;return t.src=D.toDataURL("image/png"),await new Promise((n,s)=>{t.onload=n,t.onerror=s}),v.classList.remove("show"),t}catch(f){throw v.classList.remove("show"),f}}function wr(E,A){if(AB!=="china")return null;for(let B of oE)if(E>=B.minLon&&E<=B.maxLon&&A>=B.minLat&&A<=B.maxLat)return B;return null}function Cr(){let E=qA.target,A=jA?jA.scale.x:1.6,B=AB==="world"?-180:73,Q=AB==="world"?180:135,g=AB==="world"?-90:17,v=AB==="world"?90:54,w=(E.x/(A*.5)+1)/2,f=(E.z/.5+1)/2,C=B+w*(Q-B),e=g+(1-f)*(v-g);return{lon:C,lat:e}}function er(){if(!jA||Nv||QQ||AB!=="china")return;let E=performance.now();if(E-ie<500)return;if(ie=E,2.8/VB.position.distanceTo(qA.target)>Sw){let{lon:Q,lat:g}=Cr(),v=wr(Q,g);v&&v.pinyin!==AQ?cE(v):!v&&AQ&&tQ()}else AQ&&tQ()}async function cE(E){if(Nv)return;Nv=!0;let A=E.pinyin,B=`province_${A}.png`;Yw.style.display="flex",Ov.textContent=`\u{1F4E5} \u52A0\u8F7D ${E.name} \u9AD8\u6E05\u5730\u5F62...`;try{let Q=await Pr(B),g=gg.checked,v=parseFloat(Eg.value),w=RQ?"custom":fg,f=Math.min(parseInt(eQ.value)*2,600);_A&&(SA.remove(_A),_A.geometry&&_A.geometry.dispose(),_A.material&&_A.material.dispose());let C=Jw(Q,g,v,w,f);_A=C,SA.add(C),AQ=A,Ov.textContent=`\u2705 ${E.name} \u9AD8\u6E05\u5730\u5F62\u5DF2\u52A0\u8F7D (${f}\xD7${f})`,RA(`\u2705 \u5DF2\u52A0\u8F7D ${E.name} \u9AD8\u6E05\u5730\u5F62`)}catch(Q){console.warn(`\u65E0\u6CD5\u52A0\u8F7D\u7701\u4EFD\u5730\u5F62: ${B}`,Q),Ov.textContent=`\u26A0\uFE0F \u672A\u627E\u5230 ${E.name} \u9AD8\u6E05\u6570\u636E`,setTimeout(()=>{Yw.style.display="none"},3e3)}Nv=!1}function tQ(){_A&&(SA.remove(_A),_A.geometry&&_A.geometry.dispose(),_A.material&&_A.material.dispose(),_A=null,AQ=null,Yw.style.display="none",Ov.textContent="")}function Pr(E){return new Promise((A,B)=>{let Q=new Image;Q.onload=()=>A(Q),Q.onerror=()=>B(new Error(`\u52A0\u8F7D\u5931\u8D25: ${E}`)),Q.src=E})}var Te=new xv(10070715,.6);SA.add(Te);var Vw=new CE(16772829,1.4);Vw.position.set(2,4,3);SA.add(Vw);var kw=new CE(10079487,.6);kw.position.set(-3,2,-2);SA.add(kw);var je=new CE(16777215,.3);je.position.set(0,-1,-4);SA.add(je);var ye=new CE(13426175,.2);ye.position.set(0,5,0);SA.add(ye);function qw(E,A,B=600){let Q=VB.position.clone(),g=qA.target.clone(),v=performance.now();function w(){let f=performance.now()-v,C=Math.min(f/B,1),e=C<.5?4*C*C*C:1-Math.pow(-2*C+2,3)/2;VB.position.lerpVectors(Q,E,e),qA.target.lerpVectors(g,A,e),qA.update(),C<1&&requestAnimationFrame(w)}w()}N9.addEventListener("click",()=>{let E=new x(0,1.2,2.8),A=new x(0,0,0);qw(E,A),RA("\u{1F3E0} \u89C6\u89D2\u5DF2\u91CD\u7F6E"),tQ()});R9.addEventListener("click",()=>{let E=new x(0,4.5,.01),A=new x(0,0,0);qw(E,A),RA("\u2B07 \u4FEF\u89C6\u56FE")});Z9.addEventListener("click",()=>{if(!jA)return;let E=jA.scale.x/jA.scale.z,A=2.8;E>1.6?A=3.5:E<.7&&(A=2.2);let B=new x(0,1.2,A),Q=new x(0,0,0);qw(B,Q),RA("\u2B1B \u9002\u5E94\u5C4F\u5E55")});function Bf(){[Tw,jw,yw].forEach(E=>E.classList.remove("active")),qA.autoRotate?qA.autoRotateSpeed>0?yw.classList.add("active"):Tw.classList.add("active"):jw.classList.add("active")}function Oe(E){qA.autoRotateSpeed=Math.abs(E),E<0?qA.autoRotateSpeed=-Math.abs(qA.autoRotateSpeed):qA.autoRotateSpeed=Math.abs(qA.autoRotateSpeed),qA.autoRotate=!0,Bf()}Tw.addEventListener("click",()=>{Oe(-Math.abs(parseFloat(Vv.value))),RA("\u25C0 \u5DE6\u65CB")});yw.addEventListener("click",()=>{Oe(Math.abs(parseFloat(Vv.value))),RA("\u25B6 \u53F3\u65CB")});jw.addEventListener("click",()=>{qA.autoRotate=!1,Bf(),RA("\u23F8 \u65CB\u8F6C\u505C\u6B62")});Vv.addEventListener("input",()=>{let E=parseFloat(Vv.value);if(y9.textContent=E.toFixed(1),qA.autoRotate){let A=qA.autoRotateSpeed>=0?1:-1;qA.autoRotateSpeed=A*E}});function tr(){return{name:"\u81EA\u5B9A\u4E49",stops:[{pos:0,color:bg(IE[0].value)},{pos:.25,color:bg(IE[1].value)},{pos:.5,color:bg(IE[2].value)},{pos:.75,color:bg(IE[3].value)},{pos:1,color:bg(IE[4].value)}]}}function bg(E){let A=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(E);return A?[parseInt(A[1],16),parseInt(A[2],16),parseInt(A[3],16)]:[128,128,128]}function Ne(){let E=Array.from(IE).map(A=>A.value);O9.innerHTML=E.map(A=>`<span style="background:${A};"></span>`).join("")}IE.forEach(E=>{E.addEventListener("input",()=>{if(Ne(),RQ&&dQ&&!QQ&&(vg(),_A)){let A=oE.find(B=>B.pinyin===AQ);A&&(tQ(),cE(A))}})});function Dr(E,A){let B;if(A==="custom"?B=tr():B=Af[A],!B)return[128,128,128];let Q=B.stops;if(B.stepped){for(let g=Q.length-1;g>=0;g--)if(E>=Q[g].pos)return Q[g].color;return Q[0].color}if(E<=Q[0].pos)return Q[0].color;if(E>=Q[Q.length-1].pos)return Q[Q.length-1].color;for(let g=0;g<Q.length-1;g++){let v=Q[g],w=Q[g+1];if(E>=v.pos&&E<=w.pos){let f=(E-v.pos)/(w.pos-v.pos);return[Math.round(v.color[0]+(w.color[0]-v.color[0])*f),Math.round(v.color[1]+(w.color[1]-v.color[1])*f),Math.round(v.color[2]+(w.color[2]-v.color[2])*f)]}}return Q[Q.length-1].color}function Jw(E,A,B,Q,g){let v=E.width,w=E.height,f=v/w,C=document.createElement("canvas");C.width=v,C.height=w;let e=C.getContext("2d");e.drawImage(E,0,0);let D=e.getImageData(0,0,v,w).data,t=B*255,n=new Uint8ClampedArray(D.length),s=new Uint8ClampedArray(D.length);for(let p=0;p<D.length;p+=4){let L=D[p],N=D[p+1],k=D[p+2],V=.299*L+.587*N+.114*k;if(V<t)n[p]=0,n[p+1]=0,n[p+2]=0,n[p+3]=0,s[p]=0,s[p+1]=0,s[p+2]=0,s[p+3]=255;else{let W=V/255;A&&(W=1-W);let $=Dr(W,Q);n[p]=$[0],n[p+1]=$[1],n[p+2]=$[2],n[p+3]=255;let eA=A?255-L:L;s[p]=eA,s[p+1]=eA,s[p+2]=eA,s[p+3]=255}}let i=new ImageData(n,v,w),r=document.createElement("canvas");r.width=v,r.height=w,r.getContext("2d").putImageData(i,0,0);let H=new dg(r);H.needsUpdate=!0,H.wrapS=zB,H.wrapT=zB,H.minFilter=TQ,H.magFilter=bB,H.generateMipmaps=!0,H.colorSpace=eB;let o=new ImageData(s,v,w),l=document.createElement("canvas");l.width=v,l.height=w,l.getContext("2d").putImageData(o,0,0);let b=new dg(l);b.needsUpdate=!0,b.wrapS=zB,b.wrapT=zB,b.minFilter=TQ,b.magFilter=bB,b.generateMipmaps=!0;let h=Math.min(g,Math.floor(v/2)),Z=Math.min(g,Math.floor(w/2));h<20&&(h=20),Z<20&&(Z=20);let a=800;h>a&&(h=a),Z>a&&(Z=a);let u=new Hg(2,2,h,Z);u.rotateX(-Math.PI/2);let y=Ve==="dark",q=new pv({map:H,displacementMap:b,displacementScale:parseFloat(Xg.value),displacementBias:parseFloat(Ug.value),roughness:.45,metalness:.05,emissive:y?new lA(2232576):new lA(0),emissiveIntensity:y?.05:0,side:yB,transparent:!0,depthWrite:!0}),EA=new UB(u,q);return EA.scale.set(f,1,1),u.computeVertexNormals(),EA.userData.colorTexture=H,EA.userData.dispTexture=b,EA.userData.material=q,EA.userData.segments={x:h,y:Z},EA}function vg(){if(!dQ)return;let E=gg.checked,A=parseFloat(Eg.value),B=RQ?"custom":fg,Q=parseInt(eQ.value),g=jA,v=Jw(dQ,E,A,B,Q);if(jA=v,SA.add(v),g&&(SA.remove(g),g.geometry&&g.geometry.dispose(),g.material&&g.material.dispose(),g.userData.colorTexture&&g.userData.colorTexture.dispose(),g.userData.dispTexture&&g.userData.dispTexture.dispose()),_A&&AB==="china"){let f=oE.find(C=>C.pinyin===AQ);f&&(tQ(),cE(f))}$e(),pe.textContent=E?"\u53CD\u8F6C":"\u6B63\u5E38";let w=RQ?"\u81EA\u5B9A\u4E49":Af[fg].name;Fe.textContent="\u{1F3A8} "+w,Ww()}function Re(){if(!jA||!jA.material)return;let E=parseFloat(Ug.value),A=parseFloat(Xg.value);jA.material.displacementBias=E,jA.material.displacementScale=A,_A&&_A.material&&(_A.material.displacementBias=E,_A.material.displacementScale=A),Ww(),jA.geometry&&jA.geometry.computeVertexNormals(),_A&&_A.geometry&&_A.geometry.computeVertexNormals(),$e()}function Ww(){T9.textContent=parseFloat(Ug.value).toFixed(2),j9.textContent=parseFloat(Xg.value).toFixed(2),he.textContent=parseFloat(Eg.value).toFixed(3),be.textContent=eQ.value,me.textContent=mg.value}var Ir={light:{background:"#f5f5f5",bodyClass:"light-theme",ambient:new lA(10070715),main:new lA(16772829),fill:new lA(10079487)},lightblue:{background:"#c8e6ff",bodyClass:"light-theme",ambient:new lA(8956620),main:new lA(16772829),fill:new lA(8965375)},dark:{background:"#0a0a1a",bodyClass:"dark-theme",ambient:new lA(4210795),main:new lA(16772829),fill:new lA(8961023)}};function Ze(E){let A=Ir[E];if(!A)return;Ve=E,SA.background=new lA(A.background),Te.color.copy(A.ambient),Vw.color.copy(A.main),kw.color.copy(A.fill),document.body.className=A.bodyClass,xe.forEach(Q=>Q.classList.toggle("active",Q.dataset.bg===E));let B=Q=>{Q&&Q.material&&(E==="dark"?(Q.material.emissive.setHex(2232576),Q.material.emissiveIntensity=.05):(Q.material.emissive.setHex(0),Q.material.emissiveIntensity=0),Q.material.needsUpdate=!0)};B(jA),B(_A),RA(`\u{1F3A8} \u5207\u6362\u81F3 ${E==="dark"?"\u6DF1\u8272":E==="lightblue"?"\u6DE1\u84DD":"\u767D\u8272"} \u4E3B\u9898`)}var AB=null,QQ=!1,dQ=null,jA=null,_A=null,fg="classic",Ve="light",RQ=!1,AQ=null,Nv=!1,ie=0,Sw=.6;function Kw(E,A=null,B=null){QQ=!0,AB=A,dQ=E,jA&&(SA.remove(jA),jA.geometry&&jA.geometry.dispose(),jA.material&&jA.material.dispose(),jA.userData.colorTexture&&jA.userData.colorTexture.dispose(),jA.userData.dispTexture&&jA.userData.dispTexture.dispose()),tQ(),Xe();let Q=gg.checked,g=parseFloat(Eg.value),v=RQ?"custom":fg,w=parseInt(eQ.value);jA=Jw(E,Q,g,v,w),SA.add(jA),ar(E,A);let C=A==="china",e=document.getElementById("mountain-group"),P=document.getElementById("profile-group");e&&(e.style.display=C?"block":"none"),P&&(P.style.display=C?"block":"none"),C?(hr(),BQ?uQ(!0):Sv(),Kv(),Lg()):(Sv(),Kv(),Lg());let D=E.width/E.height,t=2.8;D>1.6?t=3.5:D<.7&&(t=2.2),VB.position.set(0,1.2,t),qA.target.set(0,0,0),qA.update(),nE.classList.add("visible"),rE.style.display="none",NQ.classList.add("hidden"),pe.textContent=Q?"\u53CD\u8F6C":"\u6B63\u5E38";let n=RQ?"\u81EA\u5B9A\u4E49":Af[fg].name;Fe.textContent="\u{1F3A8} "+n,Ww(),Bf();let s=(w+1)*(w+1),i=A==="world"?"\u4E16\u754C\u5730\u5F62":A==="china"?"\u4E2D\u56FD\u5730\u5F62":A==="geojson"?"GeoJSON\u5730\u5F62":"\u81EA\u5B9A\u4E49";Y9.textContent=`\u{1F52C} ${w}\xD7${w} (${s.toLocaleString()}) \xB7 ${i}`,A==="world"?(_9(D),document.querySelector("#info h1").innerHTML="\u{1F5FA}\uFE0F <span>\u4E16\u754C</span> \u5730\u5F62",document.getElementById("world-label-size-group").style.display="block"):(document.querySelector("#info h1").innerHTML=A==="china"?"\u{1F5FA}\uFE0F <span>\u4E2D\u56FD</span> \u5730\u5F62":A==="geojson"?"\u{1F5FA}\uFE0F <span>GeoJSON</span> \u5730\u5F62":"\u{1F5FA}\uFE0F <span>\u81EA\u5B9A\u4E49</span> \u5730\u5F62",document.getElementById("world-label-size-group").style.display="none"),document.querySelector("#info p")?.remove(),QQ=!1,B&&B()}var nr="data/world-terrain.png",rr="data/china-terrain.png";function sr(E){return new Promise(A=>{let B=document.getElementById("loading-overlay"),Q=document.getElementById("load-text"),g=E==="world"?nr:rr,v=E==="world"?"\u4E16\u754C":"\u4E2D\u56FD";if(!(g&&g.length>5&&(g.startsWith("data:image")||g.startsWith("data/")))){console.warn(`\u26A0\uFE0F ${v}\u5730\u5F62 Base64 \u6570\u636E\u4E3A\u7A7A\uFF0C\u4F7F\u7528\u566A\u58F0\u5730\u5F62`),B.classList.add("show"),Q.textContent=`\u23F3 \u751F\u6210 ${v} \u5730\u5F62\u793A\u4F8B\uFF08\u5907\u7528\u65B9\u6848\uFF09...`,setTimeout(()=>{let C;E==="world"?C=yv(1800,900,12345):C=yv(1e3,600,67890);let e=new Image;e.onload=()=>{B.classList.remove("show"),A(e)},e.onerror=()=>{B.classList.remove("show");let P=document.createElement("canvas");P.width=600,P.height=400;let D=P.getContext("2d");D.fillStyle="#888",D.fillRect(0,0,600,400);let t=new Image;t.onload=()=>A(t),t.src=P.toDataURL("image/png")},e.src=C.toDataURL("image/png")},300);return}B.classList.add("show"),Q.textContent=`\u23F3 \u52A0\u8F7D ${v} \u5730\u5F62\u793A\u4F8B...`;let f=new Image;f.onload=()=>{B.classList.remove("show"),console.log(`\u2705 ${v}\u5730\u5F62\u52A0\u8F7D\u6210\u529F\uFF01\u5C3A\u5BF8: ${f.width}\xD7${f.height}`),A(f)},f.onerror=()=>{B.classList.remove("show"),console.warn(`\u26A0\uFE0F ${v}\u5730\u5F62 Base64 \u52A0\u8F7D\u5931\u8D25\uFF0C\u4F7F\u7528\u566A\u58F0\u5730\u5F62`),setTimeout(()=>{let C;E==="world"?C=yv(1800,900,12345):C=yv(1e3,600,67890);let e=new Image;e.onload=()=>A(e),e.src=C.toDataURL("image/png")},300)},f.src=g})}function yv(E,A,B=42){let Q=document.createElement("canvas");Q.width=E,Q.height=A;let g=Q.getContext("2d"),v=g.createImageData(E,A),w=v.data;function f(P,D){let t=B+P*374761393+D*668265263;return t=(t^t>>13)*1274126177,(t^t>>16)&4294967295}function C(P,D){let t=Math.floor(P),n=Math.floor(D),s=P-t,i=D-n,r=(f(t,n)&255)/255,I=(f(t+1,n)&255)/255,H=(f(t,n+1)&255)/255,o=(f(t+1,n+1)&255)/255,l=s*s*(3-2*s),F=i*i*(3-2*i);return r*(1-l)*(1-F)+I*l*(1-F)+H*(1-l)*F+o*l*F}function e(P,D,t=6){let n=0,s=.5,i=1;for(let r=0;r<t;r++)n+=s*C(P*i,D*i),s*=.5,i*=2;return n}for(let P=0;P<A;P++)for(let D=0;D<E;D++){let t=(P*E+D)*4,n=D/E,s=P/A,i=Math.sin(n*Math.PI*2.2)*Math.sin(s*Math.PI*1.8)*.3+.5,r=e(n*4,s*4)*.7+i*.3;r=Math.max(0,Math.min(1,r));let I=Math.round(r*255);w[t]=I,w[t+1]=I,w[t+2]=I,w[t+3]=255}return g.putImageData(v,0,0),Q}var PQ=73,qv=135,ke=53.5,ir=221,Mr=2869/62,or=88,cr=46;function _w(E,A){return{px:ir+(E-PQ)*Mr,py:or+(ke-A)*cr}}var qB=null;function ar(E,A){let B=document.createElement("canvas");B.width=E.width,B.height=E.height;let Q=B.getContext("2d");Q.drawImage(E,0,0);let g=Q.getImageData(0,0,E.width,E.height).data,v=new Float32Array(E.width*E.height);for(let w=0,f=0;w<g.length;w+=4,f++)v[f]=(.299*g[w]+.587*g[w+1]+.114*g[w+2])/255;qB={w:E.width,h:E.height,gray:v,type:A}}function qe(E,A){if(!qB)return 0;let{w:B,h:Q,gray:g}=qB,{px:v,py:w}=_w(E,A),f=Math.max(0,Math.min(B-1,Math.round(v))),C=Math.max(0,Math.min(Q-1,Math.round(w))),e=g[C*B+f];return gg.checked&&(e=1-e),e}var tE=[[0,0],[97,50],[121,1e3],[164,2800],[205,3650],[227,8849]];function zr(E){if(E<=tE[0][0])return tE[0][1];for(let A=0;A<tE.length-1;A++){let[B,Q]=tE[A],[g,v]=tE[A+1];if(E<=g)return Q+(E-B)*(v-Q)/(g-B)}return tE[tE.length-1][1]}function xg(E,A){return parseFloat(Ug.value)+parseFloat(Xg.value)*qe(E,A)}function Je(E,A){return zr(qe(E,A)*255)}function Gg(E){let{px:A}=_w(E,ke);return(A/qB.w-.5)*2*jA.scale.x}function OQ(E){let{py:A}=_w(PQ,E);return(A/qB.h-.5)*2*jA.scale.z}var Ow=[{name:"\u5929\u5C71\u5C71\u8109",dir:"\u6A2A\u5411",points:[[80.5,42.5],[83,42.9],[85,43.1],[87,43.3],[89,43.1],[91,42.8],[93,42.7],[95,43.3]]},{name:"\u9634\u5C71\u5C71\u8109",dir:"\u6A2A\u5411",points:[[106,40.6],[108,40.8],[110,41.2],[112,41.5],[114,41.8],[116,42]]},{name:"\u6606\u4ED1\u5C71\u8109",dir:"\u6A2A\u5411",points:[[75,36.6],[78,36.4],[82,36.1],[86,35.9],[90,36],[94,36.1],[98,35.7],[102,35.4],[104,35.2]]},{name:"\u79E6\u5CAD",dir:"\u6A2A\u5411",points:[[104,33.5],[106,33.6],[108,33.9],[110,34.1],[112,34.3],[113.5,34]]},{name:"\u5357\u5CAD",dir:"\u6A2A\u5411",points:[[109.5,24.8],[111,25],[113,25.3],[115,25.5],[116.5,25.2]]},{name:"\u71D5\u5C71\u5C71\u8109",dir:"\u6A2A\u5411",points:[[114.5,40.5],[116,40.8],[118,41],[119.5,40.6]]},{name:"\u5927\u5174\u5B89\u5CAD",dir:"\u7EB5\u5411",points:[[122.5,53.3],[123.2,52.5],[123.6,51.7],[123.7,50.8],[123.5,50],[122.9,49.2],[122.2,48.3],[121.4,47.4],[120.5,46.5],[119.8,45.5],[119.3,44.5]]},{name:"\u592A\u884C\u5C71\u8109",dir:"\u7EB5\u5411",points:[[115.6,39.9],[115,39.5],[114.5,39],[114,38.4],[113.6,37.8],[113.3,37],[113,36.2],[112.8,35.5],[112.5,35]]},{name:"\u5DEB\u5C71",dir:"\u7EB5\u5411",points:[[109.4,31.8],[109.6,31.3],[109.8,30.8],[110,30.3],[110.3,29.8]]},{name:"\u96EA\u5CF0\u5C71",dir:"\u7EB5\u5411",points:[[110,28.8],[110.3,28.2],[110.6,27.6],[111,27],[111.3,26.5]]},{name:"\u957F\u767D\u5C71\u8109",dir:"\u7EB5\u5411",points:[[126.8,43],[127.3,42.6],[127.8,42.3],[128,42]]},{name:"\u6B66\u5937\u5C71\u8109",dir:"\u7EB5\u5411",points:[[117.5,28.3],[117.9,27.5],[118.1,26.8],[117.9,26.1],[117.4,25.4],[116.9,24.8]]},{name:"\u53F0\u6E7E\u5C71\u8109",dir:"\u7EB5\u5411",points:[[121.2,24.6],[121.3,24.4],[121.4,23.9],[121.3,23.5],[121.1,23.1]]},{name:"\u963F\u5C14\u6CF0\u5C71",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[86.2,47.4],[86.8,47.7],[87.5,47.9]]},{name:"\u7941\u8FDE\u5C71\u8109",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[94,38.8],[95.5,38.6],[97,38.4],[98.5,38.2],[100,38],[101.5,37.8],[103,37.5],[104.5,37.2]]},{name:"\u5C0F\u5174\u5B89\u5CAD",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[126.9,49.7],[128.2,49.4],[129.5,49],[130.3,48.3],[130.3,47]]},{name:"\u5510\u53E4\u62C9\u5C71\u8109",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[90.5,33.2],[92,33],[94,32.8],[96,32.6],[98,32.3]]},{name:"\u5DF4\u989C\u5580\u62C9\u5C71",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[95,34.6],[97,34.8],[99,34.6],[101,34.4],[103,34.2]]},{name:"\u5927\u522B\u5C71",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[114.3,31.7],[115,31.5],[115.8,31.3],[116.5,31.1]]},{name:"\u559C\u9A6C\u62C9\u96C5\u5C71\u8109",dir:"\u897F\u5317\u2014\u4E1C\u5357",points:[[83.5,28.9],[85,28.9],[86.4,28.5],[86.9,28.2],[88.2,28.7],[90.2,28.4],[92.2,28.1],[94.2,28.4],[95.2,29.5]]},{name:"\u8D3A\u5170\u5C71",dir:"\u5357\u5317\u8D70\u5411",points:[[105.3,39.6],[105.6,38.8],[105.9,38],[106.1,37.2],[106.2,36.8]]},{name:"\u516D\u76D8\u5C71",dir:"\u5357\u5317\u8D70\u5411",points:[[106,36.8],[106.2,36.2],[106.3,35.6],[106.4,35.2]]},{name:"\u6A2A\u65AD\u5C71\u8109",dir:"\u5357\u5317\u8D70\u5411",points:[[98.5,32.5],[98.8,31.5],[99,30.5],[99.5,29.5],[100,28.5],[100.5,27.5],[101,26.5],[101.5,25.5]]},{name:"\u5415\u6881\u5C71",dir:"\u5357\u5317\u8D70\u5411",points:[[110.7,38.2],[110.9,37.7],[111.1,37.2],[111.3,36.7],[111.5,36.2]]},{name:"\u54C0\u7262\u5C71",dir:"\u5357\u5317\u8D70\u5411",points:[[101,24.8],[101.2,24.2],[101.4,23.6],[101.6,23]]},{name:"\u4E4C\u8499\u5C71",dir:"\u5357\u5317\u8D70\u5411",points:[[103.5,27.5],[104,26.8],[104.5,26.2],[105,25.6]]}],Hr={45:"\u51C6\u5676\u5C14",36:"\u9EC4\u6CB3",30:"\u957F\u6C5F",22:"\u73E0\u6C5F"},Qg=null,Jv=[],Nw=[],Wv="\u5168\u90E8",BQ=!0,sE=null;function ur(){Nw.forEach(E=>{SA.remove(E),E.element&&E.element.parentNode&&E.element.parentNode.removeChild(E.element)}),Nw=[]}function Sv(){sE&&(cancelAnimationFrame(sE),sE=null),Qg&&(SA.remove(Qg),Qg=null),Jv=[],ur()}function dr(E,A){let B=document.createElement("div");B.className="mountain-label",B.textContent=E;let Q=new Bg(B);Q.position.copy(A),SA.add(Q),Nw.push(Q)}function uQ(E=!0){if(Sv(),!BQ||AB!=="china"||!qB||!jA)return;Qg=new cQ;let A=Ow.filter(g=>Wv==="\u5168\u90E8"||g.dir===Wv),B=EQ&&lQ&&Cg==="hide",Q=B?OQ(ZB):0;A.forEach(g=>{let v=B?br(g.points,Q,$w==="north"):g.points;if(v.length<2)return;let w=v.map(([t,n])=>new x(Gg(t),xg(t,n)+.022,OQ(n))),f=new YB().setFromPoints(w),C=new SE(f,new vE({color:16765514,transparent:!0,opacity:.95}));Qg.add(C),Jv.push(C);let e=v.reduce((t,n)=>t+n[0],0)/v.length,P=v.reduce((t,n)=>t+n[1],0)/v.length,D=new x(Gg(e),xg(e,P)+.04,OQ(P));dr(g.name,D)}),SA.add(Qg),E?lr():Jv.forEach(g=>g.geometry.setDrawRange(0,g.geometry.attributes.position.count))}function lr(){sE&&cancelAnimationFrame(sE);let E=performance.now(),A=1400,B=()=>{let Q=Math.min((performance.now()-E)/A,1);Jv.forEach((g,v)=>{let w=g.geometry.attributes.position.count,f=Math.floor(w*Math.max(0,Math.min(1,Q-v*.015)));g.geometry.setDrawRange(0,f)}),Q<1?sE=requestAnimationFrame(B):sE=null};B()}function hr(){let E=B=>Ow.filter(Q=>Q.dir===B).length,A=B=>document.getElementById(B);A("dir-all-count").textContent=Ow.length,A("dir-h-count").textContent=E("\u6A2A\u5411"),A("dir-v-count").textContent=E("\u7EB5\u5411"),A("dir-nw-count").textContent=E("\u897F\u5317\u2014\u4E1C\u5357"),A("dir-s-count").textContent=E("\u5357\u5317\u8D70\u5411")}var ZB=36,wg=!0,DE=null;function Qf(){for(DE||(DE=new cQ,SA.add(DE));DE.children.length;)DE.remove(DE.children[0]);if(EQ||!wg||AB!=="china"||!qB||!jA)return;let E=[];for(let B=0;B<=120;B++){let Q=PQ+(qv-PQ)*B/120;E.push(new x(Gg(Q),xg(Q,ZB)+.016,OQ(ZB)))}let A=new YB().setFromPoints(E);DE.add(new SE(A,new vE({color:5099775,transparent:!0,opacity:.9})))}function Ef(){let E=document.getElementById("profile-panel"),A=document.getElementById("profile-canvas");if(!E||!A||!wg||AB!=="china"||!qB){E&&E.classList.remove("show");return}E.classList.add("show");let B=A.getContext("2d"),Q=A.width,g=A.height;B.clearRect(0,0,Q,g);let v=ZB,w=Q,f=new Float32Array(w),C=500;for(let l=0;l<w;l++){let F=PQ+(qv-PQ)*l/(w-1),b=Je(F,v);f[l]=b,b>C&&(C=b)}C=Math.ceil(C/500)*500;let e=40,P=10,D=16,t=24,n=Q-e-P,s=g-D-t,i=l=>e+n*l/(w-1),r=l=>D+s*(1-l/C);[[0,500,"#3f9460"],[500,2e3,"#c8be6e"],[2e3,4e3,"#d6a05a"],[4e3,9e3,"#b27a58"]].forEach(([l,F,b])=>{let h=r(Math.min(l,C)),Z=r(Math.min(F,C));Z>=h||(B.fillStyle=b,B.globalAlpha=.3,B.fillRect(e,Z,n,h-Z),B.globalAlpha=1)}),[500,2e3,4e3].forEach(l=>{if(l>C)return;let F=r(l);B.strokeStyle="#999",B.setLineDash([3,3]),B.beginPath(),B.moveTo(e,F),B.lineTo(Q-P,F),B.stroke(),B.setLineDash([]),B.fillStyle="#777",B.font="9px sans-serif",B.fillText(l+"m",e+2,F-2)}),B.strokeStyle="#e0533d",B.lineWidth=1.8,B.beginPath();for(let l=0;l<w;l++){let F=i(l),b=r(f[l]);l?B.lineTo(F,b):B.moveTo(F,b)}B.stroke(),B.fillStyle="#555",B.font="10px sans-serif",B.fillText("73\xB0E",e,g-6),B.fillText("135\xB0E",Q-P-34,g-6),B.fillText(Math.round(C)+"m",2,D+8),B.fillText("0",6,g-t+6);let H=Hr[Math.round(v)],o=document.getElementById("profile-title");o&&(o.textContent=v.toFixed(1)+"\xB0N "+(H?H+"\u5256\u9762":"\u5256\u9762")+" \xB7 \u897F\u9AD8\u4E1C\u4F4E \u4E09\u7EA7\u9636\u68AF\uFF08\u793A\u610F\u6362\u7B97\uFF09")}function Kv(){let E=wg&&AB==="china"&&!!qB,A=document.getElementById("profile-panel");A&&A.classList.toggle("show",E),Qf(),Ef()}var EQ=!1,$w="north",Cg="hide",lQ=null,CQ=null,yQ=null;function We(){CQ&&(SA.remove(CQ),CQ.geometry&&CQ.geometry.dispose(),CQ.material&&CQ.material.dispose(),CQ=null),yQ&&(SA.remove(yQ),yQ.geometry&&yQ.geometry.dispose(),yQ=null)}function iE(E){let A=[];jA&&jA.material&&A.push(jA.material),_A&&_A.material&&A.push(_A.material),A.forEach(B=>{B.transparent=!0,B.opacity=E?.32:1,B.depthWrite=!E,B.needsUpdate=!0})}function AC(){if(!EQ||AB!=="china"||!qB||!jA){lQ=null;return}let E=OQ(ZB);lQ=$w==="north"?new pB(new x(0,0,1),-E):new pB(new x(0,0,-1),E)}function ME(E){kB&&(kB.localClippingEnabled=E),SA.traverse(A=>{if(!A.isMesh)return;(Array.isArray(A.material)?A.material:[A.material]).forEach(Q=>{Q&&(Q.clippingPlanes=E&&lQ?[lQ]:null,Q.needsUpdate=!0)})})}function br(E,A,B){let Q=[];for(let g=0;g<E.length-1;g++){let v=E[g],w=E[g+1],f=OQ(v[1]),C=OQ(w[1]),e=B?f>=A:f<=A,P=B?C>=A:C<=A;if(e&&P){Q.push(w);continue}if(f===C)continue;let D=(A-f)/(C-f),t=[v[0]+(w[0]-v[0])*D,v[1]+(w[1]-v[1])*D];e&&!P?Q.push(t):!e&&P&&(Q.push(t),Q.push(w))}return Q}function _v(){if(We(),!EQ||AB!=="china"||!qB||!jA)return;let E=ZB,A=OQ(E),B=-.55,Q=180,g=t=>{let n=Je(t,E);return n<500?[63,148,96]:n<2e3?[200,190,110]:n<4e3?[214,160,90]:[178,120,90]},v=[],w=[],f=[];for(let t=0;t<=Q;t++){let n=PQ+(qv-PQ)*t/Q,s=Gg(n),i=xg(n,E)+.006;v.push(s,i,A,s,B,A);let r=g(n),I=[r[0]/255,r[1]/255,r[2]/255];w.push(I[0],I[1],I[2],I[0],I[1],I[2])}for(let t=0;t<Q;t++){let n=t*2,s=t*2+1,i=t*2+2,r=t*2+3;f.push(n,s,i,s,r,i)}let C=new YB;C.setAttribute("position",new XB(v,3)),C.setAttribute("color",new XB(w,3)),C.setIndex(f),C.computeVertexNormals();let e=new JE({vertexColors:!0,side:yB});CQ=new UB(C,e),CQ.renderOrder=5,SA.add(CQ);let P=[];for(let t=0;t<=Q;t++){let n=PQ+(qv-PQ)*t/Q;P.push(new x(Gg(n),xg(n,E)+.014,A))}let D=new YB().setFromPoints(P);yQ=new SE(D,new vE({color:16734780})),yQ.renderOrder=6,SA.add(yQ)}function Lg(){let E=EQ&&AB==="china"&&qB&&jA;E&&Cg==="hide"?(AC(),ME(!0),iE(!1),_v(),BQ&&uQ(!1)):E&&Cg==="ghost"?(lQ=null,ME(!1),iE(!0),_v(),BQ&&uQ(!1)):(lQ=null,ME(!1),iE(!1),We(),BQ&&uQ(!1)),Qf(),Ef()}function Se(){Qf(),Ef(),EQ&&AB==="china"&&(Cg==="hide"?(AC(),ME(!0),iE(!1)):(lQ=null,ME(!1),iE(!0)),_v(),BQ&&uQ(!1))}function Ke(E){$w=E;let A=document.getElementById("clip-north-btn"),B=document.getElementById("clip-south-btn");A&&A.classList.toggle("active",E==="north"),B&&B.classList.toggle("active",E==="south"),EQ&&AB==="china"&&(Lg(),RA(E==="north"?"\u{1F50D} \u5DF2\u9690\u85CF\u5256\u5207\u7EBF\u4EE5\u5357\uFF0C\u4FDD\u7559\u5317\u4FA7":"\u{1F50D} \u5DF2\u9690\u85CF\u5256\u5207\u7EBF\u4EE5\u5317\uFF0C\u4FDD\u7559\u5357\u4FA7"))}function _e(E){Cg=E;let A=document.getElementById("hidden-hide-btn"),B=document.getElementById("hidden-ghost-btn");A&&A.classList.toggle("active",E==="hide"),B&&B.classList.toggle("active",E==="ghost"),EQ&&AB==="china"&&(Lg(),RA(E==="hide"?"\u{1F441}\uFE0F \u9690\u85CF\u4FA7\u6837\u5F0F\uFF1A\u5B8C\u5168\u9690\u85CF\uFF08\u771F\u5207\u5F00\uFF09":"\u{1F441}\uFE0F \u9690\u85CF\u4FA7\u6837\u5F0F\uFF1A\u534A\u900F\u660E\u663E\u793A"))}function $e(){AB==="china"&&(BQ&&uQ(!1),Qf(),Ef(),EQ&&(Cg==="hide"?(AC(),ME(!0),iE(!1)):(lQ=null,ME(!1),iE(!0)),_v()))}var Uw=document.getElementById("mt-toggle"),Fg=document.getElementById("profile-toggle"),Rv=document.getElementById("profile-lat-slider"),AP=document.getElementById("profile-lat-value"),Me=document.getElementById("btn-regrow");document.querySelectorAll(".dir-btn").forEach(E=>{E.addEventListener("click",()=>{document.querySelectorAll(".dir-btn").forEach(A=>A.classList.remove("active")),E.classList.add("active"),Wv=E.dataset.dir,AB==="china"&&uQ(!0),RA("\u26F0\uFE0F \u5C71\u8109\u7B5B\u9009\uFF1A"+Wv)})});Uw&&Uw.addEventListener("change",()=>{BQ=Uw.checked,AB==="china"&&(BQ?uQ(!0):Sv(),RA(BQ?"\u26F0\uFE0F \u5C71\u8109\u9AA8\u67B6\u5DF2\u663E\u793A":"\u26F0\uFE0F \u5C71\u8109\u9AA8\u67B6\u5DF2\u9690\u85CF"))});Me&&Me.addEventListener("click",()=>{AB==="china"&&BQ&&(uQ(!0),RA("\u2728 \u5C71\u8109\u9AA8\u67B6\u91CD\u65B0\u751F\u957F"))});Fg&&Fg.addEventListener("change",()=>{wg=Fg.checked,Kv(),RA(wg?"\u{1F4D0} \u5256\u9762\u9762\u677F\u5DF2\u663E\u793A":"\u{1F4D0} \u5256\u9762\u9762\u677F\u5DF2\u9690\u85CF")});Rv&&Rv.addEventListener("input",()=>{ZB=parseFloat(Rv.value),AP.textContent=ZB.toFixed(1)+"\xB0N",Se(),RA("\u{1F4D0} \u5256\u5207\u7EAC\u5EA6 "+ZB.toFixed(1)+"\xB0N")});document.querySelectorAll(".profile-preset").forEach(E=>{E.addEventListener("click",()=>{document.querySelectorAll(".profile-preset").forEach(A=>A.classList.remove("active")),E.classList.add("active"),ZB=parseFloat(E.dataset.lat),Rv.value=ZB,AP.textContent=ZB.toFixed(1)+"\xB0N",Se(),RA("\u{1F4D0} \u5256\u9762\u5207\u6362\uFF1A"+E.textContent.trim())})});var Xw=document.getElementById("persp-toggle");Xw&&Xw.addEventListener("change",()=>{EQ=Xw.checked,Lg(),RA(EQ?"\u{1F52A} \u900F\u89C6\u5256\u9762\u5DF2\u5F00\u542F\uFF1A\u5256\u5207\u7EBF\u4E00\u4FA7\u5730\u5F62\u5DF2\u9690\u85CF\uFF0C\u53EF\u89C1\u5185\u90E8\u5207\u9762":"\u{1F52A} \u900F\u89C6\u5256\u9762\u5DF2\u5173\u95ED")});var oe=document.getElementById("clip-north-btn"),ce=document.getElementById("clip-south-btn");oe&&oe.addEventListener("click",()=>Ke("north"));ce&&ce.addEventListener("click",()=>Ke("south"));var ae=document.getElementById("hidden-hide-btn"),ze=document.getElementById("hidden-ghost-btn");ae&&ae.addEventListener("click",()=>_e("hide"));ze&&ze.addEventListener("click",()=>_e("ghost"));(function(){let A=document.getElementById("profile-panel"),B=document.getElementById("profile-header"),Q=document.getElementById("profile-resize"),g=document.getElementById("profile-close-btn");if(A){if(g&&g.addEventListener("click",v=>{v.stopPropagation(),wg=!1,Fg&&(Fg.checked=!1),Kv(),RA("\u{1F4D0} \u5256\u9762\u9762\u677F\u5DF2\u5173\u95ED")}),B){let v=!1,w=0,f=0,C=0,e=0,P=n=>{if(n.target.closest("#profile-close-btn"))return;v=!0;let s=n.touches?n.touches[0]:n;w=s.clientX,f=s.clientY;let i=A.getBoundingClientRect();C=i.left,e=i.top,n.preventDefault(),n.stopPropagation()},D=n=>{if(!v)return;let s=n.touches?n.touches[0]:n,i=C+(s.clientX-w),r=e+(s.clientY-f);i=Math.max(4,Math.min(window.innerWidth-A.offsetWidth-4,i)),r=Math.max(4,Math.min(window.innerHeight-A.offsetHeight-4,r)),A.style.left=i+"px",A.style.top=r+"px",A.style.right="auto",A.style.bottom="auto",A.style.transform="none",n.preventDefault(),n.stopPropagation()},t=()=>{v=!1};B.addEventListener("mousedown",P),window.addEventListener("mousemove",D),window.addEventListener("mouseup",t),B.addEventListener("touchstart",P,{passive:!1}),window.addEventListener("touchmove",D,{passive:!1}),window.addEventListener("touchend",t)}if(Q){let v=!1,w=0,f=0,C=0,e=0,P=n=>{v=!0;let s=n.touches?n.touches[0]:n;w=s.clientX,f=s.clientY;let i=A.getBoundingClientRect();C=i.width,e=i.height,n.preventDefault(),n.stopPropagation()},D=n=>{if(!v)return;let s=n.touches?n.touches[0]:n,i=C+(s.clientX-w),r=e+(s.clientY-f);i=Math.max(300,Math.min(window.innerWidth-16,i)),r=Math.max(130,Math.min(window.innerHeight-40,r)),A.style.width=i+"px",A.style.height=r+"px",n.preventDefault(),n.stopPropagation()},t=()=>{v=!1};Q.addEventListener("mousedown",P),window.addEventListener("mousemove",D),window.addEventListener("mouseup",t),Q.addEventListener("touchstart",P,{passive:!1}),window.addEventListener("touchmove",D,{passive:!1}),window.addEventListener("touchend",t)}}})();async function BP(E){if(!QQ)try{let A=await sr(E);Kw(A,E,()=>{RA(`\u2705 \u5DF2\u52A0\u8F7D\u793A\u4F8B: ${E==="world"?"\u4E16\u754C\u5730\u5F62\uFF08\u5E26\u5927\u6D32\u5927\u6D0B\u6807\u6CE8\uFF09":"\u4E2D\u56FD\u5730\u5F62\uFF08\u88C1\u526A\u533A\u57DF\uFF09"}`)})}catch(A){RA(`\u274C \u52A0\u8F7D\u793A\u4F8B\u5931\u8D25: ${A.message}`),QQ=!1}}k9.addEventListener("click",()=>BP("world"));q9.addEventListener("click",()=>BP("china"));function QP(E){if(!E.type.startsWith("image/")){RA("\u274C \u8BF7\u4E0A\u4F20\u56FE\u7247\u6587\u4EF6");return}let A=new FileReader;A.onload=B=>{let Q=new Image;Q.onload=()=>{Kw(Q,null,()=>{RA(`\u2705 \u52A0\u8F7D\u6210\u529F\uFF01\u7CBE\u7EC6\u5EA6: ${eQ.value}\xD7${eQ.value}`)})},Q.src=B.target.result},A.onerror=()=>RA("\u274C \u8BFB\u53D6\u6587\u4EF6\u5931\u8D25"),A.readAsDataURL(E)}async function EP(E){try{let A=await fr(E,{gridWidth:600,gridHeight:400,power:2});Kw(A,"geojson",()=>{RA(`\u2705 GeoJSON\u5730\u5F62\u6210\u529F\uFF01\u70B9\u6570: ${E.name}`)})}catch(A){RA(`\u274C GeoJSON\u52A0\u8F7D\u5931\u8D25: ${A.message}`),console.error(A)}}De.addEventListener("change",E=>{E.target.files.length>0&&QP(E.target.files[0]),De.value=""});Ie.addEventListener("change",E=>{E.target.files.length>0&&EP(E.target.files[0]),Ie.value=""});NQ.addEventListener("dragover",E=>{E.preventDefault(),NQ.classList.add("dragover")});NQ.addEventListener("dragleave",()=>{NQ.classList.remove("dragover")});NQ.addEventListener("drop",E=>{E.preventDefault(),NQ.classList.remove("dragover");let A=E.dataTransfer.files;if(A.length>0){let B=A[0];B.type.startsWith("image/")?QP(B):B.name.endsWith(".geojson")||B.name.endsWith(".json")?EP(B):RA("\u274C \u4E0D\u652F\u6301\u7684\u6587\u4EF6\u683C\u5F0F\uFF0C\u8BF7\u4E0A\u4F20\u56FE\u7247\u6216GeoJSON")}});document.addEventListener("dragover",E=>E.preventDefault());document.addEventListener("drop",E=>E.preventDefault());Ug.addEventListener("input",Re);Xg.addEventListener("input",Re);eQ.addEventListener("input",()=>{be.textContent=eQ.value,dQ&&!QQ&&(vg(),RA(`\u{1F52C} \u7CBE\u7EC6\u5EA6: ${eQ.value}\xD7${eQ.value}`))});mg.addEventListener("input",()=>{me.textContent=mg.value,Sw=parseFloat(mg.value)});Eg.addEventListener("input",()=>{if(dQ&&!QQ&&(he.textContent=parseFloat(Eg.value).toFixed(3),vg(),AB==="china")){let E=oE.find(A=>A.pinyin===AQ);E&&(tQ(),cE(E))}});gg.addEventListener("change",()=>{if(dQ&&!QQ){if(vg(),AB==="china"){let E=oE.find(A=>A.pinyin===AQ);E&&(tQ(),cE(E))}RA(gg.checked?"\u{1F504} \u7070\u5EA6\u5DF2\u53CD\u8F6C":"\u{1F504} \u7070\u5EA6\u5DF2\u6062\u590D")}});xw.forEach(E=>{E.addEventListener("click",()=>{let A=E.dataset.scheme;if(A==="custom"){if(RQ=!0,xw.forEach(B=>B.classList.remove("active")),E.classList.add("active"),dQ&&!QQ){if(vg(),AB==="china"){let B=oE.find(Q=>Q.pinyin===AQ);B&&(tQ(),cE(B))}RA("\u{1F3A8} \u5207\u6362\u81F3\u300C\u81EA\u5B9A\u4E49\u300D\u914D\u8272")}}else if(RQ=!1,fg=A,xw.forEach(B=>B.classList.remove("active")),E.classList.add("active"),dQ&&!QQ){if(vg(),AB==="china"){let B=oE.find(Q=>Q.pinyin===AQ);B&&(tQ(),cE(B))}RA(`\u{1F3A8} \u5207\u6362\u81F3\u300C${Af[A].name}\u300D`)}})});xe.forEach(E=>{E.addEventListener("click",()=>{Ze(E.dataset.bg)})});ne.addEventListener("input",()=>{let E=parseInt(ne.value);V9.textContent=E,K9(E)});var Zv=!1;function BC(){Zv=!Zv,Zv?(nE.classList.remove("visible"),nE.style.display="none",rE.style.display="flex",rE.classList.add("pulse")):(nE.style.display="flex",nE.classList.add("visible"),rE.style.display="none",rE.classList.remove("pulse"))}document.addEventListener("click",E=>{if(Zv)return;let A=nE.contains(E.target),B=rE.contains(E.target),Q=NQ.contains(E.target);!A&&!B&&!Q&&BC()});rE.addEventListener("click",BC);X9.addEventListener("click",BC);nE.addEventListener("click",E=>{E.stopPropagation()});var He=null;function mr(){let A=2.8/VB.position.distanceTo(qA.target),B=Math.round(A*100);Fw.textContent=`\u{1F50D} ${B}%`,Fw.classList.add("show"),clearTimeout(He),He=setTimeout(()=>{Fw.classList.remove("show")},1500)}qA.addEventListener("change",()=>{mr(),er()});function RA(E){pw.textContent=E,pw.classList.add("show"),clearTimeout(window.statusTimeout),window.statusTimeout=setTimeout(()=>{pw.classList.remove("show")},3e3)}window.addEventListener("resize",()=>{VB.aspect=window.innerWidth/window.innerHeight,VB.updateProjectionMatrix(),kB.setSize(window.innerWidth,window.innerHeight),ZQ.setSize(window.innerWidth,window.innerHeight)});function gP(){requestAnimationFrame(gP),qA.update(),kB.render(SA,VB),ZQ.render(SA,VB)}gP();Ze("light");Ne();Bf();Sw=parseFloat(mg.value);RA("\u{1F4E4} \u8BF7\u4E0A\u4F20DEM\u7070\u5EA6\u56FE\u3001GeoJSON \u6216 \u9009\u62E9\u793A\u4F8B\u5730\u5F62");wQ=!1;Zw.classList.remove("active");Ge.textContent="\u5173\u95ED";le.classList.remove("show");document.getElementById("world-label-size-group").style.display="none";setTimeout(()=>{de.style.opacity="0.6"},8e3);console.log("\u{1F30D} 3D\u5730\u5F62\u53EF\u89C6\u5316 V"+ue+" \u5DF2\u542F\u52A8\uFF01");console.log("\u652F\u6301\u683C\u5F0F: \u56FE\u7247(PNG/JPG) | GeoJSON(.geojson/.json)");console.log("\u{1F4E7} rainbowgeo@qq.com");
/*! Bundled license information:

three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2023 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
